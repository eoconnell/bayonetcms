-- ***********************************************************************************
-- MILPACS - Military Personnel and Classification System
-- 
-- � 2005 - Donovan [3rd ID]
-- donovan _at_3rd-infantry DOT com
-- 
-- MILPACS is a PHPNuke module designed and offered to the First Person Shooter (FPS) Tactical Realism (TR) community.
--
-- This is release candiate 1, beta version.  (RC1_b)--
-- 
-- Created by: Donovan [3rd ID] http://www.3rd-infantry-division.net  
--
-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_adminunit`
-- 

CREATE TABLE `nuke_milpacs_adminunit` (
  `admin_unit_id` tinyint(4) NOT NULL auto_increment,
  `admin_unit_name` varchar(255) NOT NULL default '',
  `admin_unit_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`admin_unit_id`),
  KEY `admin_unit_name` (`admin_unit_name`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_award_lkup`
-- 

CREATE TABLE `nuke_milpacs_award_lkup` (
  `pid` int(4) NOT NULL auto_increment,
  `award_id` tinyint(4) default NULL,
  `uniqueid` tinyint(4) default NULL,
  `award_dt` date default NULL,
  `adetails` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`pid`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_awards`
-- 

CREATE TABLE `nuke_milpacs_awards` (
  `award_id` tinyint(4) NOT NULL auto_increment,
  `award_name` text NOT NULL,
  `award_image` varchar(255) NOT NULL default '',
  `award_description` varchar(250) NOT NULL default '',
  `award_class` varchar(255) default NULL,
  KEY `uniqueid` (`award_id`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_combat`
-- 

CREATE TABLE `nuke_milpacs_combat` (
  `warid` smallint(5) NOT NULL default '0',
  `uniqueid` tinyint(4) NOT NULL default '0',
  `oppid` smallint(5) NOT NULL default '0',
  `warstatus` smallint(1) default NULL,
  PRIMARY KEY  (`warid`,`uniqueid`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_drill_lkup`
-- 

CREATE TABLE `nuke_milpacs_drill_lkup` (
  `drill_id` int(11) NOT NULL default '0',
  `uniqueid` int(11) NOT NULL default '0',
  `status` char(10) NOT NULL default '',
  PRIMARY KEY  (`drill_id`,`uniqueid`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_drills`
-- 

CREATE TABLE `nuke_milpacs_drills` (
  `drill_id` int(11) NOT NULL auto_increment,
  `drill_dt` date NOT NULL default '0000-00-00',
  `drill_points` int(11) NOT NULL default '5',
  `drill_news` text NOT NULL,
  `drill_promotions` text NOT NULL,
  `drill_assign` text NOT NULL,
  `drill_tactic` text NOT NULL,
  `drill_leader` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`drill_id`)
) TYPE=MyISAM;

-- --------------------------------------------------------
-- 
-- Table structure for table `nuke_milpacs_main`
-- 

CREATE TABLE `nuke_milpacs_main` (
  `name` text NOT NULL,
  `motd` text NOT NULL,
  `color` text NOT NULL,
  `u_email` text NOT NULL,
  `drillpass` varchar(10) NOT NULL default ''
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_members`
-- 

CREATE TABLE `nuke_milpacs_members` (
  `u_name` text,
  `uniqueid` tinyint(4) NOT NULL auto_increment,
  `password` varchar(25) NOT NULL default '',
  `last_login` date NOT NULL default '0000-00-00',
  `Age` text,
  `location` text,
  `email` text,
  `icq` text,
  `bio` text,
  `weapon_id` tinyint(4) default NULL,
  `position` text,
  `enlistment_dt` date NOT NULL default '0000-00-00',
  `promotion_dt` date default '0000-00-00',
  `status` text,
  `unit_id` tinyint(4) NOT NULL default '4',
  `uniform` varchar(255) default NULL,
  `rank_id` tinyint(4) default '17',
  `flag` text,
  `reports` text,
  `s_mos` text,
  `p_mos` text,
  `points` int(11) NOT NULL default '0',
  `subunit_id` tinyint(4) NOT NULL default '0',
  `adminunits` text NOT NULL,
  PRIMARY KEY  (`uniqueid`),
  KEY `uniqueid` (`uniqueid`)
) TYPE=MyISAM;

-- 
-- Table structure for table `nuke_milpacs_pass`
-- 

CREATE TABLE `nuke_milpacs_pass` (
  `id` varchar(255) NOT NULL default '',
  `pass` varchar(255) NOT NULL default ''
) TYPE=MyISAM;

-- 
-- Insert data for table `nuke_milpacs_pass`
-- 

INSERT INTO `nuke_milpacs_pass` VALUES ('admin', '21232f297a57a5a743894a0e4a801fc3');

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_points`
-- 

CREATE TABLE `nuke_milpacs_points` (
  `point_id` tinyint(4) NOT NULL default '0',
  `point_class` varchar(255) NOT NULL default '',
  `action` varchar(5) NOT NULL default '',
  PRIMARY KEY  (`point_id`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_points_lkup`
-- 

CREATE TABLE `nuke_milpacs_points_lkup` (
  `pid` tinyint(4) NOT NULL auto_increment,
  `point_id` tinyint(4) NOT NULL default '0',
  `point_dt` date NOT NULL default '0000-00-00',
  `uniqueid` tinyint(4) NOT NULL default '0',
  `pdetails` varchar(255) NOT NULL default '',
  `points` int(11) NOT NULL default '0',
  PRIMARY KEY  (`pid`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_ranks`
-- 

CREATE TABLE `nuke_milpacs_ranks` (
  `rankname` text,
  `rank_id` tinyint(4) NOT NULL auto_increment,
  `rank_image` varchar(255) default NULL,
  `rank_image_l` varchar(255) default NULL,
  `rank_abbr` text,
  `rank_order` tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (`rank_id`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_service_record`
-- 

CREATE TABLE `nuke_milpacs_service_record` (
  `record_id` tinyint(4) NOT NULL auto_increment,
  `uniqueid` tinyint(4) default NULL,
  `record_dt` date default NULL,
  `details` varchar(255) default NULL,
  PRIMARY KEY  (`record_id`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_subunit`
-- 

CREATE TABLE `nuke_milpacs_subunit` (
  `subunit_id` tinyint(4) NOT NULL auto_increment,
  `unit_id` tinyint(4) NOT NULL default '0',
  `subunit_name` varchar(255) NOT NULL default '',
  `subunit_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`subunit_id`),
  KEY `subunit_name` (`subunit_name`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_units`
-- 

CREATE TABLE `nuke_milpacs_units` (
  `unit_id` tinyint(4) NOT NULL auto_increment,
  `unit_order` tinyint(4) NOT NULL default '0',
  `unit_name` varchar(255) default NULL,
  `unit_image` varchar(255) default NULL,
  `unit_creed` varchar(50) default NULL,
  `unit_motto` text,
  `unit_nick` text,
  `unit_goal_one` text,
  `unit_goal_two` text,
  `unit_goal_three` text,
  `unit_bio` text,
  PRIMARY KEY  (`unit_id`),
  FULLTEXT KEY `unit_motto` (`unit_motto`)
) TYPE=MyISAM;

-- ---------------------------------------------------------- 
-- Table structure for table `nuke_milpacs_weapons`
-- 

CREATE TABLE `nuke_milpacs_weapons` (
  `weapon_id` tinyint(4) NOT NULL auto_increment,
  `model` varchar(50) default NULL,
  `make` varchar(50) default NULL,
  `weapon_image` varchar(255) default NULL,
  `weapon_descr` text,
  `caliber` varchar(20) default NULL,
  `rounds` varchar(20) default NULL,
  `weight` varchar(20) default NULL,
  `weapon_class` varchar(30) default NULL,
  `intro_dt` varchar(50) default NULL,
  `type_fire` varchar(50) default NULL,
  `rate_fire` varchar(50) default NULL,
  `eff_range` varchar(50) default NULL,
  `max_range` varchar(50) default NULL,
  PRIMARY KEY  (`weapon_id`)
) TYPE=MyISAM;
