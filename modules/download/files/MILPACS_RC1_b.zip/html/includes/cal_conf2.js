
//Define calendar(s): addCalendar ("Unique Calendar Name", "Window title", "Form element's name", Form name")
addCalendar("Enlistment", "Select Date", "enlistment_dt", "editsoldier");
addCalendar("Promoted", "Select Date", "promotion_dt", "editsoldier");
addCalendar("addDrillDate", "Select Date", "drill_dt", "adddrillreport");
addCalendar("editDrillDate", "Select Date", "drill_dt", "editdrillreport");
addCalendar("editServiceRecord", "Select Date", "record_dt", "editservicerecord");
addCalendar("addServiceRecord", "Select Date", "record_dt", "addservicerecord");
addCalendar("EditMedalDate", "Select Date", "award_dt", "editmedalrecord");
addCalendar("AddMedalDate", "Select Date", "award_dt", "addmedalrecord");
addCalendar("AddPointDate", "Select Date", "point_dt", "addpoints");
addCalendar("RemovePointDate", "Select Date", "point_dt", "removepoints");
addCalendar("addEnlistment", "Select Date", "enlistment_dt", "addsoldier");




// default settings for English
// Uncomment desired lines and modify its values
// setFont("verdana", 9);
 setWidth(90, 1, 15, 1);
// setColor("#cccccc", "#cccccc", "#ffffff", "#ffffff", "#333333", "#cccccc", "#333333");
// setFontColor("#333333", "#333333", "#333333", "#ffffff", "#333333");
 setFormat("yyyy-mm-dd");
// setSize(200, 200, -200, 16);

// setWeekDay(0);
// setMonthNames("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
// setDayNames("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
// setLinkNames("[Close]", "[Clear]");
