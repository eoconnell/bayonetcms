<?php

/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if(!defined('NUKE_FILE')) {
  header("Location: ../index.php");
  die();
}
$module_name = "MILPACS";
get_lang($module_name);

$content  =  "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS\">Information</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=roster\">Roster</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=award\">Medals</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=weapon\">Weapons</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=enlistment\">Enlistment</a><BR>";
$content  .= "<HR><br>";
$content  .= "<B><center>"._MILPACS_TAG." Only!</center></B><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=checkuser\">Drill Report</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"milpacs.php\">Administration</a><BR>";
?>