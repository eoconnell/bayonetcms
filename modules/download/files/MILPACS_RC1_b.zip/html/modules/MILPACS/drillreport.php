 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Drill Report                                          */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "drillreport.php")) {
	Header("Location: ../../index.php");
	die();
}

require_once("common.php");

if (!milpacs_is_user())
{
    Header("Location: modules.php?name=MILPACS&file=checkuser");
}
$index = 0;

//finds the server's root directory
@require_once("mainfile.php");
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
global $module_name, $db, $prefix;
get_lang($module_name);
OpenTable();
echo"<table border=0><tr><td width=100%>"
  . "<font class=\"mainroster\"><big><b>"._MILPACS_UNIT." Drill Report</b></big></font>"
  . "<!-- <hr width=200 align=\"left\"> -->"
  . "</td></tr></table>"
  . ""
  . "<br>";

CloseTable();
OpenTable();
$drill_id = intval($_GET['drill_id']);	
$result = $db->sql_query ("SELECT date_format(drill_dt,'%e %b %Y') as drill_dt, drill_id, drill_news, drill_promotions, drill_assign, drill_tactic FROM " . $prefix . "_milpacs_drills WHERE drill_id = '$drill_id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}

$News_Result = str_replace( "\n", '<br />', $info[drill_news]); 
$Promo_Result = str_replace( "\n", '<br />', $info[drill_promotions]);
$Assign_Result = str_replace( "\n", '<br />', $info[drill_assign]);
$Tactic_Result = str_replace( "\n", '<br />', $info[drill_tactic]);

?>
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#444444" bordercolor="#111111" width="100%">
<a href="modules.php?name=MILPACS&file=viewdrill">Go back to select another drill.</a>
		<tr>
         <td align="center" bgcolor="#777777">
            <b><font color="#000000">Drill Report for <?php echo $info[drill_dt]; ?></font></b>
         </td>
       <tr>
			<td align="left" bgcolor="#666633">
			 <b><font color="#000000">News</font></b>
			</td>
		</tr>
       <tr>
            <td align="left" bgcolor="#777777" width="80%"><p class="content"><?php echo $News_Result; ?></p></td>
       </tr>
       <tr>
			<td align="left" bgcolor="#666633">
			 <b><font color="#000000">Promotions</font></b>
			</td>
		</tr>
       <tr>
            <td align="left" bgcolor="#777777" width="80%"><p class="content"><?php echo $Promo_Result; ?></p></td>
       </tr>
       <tr>
			<td align="left" bgcolor="#666633">
			 <b><font color="#000000">Assignments</font></b>
			</td>
		</tr>
       <tr>
            <td align="left" bgcolor="#777777" width="80%"><p class="content"><?php echo $Assign_Result; ?></p></td>
       </tr>
       <tr>
			<td align="left" bgcolor="#666633">
			 <b><font color="#000000">Tactics</font></b>
			</td>
		</tr>
       <tr>
            <td align="left" bgcolor="#777777" width="80%"><p class="content"><?php echo $Tactic_Result; ?></p></td>
       </tr>
		</table>

<!-- returns all units personnel present for drills -->

<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="100%">
		 <tr>
         <td align="center" bgcolor="#777777">
            <b><font color="#000000">Attendance for Drill on <?php echo $info[drill_dt]; ?></font></b>
         </td>
		 </tr>
<table border=0 width='100%' cellpadding='3'><tr><th width='8%'>Rank</th><th width='30%'><b>Name</b></th><th width='30%'><b>Status</b></th></tr>
		</table>
<?php
$sql = "SELECT nmr.rank_abbr, nmm.u_name, nmdl.uniqueid, nmdl.drill_id, nmdl.status FROM " . $prefix . "_milpacs_members nmm, " . $prefix . "_milpacs_ranks nmr, " . $prefix . "_milpacs_drill_lkup nmdl WHERE nmdl.uniqueid = nmm.uniqueid AND nmm.rank_id = nmr.rank_id AND nmdl.status = 'Present' AND drill_id = $drill_id AND nmm.status IN ('Active','LOA') ORDER BY nmm.rank_id";
 // echo "    <td align=\"center\" bgcolor=\"#666633\"><b><font color=\"#000000\">Present</font></b>";
$result1 = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result1) ) {
	extract($row); 
	?>
	<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#444444" bordercolor="#111111" width="100%">
	 <tr>
		<td align="center" bgcolor="#777777" width="8%"<p class="content"><?php echo $rank_abbr; ?></font></b>
		</td>
		<td align="center" bgcolor="#777777" width="30%"<p class="content"><?php echo $u_name; ?></font></b>
		</td>
		<td align="center" bgcolor="#777777" width="30%"<p class="content"><font color="#009900"><?php echo $status; ?></font></b>
		</td>
	</tr>
	<?php
}
?>
</table>
<?php

$sql = "SELECT nmr.rank_abbr, nmm.u_name, nmdl.uniqueid, nmdl.drill_id, nmdl.status FROM " . $prefix . "_milpacs_members nmm, " . $prefix . "_milpacs_ranks nmr, " . $prefix . "_milpacs_drill_lkup nmdl WHERE nmdl.uniqueid = nmm.uniqueid AND nmm.rank_id = nmr.rank_id AND nmdl.status = 'Excused' AND drill_id = $drill_id AND nmm.status IN ('Active','LOA') ORDER BY nmm.rank_id";
//  echo "    <td align=\"center\" bgcolor=\"#666633\"><b><font color=\"#000000\">Excused</font></b>";
$result2 = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result2) ) {
	extract($row); 
	?>
	<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#444444" bordercolor="#111111" width="100%">
	 <tr>
		<td align="center" bgcolor="#777777" width="8%"<p class="content"><?php echo $rank_abbr; ?></font></b>
		</td>
		<td align="center" bgcolor="#777777" width="30%"<p class="content"><?php echo $u_name; ?></font></b>
		</td>
		<td align="center" bgcolor="#777777" width="30%"<p class="content"><font color="#FFFF00"><?php echo $status; ?></font></b>
		</td>
	</tr>
	<?php
}
?>
</table>
<?php

$sql = "SELECT nmr.rank_abbr, nmm.u_name, nmdl.uniqueid, nmdl.drill_id, nmdl.status FROM " . $prefix . "_milpacs_members nmm, " . $prefix . "_milpacs_ranks nmr, " . $prefix . "_milpacs_drill_lkup nmdl WHERE nmdl.uniqueid = nmm.uniqueid AND nmm.rank_id = nmr.rank_id AND nmdl.status = 'Absent' AND drill_id = $drill_id AND nmm.status IN ('Active','LOA') ORDER BY nmm.rank_id";
//  echo "    <td align=\"center\" bgcolor=\"#666633\"><b><font color=\"#000000\">Absent</font></b>";
$result3 = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result3) ) {
	extract($row); 
	?>
	<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#444444" bordercolor="#111111" width="100%">
	 <tr>
		<td align="center" bgcolor="#777777" width="8%"<p class="content"><?php echo $rank_abbr; ?></font></b>
		</td>
		<td align="center" bgcolor="#777777" width="30%"<p class="content"><?php echo $u_name; ?></font></b>
		</td>
		<td align="center" bgcolor="#777777" width="30%"<p class="content"><font color="#FF3300"><?php echo $status; ?></font></b>
		</td>
	</tr>
	<?php
}
echo	"</table>";
CloseTable();
@include_once("footer.php");
?>
