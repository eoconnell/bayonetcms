<?php

/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* View Drill                                            */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "viewdrill.php")) {
    Header("Location: ../../index.php");
    die();
}
require_once("common.php");

if (!milpacs_is_user())
{
    Header("Location: modules.php?name=MILPACS&file=checkuser");
}

$index=0;

//finds the server's root directory
@require_once("mainfile.php");
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
global $module_name, $db, $prefix;
get_lang($module_name);

OpenTable();
echo"<style type=\"text/css\"><!--"
  . "p.content		{ font-size: 12px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF;}"
  . "h1 {text-align: center}"
  . "--></style>"
  . "<table border=0><tr><td width=100%>"
  . "<font class=\"mainroster\"><big><b>"._MILPACS_TAG." Drill Page</b></big></font><hr width=200 align=\"left\"></td></tr>"
  . "<tr>"
  . "</td>"
  . "</tr></table>"
  . "<form name=\"viewdrill\" method=\"post\" action=\"modules.php?name=MILPACS&file=drillreport\">"
 ."";
CloseTable();
OpenTable();
echo"<table border=0 width='100%' cellpadding='5'><tr>"
  . "<table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Drill Date</th><th width='20%'><b>Drill Leader</b></th><th width='20%'>View Drill"
  . "</th></tr>"
 ."";
// create the SQL statement
$sql = "SELECT drill_id, drill_dt, drill_leader FROM " . $prefix . "_milpacs_drills ORDER BY drill_dt DESC";
//fill the table with values from drill table
$result = $db->sql_query($sql);
$total = $db->sql_numrows($result);

	$posts_per_page = 20;
	if (!isset($start)) { $start = 0; }
    else {$start = intval($start);}
	$pageaddy = "modules.php?name=MILPACS&file=viewdrill";

	if($total > $posts_per_page) {
   	$times = 0;
   	for($x = 0; $x < $total; $x += $posts_per_page)
    	 	$times++;
   		$pages = $times;
	}

if($total > $posts_per_page) {
   $printposts = "<TABLE BORDER=\"0\" ALIGN=\"RIGHT\">";
   $times = 1;

   $printposts = $printposts . "<TR ALIGN=\"LEFT\"><TD>"." ( ";
   $last_page = $start - $posts_per_page;
   if($start > 0) {
   $printposts = $printposts . "<a href=\"". $pageaddy ."&start=$last_page\">Previous Page</a> ";
   }
   for($x = 0; $x < $total; $x += $posts_per_page) {
      if($times != 1)
   $printposts = $printposts . " | ";
      if($start && ($start == $x)) {
   $printposts = $printposts . "<b>".$times."</b>";
      }
      else if($start == 0 && $x == 0) {
   $printposts = $printposts . "<b>1</b>";
      }
      else {
   $printposts = $printposts . "<a href=\"".$pageaddy . "&start=$x\">$times</a>";
      }
      $times++;
   }
   if(($start + $posts_per_page) < $total) {
      $next_page = $start + $posts_per_page;
   $printposts = $printposts . " <a href=\"". $pageaddy . "&start=$next_page\">Next Page</a>";
   }
   $printposts = $printposts . " ) </TD></TR></TABLE>\n";
}

$sql = "SELECT drill_id, drill_dt, drill_leader FROM " . $prefix . "_milpacs_drills ORDER BY drill_dt DESC  LIMIT $start, $posts_per_page";
//fill the table with values from drill table
$result = $db->sql_query($sql);

while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	list($Year,$Month,$Day) = split('-',$drill_dt);
    $formatdrilldate = date("F j, Y",mktime(12,0,0,$Month,$Day,$Year));
	?>
	<td class='row1' width='20%' class='row1' align='center'><?php echo $formatdrilldate ?></td><td width='20%' class='row1' align='center'><?php echo $drill_leader ?></td><td class='row1' width='20%' align='center'><a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=drillreport&amp;drill_id=<?php echo $drill_id ?>">Click Here!</a>
	</td></tr>
	<?php
}
?>
</table>
<?
if($total > $posts_per_page) {
	echo $printposts;
}
?>
<br/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>