<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

// Drill page access with session authentication.

if (stristr($_SERVER['SCRIPT_NAME'], "drillaccess.php")) {
    Header("Location: ../../index.php");
    die();
}
//@include_once ("constants.php");
@require_once("mainfile.php");
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
global $module_name, $db, $prefix;
OpenTable();

//show the form

?>
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#444444" bordercolor="#111111" width="100%">
<tr>
    <td align="center" bgcolor="#777777"> <b><H3> Drill Access -- Authorization Required!</H3></b></td>
</tr>
<tr>
    <td align="center" bgcolor="#777777"> <b><font color="#000000"> All soldiers are required to enter the password.</font></b></td>
</tr>
<tr>
<form name="drillaccess" action="modules.php?name=<?php echo $module_name ?>" method="post">
	<td align="center"> <b><font color="#000000">Password: <input type="password" name="drillpass" /></td>
</tr>
<tr>
<td><input type="hidden" name="op" value="AccessDrill"/>
<input type="submit" align="center" name="submit" value="Login" /><br></td>
</tr>
</table>
</form>

<?php
CloseTable();
if ($op == "AccessDrill") {   //process the login

$result = $db->sql_query ("SELECT drillpass FROM " . $prefix . "_milpacs_main");
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
} else {
$password = md5($db->sql_fetchrow($result));
}

if ($password == "drillpass") //they got it right, let's go on
{
session_start();
session_register("drillsession"); //set a variable for use later
$id = session_id(); //let's grab the session ID for those who don't have cookies
$url = "modules.php?name=MILPACS&file=viewdrill?sid=" . $id;
header($url);
}
else //the dummy got the password wrong, so tell them their an idiot. :)
{
OpenTable();
?>
<tr>
<td><center><h3>Password Is Invalid!<h3></center><td/>
</tr>
<tr>
<td align="center" bgcolor="#777777"> <b><font color="#000000">Access restricted to active duty soldiers only.</font></b></td>
<tr>
<td align="center" bgcolor="#777777" valign="top"><img border="0" src=modules/MILPACS/images/classified1.gif></td>
</tr>
<!--<META HTTP-EQUIV="refresh" content="3;URL=modules.php?name=MILPACS&file=drillaccess"><a href="modules.php?name=MILPACS&file=drillaccess">-->
<?php
CloseTable();
@include_once("footer.php");
}
}
?> 