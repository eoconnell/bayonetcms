 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Medal                                             */
/*********************************************************/
if (stristr($_SERVER['SCRIPT_NAME'], "addmedal.php")) {
    Header("Location: ../../../index.php");
    die();
}

include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

//finds the server's root directory
$index = 0;
require_once("mainfile.php");
include_once("header.php");
get_lang($module_name);
global $module_name, $db, $prefix; 

// Load Medal image
	$urlofimages="$DOCUMENT_ROOT/modules/MILPACS/images/medals/";
	$medalselecthtml = "<select name=\"award_image\">";
	$medalselecthtml .= "<option value=\"\">Select Medal Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$award_image) {
					$medalselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$medalselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$medalselecthtml .= "</select></td>";
	

if ($op == "addMedal") {
		// Validations go here
		// If all validations passed, save and exit, otherwise, redisplay with errors
		$award_name = $_POST['award_name'];
		$award_description = addslashes($_POST['award_description']);		
		$award_image = $_POST['award_image'];
		$award_class = $_POST['award_class'];
		//Insert the values into the database 
	$sql = "INSERT INTO " . $prefix . "_milpacs_awards (award_id, award_name, award_image, award_description, award_class)". "VALUES ('NULL','$award_name','$award_image','$award_description', '$award_class')";
		$result = $db->sql_query($sql);
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		}
}
		
//} else {
//	//Update the values in the database 
//			$sql = "UPDATE " . $prefix . "_milpacs_awards set
//				award_name = '$award_name',
//				award_description = '$award_description',
//				award_image = '$award_image',
//				award_class = '$award_class'
//			 WHERE award_id = '$award_id'";
//		}
//		$result = $db->sql_query($sql);
//		if (!$result) {
//		echo("<p>Error performing query: " . mysql_error() . "</p>");
//		exit();
//	} else {		
//		echo "<META HTTP-EQUIV=\"refresh\" content=\"0;URL=modules.php?name=MILPACS&file=award\">";
//	}
OpenTable();
echo "<p><a href=\"milpacs.php\">Return to Main Administration</a></p>";
?>

<form name="addmedal" action="milpacs.php?aop=addmedal" method="POST">	
 <table width="100%" border="2" cellpadding="2" align ="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111">
  <tr>
           <td align="center" bgcolor="#777777">
              <b><font color="#000000"><?php echo "._MILPACS_TAG." ?> Medal <?php echo $award_name ?></font></b>
           </td>
         <tr>
  			<td align="left" bgcolor="#666633">
  			 <b><font color="#000000">Medal Information</font></b>
  			</td>
  		</tr>
  <table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Medal Image</th><th width='30%'>Name of Medal</th><th width='20%'><b>Medal Details</b></th><th width='10%'><b>Medal Class</b></th></tr>  
		<tr>
			<td align="center" size="20" bgcolor="#999999"> <?php echo $medalselecthtml ?>
			</td>
			<td align="center" bgcolor="#999999"><input type="text" size="40" name="award_name">
			</td>
			<td align="center" bgcolor="#999999"><textarea name="award_description" cols="30" colspan="1" rows="3"> <?php echo$award_description ?></textarea>
			</td>
			<td align="center" bgcolor="#999999">
			<select NAME="award_class">
               <option VALUE="SB">Skill Badge
               <option VALUE="UC">Unit Citiation
			   <option VALUE="IM">Individual Medal
          </select>			
			</td>
			</tr>
</table>
<br>
<br>
<hr>
<input type="hidden" name="op" value="addMedal">
<input type="hidden" name="award_id" value="<?php echo $award_id ?>"/>
<input type="submit" align="center" name="Submit" value="Add"/>
</form>
<?php
CloseTable();
include("footer.php");
?>