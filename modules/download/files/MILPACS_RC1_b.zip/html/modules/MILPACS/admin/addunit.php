<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Unit                                              */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "addunit.php")) {
    Header("Location: ../../index.php");
    die();
}
$index = 0;
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

//Required Files
require_once("mainfile.php");
include_once("header.php");
global $module_name, $db, $prefix;


// Add values to unit table
if ($op == "newUnit") {		

		$unit_name = $_POST['unit_name'];
		$unit_order = $_POST['unit_order'];
		$unit_image = $_POST['unit_image'];	
		$unit_nick = $_POST['unit_nick'];
		$unit_creed = addslashes($_POST['unit_creed']);
		$unit_motto = addslashes($_POST['unit_motto']);
		$unit_goal_one = addslashes($_POST['unit_goal_one']);
		$unit_goal_two = addslashes($_POST['unit_goal_two']);
		$unit_goal_three = addslashes($_POST['unit_goal_three']);
		$unit_bio = addslashes($_POST['unit_bio']);	
		
		//Insert the values into the units table 
	$sql = "INSERT INTO " . $prefix . "_milpacs_units (unit_id, unit_name, unit_order, unit_image, unit_nick, unit_creed, unit_motto, unit_goal_one, unit_goal_two, unit_goal_three, unit_bio)". "VALUES ('NULL','$unit_name','$unit_order','$unit_image','$unit_nick', '$unit_creed', '$unit_motto', '$unit_goal_one', '$unit_goal_two', '$unit_goal_three', '$unit_bio')";
		$result = $db->sql_query($sql);
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		}
}
		// Load Unit image
$urlofimages="$DOCUMENT_ROOT/modules/MILPACS/images/units/";
$unitselecthtml = "<select name=\"unit_image\">";
$unitselecthtml .= "<option value=\"\">Select Unit Image</option>";
if ($handle=@opendir($urlofimages)) { 
	while ($imgfile = readdir($handle)) {
		if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
			if ($imgfile==$unit_image) {
				$unitselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
			} else {
				$unitselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
			}
		}
	}
	@closedir($handle);
}
$unitselecthtml .= "</select></td>";
OpenTable();
echo "<p><a href=\"milpacs.php\">Return to Main Administration</a></p>";
?>
<form name="addunit" action="milpacs.php?aop=addunit" method="POST">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="100%"><tr>
         <td align="center" bgcolor="#777777"> Unit Name: <input type="text" name="unit_name" value="<?php echo $unit_name ?>">
         </td>
      </tr>         
		<tr>
         <td align="center" bgcolor="#777777"> Unit Image: <?php echo $unitselecthtml ?>
         </td>
      </tr>
		<tr>
         <td align="center" bgcolor="#777777"> Unit Call Sign: <input type="text" name="unit_nick" value="<?php echo $unit_nick ?>">
		 </td>
		 </tr>
		<tr>
		 <td align="center" bgcolor="#777777"> Unit Order: <input type="text" name="unit_order" value="<?php echo $unit_order ?>">
         </td>
      </tr>
      <tr>
			<td align="center" bgcolor="#666633">
            <b><font color="#000000">Unit Creed</font></b>
			</td>
      </tr>
      <tr>
			<td align="center" bgcolor="#999999">
			<textarea name="unit_creed" cols="130" colspan="1" rows="4"> <?php echo $unit_creed ?> </textarea>
			 </td>
		</tr>
      <tr>
      <tr>
			<td align="center" bgcolor="#666633">
            <b><font color="#000000">Unit Motto</font></b>
			</td>
      </tr>
      <tr>
			<td align="center" bgcolor="#999999">
			<textarea name="unit_motto" cols="130" colspan="1" rows="4"> <?php echo $unit_motto ?> </textarea>
			 </td>
		</tr>
      <tr>
			<td align="center" bgcolor="#666633">
            <b><font color="#000000">Unit Goals</font></b>
			</td>
      </tr>
      <tr>
			<td align="center" bgcolor="#999999">
			<textarea name="unit_goal_one" cols="130" colspan="1" rows="2"> <?php echo $unit_goal_one ?> </textarea>
			 </td>
		</tr>
      <tr>
			<td align="center" bgcolor="#999999">
			<textarea name="unit_goal_two" cols="130" colspan="1" rows="2"> <?php echo $unit_goal_two ?> </textarea>
			 </td>
		</tr>
      <tr>
			<td align="center" bgcolor="#999999">
			<textarea name="unit_goal_three" cols="130" colspan="1" rows="2"> <?php echo $unit_goal_three ?> </textarea>
			 </td>
		</tr>
      <tr>
			<td align="center" bgcolor="#666633">
            <b><font color="#000000">Unit Bio</font></b>
			</td>
      </tr>
      <tr>
			<td align="center" bgcolor="#999999">
			<textarea name="unit_bio" cols="130" colspan="1" rows="4"> <?php echo $unit_bio ?> </textarea>
			 </td>
		</tr>
		</table>		
<br>
<input type="hidden" name="op" value="newUnit"/>
<input type="hidden" name="id" value="$id"/>
<input type="submit" align="center" name="Submit" value="Add"/>
</form>
<?php
CloseTable();
?>