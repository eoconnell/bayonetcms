 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit the Soldier of the Month                         */
/*********************************************************/
if (stristr($_SERVER['SCRIPT_NAME'], "editsotm.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

$index = 0;

//finds the server's root directory
$self = dirname(__FILE__);
$nukemod = basename($self);
$rootdir = eregi_replace("/modules/$nukemod", "", $self);
require_once("mainfile.php");
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
global $module_name, $db, $prefix; 

	Opentable();

if ($op == "editsotm") {
	// Validations go here
	// If all validations passed, save and exit, otherwise, redisplay with errors	
	$uniqueid = intval($_POST['uniqueid']);	
	$citation = ($_POST['citation']);	
	$criteria = ($_POST['criteria']);	

	$result = $db->sql_query("UPDATE " . $prefix . "_milpacs_sotm SET uniqueid = '$uniqueid', citation = '$citation', criteria = '$criteria'");
			
	echo "<META HTTP-EQUIV=\"refresh\" content=\"0;URL=modules.php?name=MILPACS&file=sotm\">";
			if (!$result) {
   die('Could not query:' . mysql_error());
   exit();
}
}
?>
<form name="editsotm" action="modules.php?name=MILPACS" method="post">
<H3><center>Soldier of the Month</center></H3>
<HR>
<table border=0 width="100%" cellpadding="5">
<select name="uniqueid" size="1" align="center"> 
	<option selected value="">--- Select Soldier ---</option>
<?php
$result = $db->sql_query("SELECT uniqueid, name, status, rank_id FROM " . $prefix . "_milpacs_members WHERE status = 'Active' OR status = 'LOA' ORDER BY rank_id ASC");

while ( $row = $db->sql_fetchrow($result) ) {
	$name = $row["name"];
	$uniqueid = $row["uniqueid"];	
	echo "<option value='$uniqueid'>$name</option>";
	} 
?>
		</select>
<br><br>
<tr>
<th width="15%"><b>Citation</b></th><td align="left" width="15%">
<textarea name="citation" cols="90" colspan="1" rows="4"><?php echo $citation ?></textarea>
</td>
</tr>
<tr>
<th width="15%">Criteria</th><td align="left" width="15%">
<textarea name="criteria" cols="90" colspan="1" rows="4"><?php echo $criteria ?></textarea>
</td>
</tr>
</table>
<input type="hidden" name="op" value="editsotm"/>
<input class="button" type="submit" align="center" value="Update"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>