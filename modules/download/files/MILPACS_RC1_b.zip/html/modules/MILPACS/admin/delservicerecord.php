<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Delete Service Record                                 */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "delservicerecord.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}
include_once("header.php");
OpenTable();

if ($aop == "delservicerecord") {
	$record_id = intval($_GET['record_id']);
	$result = $db->sql_query("SELECT uniqueid FROM " . $prefix . "_milpacs_service_record WHERE record_id ='$record_id'");
	$info = $db->sql_fetchrow($result);
    $id = $info[uniqueid];
	$sql = "DELETE FROM " . $prefix . "_milpacs_service_record WHERE record_id ='$record_id'";	
	$result = $db->sql_query($sql);
	Header("Location: /milpacs.php?aop=servicerecord&id=$id");	
	}
?>

<!--//<form name="delservicerecord" action=<?php echo $_SERVER['PHP_SELF'] ?>  method="post">
//<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#666633" bordercolor="#111111" width="100%">
//	<tr>
//		<td colspan=2 align="center" bgcolor="#777777">
//		<b><font color="#000000">Are you sure you want to delete this record?</font></b>
//		</td>
//	</tr>	
//</table>
//<br>
//<input type="hidden" name="op" value="delservice"/>
//<input type="hidden" name="record_id" value="<?php echo $record_id ?>"/>
//<input type="hidden" name="id" value="<?php echo $id ?>"/>
//<input type="submit" align="center" name="Submit" value="Delete"/>
//</form>
//<?php
//CloseTable();
//@include_once("footer.php");
//?>