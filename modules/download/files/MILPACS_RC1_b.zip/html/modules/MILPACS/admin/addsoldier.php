<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/
/*********************************************************/
/* Add Soldier to MILPACS                                */
/*********************************************************/
if (stristr($_SERVER['SCRIPT_NAME'], "addsoldier.php")) {
    Header("Location: ../../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}


//finds the server's root directory
$index = 0;
require_once("mainfile.php");
include_once("header.php");
global $module_name, $db, $prefix;

if ($op == "saveSoldier") {
	// Validations go here
	// If all validations passed, save and exit, otherwise, redisplay with errors
	$rank_id = intval($_POST['rank_id']); 
    $unit_id = intval($_POST['unit_id']); 
    $weapon_id = intval($_POST['weapon_id']); 
    $bio = addslashes($_POST['bio']);	
	$soldierName = $_POST['u_name'];
	$uniform = $_POST['uniform'];
	$flag = $_POST['flag'];
	$location = $_POST['location'];
	$status = $_POST['status'];
	$p_mos = $_POST['p_mos'];
	$reports = $_POST['reports'];
	$position = $_POST['position'];
	$enlistment_dt = $_POST['enlistment_dt'];		
	$icq = $_POST['icq'];
		
	//Insert the values into the correct database with the right fields
	$result = $db->sql_query ("INSERT INTO " . $prefix . "_milpacs_members (uniqueid, u_name, uniform, rank_id, flag, location, status, p_mos, unit_id,  reports, position, weapon_id, enlistment_dt, icq, bio)".
		"VALUES ('NULL','$soldierName','$uniform', $rank_id, '$flag', '$location', '$status', '$p_mos', $unit_id, '$reports', '$position', $weapon_id, '$enlistment_dt', '$icq', '$bio')");

	if (!$result) {
	    echo("<p>Error adding Soldier!" . mysql_error() . "</p>");
	}
	else {
		$result = $db->sql_query($sql);
		echo "<META HTTP-EQUIV=\"refresh\" content=\"0;URL=modules.php?name=MILPACS&file=roster\">";
	}

}     
		   
		   $DOCUMENT_ROOT = $_SERVER['DOCUMENT_ROOT'];
// Load Uniform images (Rank, Flag)
	$urlofimages="$DOCUMENT_ROOT/modules/MILPACS/images/uniform/";
	$uniformselecthtml = "<select name=\"uniform\">";
	$uniformselecthtml .= "<option value=\"\">Select Uniform Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
//			 echo "$imgfile<br>";
				if ($imgfile==$uniform) {
					$uniformselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$uniformselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$uniformselecthtml .= "</select></td>";

// Load Ranks
	$rankselecthtml = "<select name=\"rank_id\">";
	$rankselecthtml .= "<option value=\"\">Select Rank</option>";
    $result2 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_ranks order by rank_id");
	while ($rankrow = $db->sql_fetchrow($result2)) {
		if ($rankrow[rank_id]==$rank_id) {
			$rankselecthtml .= "<option value =\"$rankrow[rank_id]\" selected>$rankrow[rankname]</option>";
		} else {
			$rankselecthtml .= "<option value =\"$rankrow[rank_id]\" >$rankrow[rankname]</option>";
		}
	}
	$rankselecthtml .= "</select></td>";

// Load Flag images
	$urlofimages="$DOCUMENT_ROOT/modules/MILPACS/images/flags/";
	$flagselecthtml = "<select name=\"flag\">";
	$flagselecthtml .= "<option value=\"\">Select Flag Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$flag) {
					$flagselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$flagselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$flagselecthtml .= "</select></td>";

// Load Weapons
	$weaponselecthtml = "<select name=\"weapon_id\">";
	$weaponselecthtml .= "<option value=\"\">Select Weapon</option>";
    $result3 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_weapons order by make");
	while ($weaponrow = $db->sql_fetchrow($result3)) {
		if ($weaponrow[weapon_id]==$weapon_id) {
			$weaponselecthtml .= "<option value =\"$weaponrow[weapon_id]\" selected>$weaponrow[make]</option>";
		} else {
			$weaponselecthtml .= "<option value =\"$weaponrow[weapon_id]\" >$weaponrow[make]</option>";
		}
	}
	$weaponselecthtml .= "</select>";

// Load Unit
	$unitselecthtml = "<select name=\"unit_id\">";
	$unitselecthtml .= "<option value=\"\">Select Unit</option>";
    $result4 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_units order by unit_name");
	while ($unitrow = $db->sql_fetchrow($result4)) {
		if ($unitrow[unit_id]==$unit_id) {
			$unitselecthtml .= "<option value =\"$unitrow[unit_id]\" selected>$unitrow[unit_name]</option>";
		} else {
			$unitselecthtml .= "<option value =\"$unitrow[unit_id]\" >$unitrow[unit_name]</option>";
		}
	}
	$unitselecthtml .= "</select>";	

// Load Status
$statusselecthtml = "<select name=\"status\">\n<option value=\"\">Select Status</option>";
$wStatus = array("Active", "LOA", "Medical LOA", "Retired", "Discharged");
for ($i=0; $i < sizeof($wStatus); $i++) {
	if ($status == $wStatus[$i])
		$statusselecthtml .= "<option value='$wStatus[$i]' selected>$wStatus[$i]</option>";
	else
		$statusselecthtml .= "<option value='$wStatus[$i]'>$wStatus[$i]</option>";
}
$statusselecthtml .= "</select>";
OpenTable();
echo "<p><a href=\"milpacs.php\">Return to Main Administration</a></p>";   	 
?>
<form name="addsoldier" action="milpacs.php?aop=addsoldier" method="POST">
<!--<form name="addsoldier" action="milpacs.php" method="POST">-->
<table width="100%" border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#555555" bordercolor="#111111">
	<tr>
		<td align="center" bgcolor="#777777">
		<b><font color="#000000">Add a new Soldier!</font></b></td>
	</tr>
	<tr>
		<td align="center" bgcolor="#777777"> Uniform image: <?php echo $uniformselecthtml ?></td>
	</tr>
	<tr>
		<td align="center" bgcolor="#777777"> Rank image: <?php echo $rankselecthtml ?></td>
	</tr>
	<tr>
		<td align="center" bgcolor="#777777"> Flag image: <?php echo $flagselecthtml ?></td>
	</tr> 
</table>
<table width="100%" border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#555555" bordercolor="#111111">
	<tr>
		<td height="25" colspan="2" align="left" bgcolor="#666633"><b><font color="#000000">Vital Statistics</font></b>
		</td>
	</tr>
	<tr>
		<td align="center" bgcolor="#999999">
</table>
<table width="100%" border="1" cellpadding="2" cellspacing="1" style="border-collapse: collapse;" id="AutoNumber1" bordercolor="#111111"> 
       </td>
	</tr>
	<tr>
          <td width="50%" align="right"><b><font color="#660033">Name:</font></b></td>
          <td width="50%"><input type="text" name="u_name"></td>
    </tr>
	<tr>
		<td width="50%" align="right"><b><font color="#660033">Location:</font></b></td>
		<td width="50%"><input type="text" name="location" value="<?php echo $location ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font color="#660033">Status:  </font></b></td>
		<td width="50%"><?php echo $statusselecthtml ?></td>
	</tr>
	<tr>
		<td width="50%"><p align="right"><font color="#660033"><b>Primary MOS:</b></font></td>
		<td width="50%"><input type="text" name="p_mos" value="<?php echo $p_mos ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font color="#660033">Combat Unit:</font></b></td>
		<td width="50%"><?php echo $unitselecthtml ?></td>
	</tr>
	<tr>
		<td width="50%"><p align="right"><font color="#660033"><b>Reports to:</b></font></td>
		<td width="50%"><input type="text" name="reports" value="<?php echo $reports ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font color="#660033">Position:</font></b></td>
		<td width="50%"><input type="text" name="position" value="<?php echo $position ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><font color="#660033"><b>Weapon:</b></font></td>
		<td width="50%"><?php echo $weaponselecthtml ?></td>
	</tr>
    <tr>
		<td width="50%" align="right"><b><font color="#660033">Enlisted Date:</font></b></td>
		<td width="50%"><input type="text" name="enlistment_dt" value="<?php echo $enlistment_dt ?>"/>
		<a href="javascript:showCal('addEnlistment');"><img src="modules/MILPACS/images/icon_calendar.gif" title="Select Date" alt="Select Date"></a>
		</td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font color="#660033">ICQ#:  </font></b></td>
		<td width="50%"><input type="text" name="icq" value="<?php echo $icq ?>"/></td>
	</tr>	
</table>
<br>

<input type="hidden" name="op" value="saveSoldier"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" class="button" align="center" value="Add"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>
