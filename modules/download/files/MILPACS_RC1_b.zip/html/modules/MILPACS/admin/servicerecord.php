 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net							*/
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Soldier Service Record                                */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "servicerecord.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

//Required Files
$module_name = basename(dirname(__FILE__));
@include_once("header.php");
@require_once("mainfile.php");
global $module_name, $db, $prefix;
	
$id = $_GET['id'];
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
	echo("<p>Error performing query: " . mysql_error() . "</p>");
	exit();
}
OpenTable();
echo "<p><a href=\"milpacs.php\">Return to Main Administration</a></p>";
?>
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="100%">
	<tr>
		<td align="center" bgcolor="#777777">
		<b><font color="#000000">Service Record of <?php echo $info[u_name] ?></font></b>
		</td>
	<tr>
		<td align="left" bgcolor="#666633">
		<b><font color="#000000">Personnel File</font></b>
		</td>
	</tr>
	<tr>	 
		<td align="left" bgcolor="#666633">
		<b><font color="#000000"><a href="milpacs.php?aop=addservicerecord&amp;id=<?php echo $id ?>" title="Add">Add Service Record</a></font></b>
		</td>
	</tr>
</table>
<table border="0" width="100%" cellpadding="3"><tr><th width="8%">Record Date</th><th width="30%"><b>Record Details</b></th></tr>
<?php
$sql = "SELECT record_id, date_format(sr.record_dt,'%e %b %Y') as record_dt, details FROM " . $prefix . "_milpacs_service_record sr WHERE sr.uniqueid = '$id'";
$result1 = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result1) ) {
	$record_id = $row["record_id"];	
	$date = $row["record_dt"];	
	$details = $row["details"];
	?>
	<tr>	 
		<td align="center" bgcolor="#999999"><?php echo $date ?> <a href="milpacs.php?aop=editservicerecord&amp;record_id=<?php echo $record_id ?>" title="Edit"><img src="./modules/MILPACS/images/pencil.gif"></a> <a href="milpacs.php?aop=delservicerecord&amp;record_id=<?php echo $record_id ?>" title="Delete"><img src="./modules/MILPACS/images/delete.png"></a></td>
		<td align="left" bgcolor="#999999"><textarea name="details" cols="85" colspan="1" rows="3"><?php echo $details ?></textarea></td>
	</tr>
	<?php
}
?>
</table>
<br>
<?php
CloseTable();
include("footer.php");
?>