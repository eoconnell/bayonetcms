<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Weapons                                          */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "editweapon.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

//Required Files
@require_once("mainfile.php");
@include_once("header.php");
global $module_name, $db, $prefix;

// Delete or Update values in weapons table
if ($op == "delWeapon") {
	$weapon_id = intval($_GET['id']);
	$result1 = $db->sql_query("SELECT weapon_id FROM " . $prefix . "_milpacs_weapons WHERE weapon_id ='$id'");
	$info = $db->sql_fetchrow($result1);
    $id = $info[weapon_id];
	$result2 = $db->sql_query("DELETE FROM " . $prefix . "_milpacs_weapons WHERE weapon_id ='$id'");
	Header("Location: /milpacs.php");
	die();
} else if ($op == "saveWeapon") {		
		$sql = "UPDATE " . $prefix . "_milpacs_weapons SET
			model = '$model',
			make = '$make',
			weapon_image = '$weapon_image',
			weapon_descr = '$weapon_descr',
			caliber = '$caliber',
			rounds = '$rounds',
			weight = '$weight',
			weapon_class = '$weapon_class',
			intro_dt = '$intro_dt',
			type_fire = '$type_fire',
			rate_fire = '$rate_fire',
			eff_range = '$eff_range',
			max_range = '$max_range'
		 WHERE weapon_id ='$id'";
		$result = $db->sql_query($sql);
		//echo "<META HTTP-EQUIV=\"refresh\" content=\"0;URL=milpacs.php\">";
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();		
	}
}
		
// Display page with values from the weapons table
if ($op != "saveWeapon") {
$id = intval($_GET['id']);
$result = $db->sql_query("SELECT weapon_id, model, make, weapon_image, weapon_descr, caliber, rounds, weight, weapon_class, intro_dt, type_fire, rate_fire, eff_range, max_range FROM " . $prefix . "_milpacs_weapons mw WHERE weapon_id ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
	} else {
		$weapon_image = $info[weapon_image];
		$model = htmlspecialchars($info[model]);
		$make = stripslashes($info[make]);
		$weapon_descr = stripslashes ($info[weapon_descr]);
		$caliber = stripslashes ($info[caliber]);
		$rounds = stripslashes ($info[rounds]);
		$weight = stripslashes ($info[weight]);
		$weapon_class = stripslashes ($info[weapon_class]);
		$intro_dt = stripslashes ($info[intro_dt]);
		$type_fire = stripslashes ($info[type_fire]);
		$rate_fire = stripslashes ($info[rate_fire]);
		$eff_range = stripslashes ($info[eff_range]);
		$max_range = stripslashes ($info[max_range]);
	}
}
		// Load Weapon image
	$urlofimages="$DOCUMENT_ROOT/modules/MILPACS/images/weapons/";
	$weaponselecthtml = "<select name=\"weapon_image\">";
	$weaponselecthtml .= "<option value=\"\">Select Weapon Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$weapon_image) {
					$weaponselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$weaponselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$weaponselecthtml .= "</select></td>";
	OpenTable();
	echo "<p><a href=\"milpacs.php\">Return to Main Administration</a></p>";

?>
<!-- Display Form -->
<form name="editweapon" action="milpacs.php?aop=editweapon" method="POST">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="100%"><tr>
		<td align="center" bgcolor="#777777"> Weapon image: <?php echo $weaponselecthtml ?></td>
	</tr> 
</table>
<table width="100%" border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#555555" bordercolor="#111111">
	<tr>
		<td height="25" colspan="2" align="left" bgcolor="#666633"><b><font color="#000000">Weapon Statistics</font></b></td>
	</tr>
	<tr>		
		<td width="30%"><p align="right"><font color="#660033"><b>Make:</b></font></td>
		<td width="70%"><input type="text" name="make" value="<?php echo $make ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Model:</b></font></td>
		<td width="70%"><input type="text" name="model" value="<?php echo $model ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Caliber:</b></font></td>
		<td width="70%"><input type="text" name="caliber" value="<?php echo $caliber ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Class:</b></font></td>
		<td width="70%"><input type="text" name="weapon_class" value="<?php echo $weapon_class ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Rounds:</b></font></td>
		<td width="70%"><input type="text" name="rounds" value="<?php echo $rounds ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Weight:</b></font></td>
		<td width="70%"><input type="text" name="weight" value="<?php echo $weight ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Introduced:</b></font></td>
		<td width="70%"><input type="text" name="intro_dt" value="<?php echo $intro_dt ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Type of Fire:</b></font></td>
		<td width="70%"><input type="text" name="type_fire" value="<?php echo $type_fire ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Rate of Fire:</b></font></td>
		<td width="70%"><input type="text" name="rate_fire" value="<?php echo $rate_fire ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Effective Range:</b></font></td>
		<td width="70%"><input type="text" name="eff_range" value="<?php echo $eff_range ?>"/></td>
	</tr>
	<tr>
		<td width="30%"><p align="right"><font color="#660033"><b>Maximum Range:</b></font></td>
		<td width="70%"><input type="text" name="max_range" value="<?php echo $max_range ?>"/></td>
	</tr>
	<tr>
	<td width="30%"><p align="right"><font color="#660033"><b>Decription:</b></font></td>
	<td width="70%"><p align="left"><textarea name="weapon_descr" cols="90" colspan="1" rows="9"><?php echo $weapon_descr ?></textarea></td>
	</tr>
</table>
<br>
<input type="hidden" name="op" value="saveWeapon"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Update"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>