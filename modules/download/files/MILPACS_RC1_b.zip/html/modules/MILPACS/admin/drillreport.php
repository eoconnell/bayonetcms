<?
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "drillreport.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

$drid = intval($drid);
// Load or save?
if ($op != "saveDrillReport") {
	// Load previously saved drill report from database
	if  ($drid > 0) {
		$sql = "SELECT drill_dt, drill_points, drill_news, drill_promotions, drill_assign, drill_tactic, drill_leader FROM " . $prefix . "_milpacs_drills WHERE drill_id = $drid";
		$row = $db->sql_fetchrow($db->sql_query($sql));
		$drill_dt = $row["drill_dt"]; 
		$drill_points = $row["drill_points"]; 
		$drill_news = $row["drill_news"]; 
		$drill_promotions = $row["drill_promotions"]; 
		$drill_assign = $row["drill_assign"]; 
		$drill_tactic = $row["drill_tactic"]; 
		$drill_leader = $row["drill_leader"]; 
		// Load drill status from table for edit
		$drillstatus = array();
		$sql = "SELECT uniqueid, status FROM " . $prefix . "_milpacs_drill_lkup WHERE drill_id = $drid";
		$result = $db->sql_query($sql);
		while ( $row = $db->sql_fetchrow($result) ) { 
			$uniqueid = $row["uniqueid"]; 
			$drillsts = $row["status"]; 
			$drillstatus[$uniqueid] = $drillsts; 
		}
	// Set defaults for adding new drill report
	} else {
//		$drill_dt = $row["drill_dt"];  = today??
	}
} else {
// Validate
   	$error = "";
//		foreach( $drillstatus as $uniqueid=>$drillsts){
//			echo "$uniqueid = $drillsts<br>";
//		}
//	$error = "TESTING";
// Passed validation, save
	if ($error == "") {
//		echo "$op<br><br>";
//		$email = addslashes($email);
		$drill_points = intval($drill_points);
		$bio = addslashes($bio);
		if ($drid > 0) {
			$sql = "UPDATE " . $prefix . "_milpacs_drills set
				drill_dt = '$drill_dt',
				drill_points = $drill_points,
				drill_news = '$drill_news',
				drill_promotions = '$drill_promotions',
				drill_assign = '$drill_assign',
				drill_tactic = '$drill_tactic',
				drill_leader = '$drill_leader'
				WHERE drill_id =$drid";
		} else {
			list($newest_drid) = $db->sql_fetchrow($db->sql_query("SELECT max(drill_id) AS newest_drid FROM ".$user_prefix."_milpacs_drills"));
			if ($newest_drid == "-1") { $drid = 1; } else { $drid = $newest_drid+1; }

		   $sql = "INSERT INTO " . $prefix . "_milpacs_drills (
				drill_id, 
				drill_dt, 
				drill_points, 
				drill_news, 
				drill_promotions, 
				drill_assign, 
				drill_tactic,
				drill_leader
				) VALUES (
				$drid,
				'$drill_dt',
				'$drill_points', 
				'$drill_news', 
				'$drill_promotions', 
				'$drill_assign', 
				'$drill_tactic',
				'$drill_leader'
				)";
		}
//		echo "$sql";
		$result = $db->sql_query($sql);
		$sql = "DELETE FROM " . $prefix . "_milpacs_drill_lkup where drill_id = $drid";
		$result = $db->sql_query($sql);
		foreach( $drillstatus as $uniqueid=>$drillsts){
			$uniqueid = intval($uniqueid);
			$drillsts = substr($drillsts,0,10);
			$sql = "INSERT INTO " . $prefix . "_milpacs_drill_lkup (drill_id, uniqueid, status) VALUES ($drid, $uniqueid, '$drillsts')";
			$result = $db->sql_query($sql);
		}
		echo "<META HTTP-EQUIV=\"refresh\" content=\"0;URL=modules.php?name=$module_name&op=drillreport&drid=$drid\">";
		exit();
	}
}
// Load members
$members = array();
$sql = "SELECT mm.uniqueid , mr.rank_abbr, mm.u_name, mm.promotion_dt, mm.position, mm.status FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.unit_id != '' AND mm.rank_id = mr.rank_id AND mm.status IN ('Active','LOA') ORDER BY mr.rank_id, mm.promotion_dt asc";
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) { 
	$uniqueid = $row["uniqueid"]; 
	$rank = $row["rank_abbr"]; 
	$u_name = $row["u_name"]; 
	$position = $row["position"]; 
	$status = $row["status"]; 
	$members[] = array("uniqueid" => $uniqueid, "u_name" => $u_name, "rank" => $rank, "position" => $position, "status" => $status);
}

?>
</div><div id="dropmsg6" class="dropcontent">
<br>
<?php
OpenTable();
if ($error != "")	echo "<center>$error</center>";
?>
<form name="drillreport" action="milpacs.php?aop=drillreport" method="POST">
<div align="center">
<label><H2>3rd ID Drill Report</H2></label>
<HR>
</div>
<br>
<p>
<strong>Drill Date: </strong>
<INPUT TYPE="text" NAME="drill_dt" size="20" value="<?php echo $drill_dt ?>">
<a href="javascript:showCal('DrillDate');"><img src="images/javascript/calendar.jpg" title='Select Date' alt='Select Date'></a>
&nbsp;&nbsp;<strong>Drill Leader: </strong>
<input type="text" size="30" maxlength="30" name="drill_leader" value="<?php echo $drill_leader ?>">
<br>
<br>
<label><strong>Post the Drill News:</strong></label>
<br>
<!-- <input type="text" size="120" maxlength="200" align="center" name="drill_news" value="<?php //echo $drill_news ?>"> -->
<textarea name="drill_news" cols="130" rows="2"><?php echo $drill_news ?></textarea>
<br>
<br>
<label><strong>Post any 3rd ID promotions:</strong></label>
<br>
<!-- <input type="text" size="120" maxlength="200" align="center" name="drill_promotions" value="<?php //echo $drill_promotions ?>"> -->
<textarea name="drill_promotions" cols="130" rows="2"><?php echo $drill_promotions ?></textarea>
<br>
<br>
<label><strong>Post any 3rd ID Assignments:</strong></label>
<br>
<!-- <input type="text" size="120" maxlength="200" align="center" name="drill_assign" value="<?php //echo $drill_assign ?>"> -->
<textarea name="drill_assign" cols="130" rows="2"><?php echo $drill_assign ?></textarea>
<br>
<br>
<label><strong>Post the tactics used at drills:</strong></label>
<br>
<!-- <input type="text" size="120" maxlength="200" align="center" name="drill_tactic" value="<?php //echo $drill_tactic ?>"> -->
<textarea name="drill_tactic" cols="130" rows="2"><?php echo $drill_tactic ?></textarea>
<br>
<br>
<br><p><strong>Take Attendance:</strong>
<table border=0 width='100%' cellpadding='5'><tr>
<table border=0 width='100%' cellpadding='3'><tr><th width='15%'>Drill Status</th><th width='5%'>Rank</th><th width='15%'><b>Name</b></th><th width='8%'>Position</th><th width='5%'>Status</th>
</tr>
</table>
<table border=0 width='100%' cellpadding='5'>
<?php

// Format drill detail HTML
foreach($members as $member){
	$uniqueid = $member["uniqueid"];
	$rank = $member["rank"];
	$u_name = $member["u_name"];
	$position = $member["position"];
	$status = $member["status"];
	$presentchecked = "";
	$absentchecked = "";
	$excusedchecked = "";
	if ($drillstatus[$uniqueid] == "Absent") { $absentchecked = "CHECKED"; }
	else if ($drillstatus[$uniqueid] == "Excused") { $excusedchecked = "CHECKED"; }
	else { $presentchecked = "CHECKED"; }
	?>
	<tr>
		<td align="center" width="15%">
			<INPUT TYPE="RADIO" NAME="drillstatus[<?php echo $uniqueid ?>]" VALUE="Present" <?php echo $presentchecked ?> > Present</INPUT>
			<INPUT TYPE="RADIO" NAME="drillstatus[<?php echo $uniqueid ?>]" VALUE="Absent" <?php echo $absentchecked ?> > Absent</INPUT>
			<INPUT TYPE="RADIO" NAME="drillstatus[<?php echo $uniqueid ?>]" VALUE="Excused" <?php echo $excusedchecked ?> > Excused</INPUT>
		</td>
		<td align="center" width="5%">
			<b><font color="#000000"><?php echo $rank ?></font></b>
		</td>
		<td align="center" width="15%">
			<b><font color="#000000"><?php echo $u_name ?></font></b>
		</td>
		<td align="center" width="8%">
			<b><font color="#000000"><?php echo $position ?></font></b>
		</td>
		<td align="center" width="5%">
			<b><font color="#000000"><?php echo $status ?></font></b>
		</td>
	</tr>
	<?php
}
?>
</table>
<input type="submit" align="center" name="Submit" value="Save"/>
<input type="hidden" name="op" value="saveDrillReport"/>
<input type="hidden" name="drid" value="<?php echo $drid ?>"/>
</form>
<?php
CloseTable();
?>
