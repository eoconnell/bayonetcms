<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Soldier Medal Record                              */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "addmedalrecord.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}
include_once("header.php");

if ($op == "addmedalrecord") {
	// Validations go here	
	$pid = intval($_POST['pid']);
	$award_id = intval($_POST['award_id']);
	$id = intval($_POST['id']);
	$award_dt = addslashes($_POST['award_dt']);
	$date = explode("-",$award_dt,3);
	$date[0] = intval($date[0]);
	$date[1] = intval($date[1]);
	$date[2] = intval($date[2]);
	if(checkdate($date[1],$date[2],$date[0])) {
		$dt_error = "";
		$dt_valid = true;
	} else {
		$dt_error = "Error: Date is invalid.  Please enter date in the yyyy-mm-dd format.";
		$dt_valid = false;
	}
	$adetails = addslashes($_POST['adetails']);
	if ($dt_valid) {		
			$sql = "INSERT INTO " . $prefix . "_milpacs_award_lkup (
				 pid, 
				 award_id, 
				 uniqueid, 
				 award_dt, 
				 adetails
				 ) VALUES (
				 null, 
				 $award_id, 
				 $id, 
				 '$award_dt', 
				 '$adetails'
				 )";	
		}
		$result = $db->sql_query($sql);	
		Header("Location: /milpacs.php?aop=medalrecord&id=$id");
}	
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
} else {
	$u_name = $info[u_name];
}
OpenTable();
echo "<p><a href=\"milpacs.php\">Return to Main Administration</a></p>";
?>
<form name="addmedalrecord" action="milpacs.php?aop=addmedalrecord" method="post">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="100%">
	<tr>
		<td align="center" bgcolor="#777777">
		<b><font color="#000000">Medal Record of <?php echo $u_name ?></font></b>
		</td>	
<table border=0 width="100%" cellpadding="3">
	<tr>
		<th width="40%">Medal Name</th>
		<th width="25%">Date of Award</th>
		<th width="35%"><b>Award Details</b></th>
	</tr>
	<tr>
		<td align="left" bgcolor="#999999">
		<select name="award_id" size="1">
		<option value="">--- Select Medal ---</option>
<?php
$result = $db->sql_query("SELECT award_id, award_name FROM " . $prefix . "_milpacs_awards");
while ( $row = $db->sql_fetchrow($result) ) {
	$award_name = $row["award_name"];
	$medal_id = $row["award_id"];
	if ($medal_id == $award_id) {
		echo "<option value='$medal_id'>$award_name</option>";
	} else {
		echo "<option value='$medal_id'>$award_name</option>";
	}
}
?>
		</select>
		</td>
		<td align="center" bgcolor="#999999">
		<input type="text" name="award_dt" value="<?php echo $award_dt ?>">
		<a href="javascript:showCal('AddMedalDate');"><img src="modules/MILPACS/images/icon_calendar.gif" title="Select Date" alt="Select Date"></a>
		<font style="color: red;"><?php echo $dt_error ?></font>
		</td>
		<td align="left" bgcolor="#999999">
		<textarea name="adetails" cols="30" colspan="1" rows="4"><?php echo $adetails ?></textarea>
		</td>
	</tr>
</table>
<br>
<input type="hidden" name="op" value="addmedalrecord"/>
<input type="hidden" name="pid" value="<?php echo $pid ?>"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Add"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>