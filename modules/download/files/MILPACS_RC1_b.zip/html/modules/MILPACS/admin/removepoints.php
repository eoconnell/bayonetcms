 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Remove Points                                            */
/*********************************************************/
if (stristr($_SERVER['SCRIPT_NAME'], "removepoints.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

$index = 0;

//finds the server's root directory
$self = dirname(__FILE__);
$nukemod = basename($self);
$rootdir = eregi_replace("/modules/$nukemod", "", $self);
require_once("mainfile.php");
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
global $module_name, $dbi, $prefix; 

	OpenTable();

if ($op == "savepoints") {
		// Validations go here		
		// If all validations passed, save and exit, otherwise, redisplay with errors
		//convert all the posts to variables:		
		$point_id = intval($_POST['point_id']);
		$point_dt = addslashes($_POST['point_dt']);		
		$points = intval($_POST['points']);
		$id = intval($_POST['id']);		
		$pdetails = $_POST['pdetails'];
		//Insert the values into the correct database with the right fields
		$result = $db->sql_query ("INSERT INTO " . $prefix . "_milpacs_points_lkup (pid, point_id, point_dt, points, uniqueid, pdetails)".
			"VALUES ('NULL','$point_id','$point_dt','$points', '$$id', '$pdetails')");		
		$result = $db->sql_query($sql);
		echo "<META HTTP-EQUIV=\"refresh\" content=\"0;URL=modules.php?name=MILPACS&file=points&id=$id\">";
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
}
} else {
    $id = intval($_GET['id']);		
		}    
?>	
<form name="removepoints" action="modules.php?name=MILPACS" method="post"> 
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="100%">
	<tr>
		<td align="center" bgcolor="#777777">
		<b><font color="#000000">Record points for this soldier.</font></b>
		</td>
	<tr>
		<td align="left" bgcolor="#666633">
		<b><font color="#000000">Remove Points</font></b>
		</td>
	</tr>
<table border=0 width="100%" cellpadding="3">
	<tr>
		<th width="20%">Reason for Action</th>
		<th width="20%">Point Value</th>
		<th width="25%">Date of Action</th>
		<th width="30%"><b>Details</b></th>
	</tr>
	<tr>
		<td align="center" bgcolor="#999999">
		<select name="point_id" size="1">
		<option value="">--- Select Action ---</option>
<?php
// Get values to populate combo box 
$result = $db->sql_query("SELECT point_id, point_class FROM " . $prefix . "_milpacs_points WHERE action = 'R'");
while ( $row = $db->sql_fetchrow($result) ) {
	$pclass = $row["point_class"];
	$point_id = $row["point_id"];
			echo "<option value=\"$point_id\">$pclass</option>";	
}
?>
		</select>
		</td>		
         <td align="left" valign="middle" bgcolor="#999999">Points:<br>
            <input type="radio" name="points" checked value=""> Other&nbsp;
			<input type="text" name="points" value="0" size="3"><br>
            <input type="radio" name="points" value="-1"> 1 Point<br>
            <input type="radio" name="points" value="-5"> 5 Points<br>
			<input type="radio" name="points" value="-10"> 10 Points<br>
			<input type="radio" name="points" value="-25"> 25 Points<br>
		</td>        
		<td align="center" bgcolor="#999999">
		<input type="text" name="point_dt" value="<?php echo $point_dt ?>">
		<a href="javascript:showCal('RemovePointDate');"><img src="images/javascript/calendar.jpg" title="Select Date" alt="Select Date"></a>
		<font style="color: red;"><?php echo $dt_error ?></font>
		</td>
		<td align="left" bgcolor="#999999">
		<textarea name="pdetails" cols="35" colspan="3" rows="3"><?php echo $pdetails ?></textarea>
		</td>
	</tr>
</table>
<br>
<input type="hidden" name="op" value="savepoints"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Remove"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>