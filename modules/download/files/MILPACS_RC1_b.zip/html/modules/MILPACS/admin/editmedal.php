<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Medal                                            */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "editmedal.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

//Required Files
require_once("mainfile.php");
include_once("header.php");

//Declare Globals
global $module_name, $db, $prefix;

//Update the values in the medal table
if ($op == "saveMedal") {	 
			$sql = "UPDATE " . $prefix . "_milpacs_awards SET award_name = '$award_name', award_description = '$award_description',	award_image = '$award_image', award_class = '$award_class' WHERE award_id = '$id'";
		$result = $db->sql_query($sql);
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	} 
}

// Display page with values from the awards table
if ($op != "saveMedal") {
		$id = intval($_GET['id']);
		$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_awards WHERE award_id ='$id'");
		$info = $db->sql_fetchrow($result);
		if (!$result) {
			echo("<p>Error performing query: " . mysql_error() . "</p>");
			exit();
		} else {
			$award_name = $info[award_name];
			$award_image = $info[award_image];
			$award_description = $info[award_description];
			$award_class = $info[award_class];			
		}
}

// Load Medal image
$urlofimages="$DOCUMENT_ROOT/modules/MILPACS/images/medals/";
$medalselecthtml = "<select name=\"award_image\">";
$medalselecthtml .= "<option value=\"\">Select Medal Image</option>";
if ($handle=@opendir($urlofimages)) { 
	while ($imgfile = readdir($handle)) {
		if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
			if ($imgfile==$award_image) {
				$medalselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
			} else {
				$medalselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
			}
		}
	}
	@closedir($handle);
}
$medalselecthtml .= "</select></td>";
OpenTable();
echo "<p><a href=\"milpacs.php\">Return to Main Administration</a></p>";

?>
<!-- Display Form -->
<form name="editmedal" action="milpacs.php?aop=editmedal" method="POST">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="100%">
<tr>
		<td align="center" bgcolor="#777777">
			<b><font color="#000000">3rd ID Medal <?php echo $award_name ?></font></b>
		</td>
		<tr>
			<td align="left" bgcolor="#666633">
			<b><font color="#000000">Medal Information</font></b>
		</td>
</tr>
<table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Medal Image</th><th width='40%'>Name of Medal</th><th width='20%'><b>Medal Details</b></th><th width='10%'><b>Medal Class</b></th></tr>
<tr>
		<td align="center" size="20" bgcolor="#999999"><?php echo $medalselecthtml ?>
		</td>
		<td align="center" bgcolor="#999999"><input type="text" size="50" name="award_name" value="<?php echo $award_name ?>"/>
		</td>
		<td align="center" bgcolor="#999999"><textarea name="award_description" cols="40" colspan="1" rows="4"><?php echo $award_description ?></textarea>
		</td>
		<!--<td align="center" bgcolor="#999999"><select NAME="award_class"><option value="<?php echo $award_class ?>"></select>				
<td align="center" bgcolor="#999999"><select name= <?php echo "$award_class" ?> size="1">
  <option value="IM">Individual Medal</option> 
  <option value="UC">Unit Citation</option>
  <option value="SB">Skill Badge</option>-->
<?php
$query = mysql_query ("SELECT award_class FROM " . $prefix . "_milpacs_awards WHERE award_id ='$id'") or die(mysql_error()); 
$row = mysql_fetch_object($query); 
echo '<td align="center" bgcolor="#999999"><select name="award_class">'; 
echo '<option'.($row->award_class=="IM"? ' selected' : '').'>Individual Medal</option>'; 
echo '<option'.($row->award_class=="UC"? ' selected' : '').'>Unit Citation</option>'; 
echo '<option'.($row->award_class=="SB"? ' selected' : '').'>Skill Badge</option>';  
echo '</select>';
echo '<td>';
?>
</tr>
</table>
<br>
<br>
<br>
<hr>
<input type="hidden" name="op" value="saveMedal"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Update"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>