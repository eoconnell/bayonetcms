<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Access Denied Page                                    */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "accessdenied.php")) {
    Header("Location: ../../../index.php");
    die();
}

$index = 0;
require_once("mainfile.php");
include_once("header.php");
global $module_name, $db, $prefix;
$module_name = basename(dirname(__FILE__));
echo "<META HTTP-EQUIV=\"refresh\" content=\"3;URL=milpacs.php\">";

OpenTable();
echo "<table border=\"2\" align=\"center\" cellpadding=\"4\" cellspacing=\"0\" style=\"border-collapse: collapse\" bgcolor=\"#000000\" bordercolor=\"#111111\" width=\"675\">"
  . "	  <tr>"
  . "         <td align=\"center\" bgcolor=\"#777777\"><b><font color=\"#000000\">Access Denied!!</font></b></td>"
  . "      </tr>"
  . "      <tr>"
  . "         <td align=\"center\" bgcolor=\"#777777\" valign=\"top\"><img border=\"0\" src=modules/MILPACS/images/classified1.gif></td>"
  . "      </tr>"      
  . "      </table>"; 
  CloseTable();
  include("footer.php");
  ?>