<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/
$index = 0;
require_once("mainfile.php");

global $module_name, $db, $prefix;
$module_name = basename(dirname(__FILE__));
//For combat report.  Set value for vWar table
//@include("includes/milpacs.inc.php");
if (stristr($_SERVER['SCRIPT_NAME'], "index.php")) {
    Header("Location: ../../index.php");
    die();
}

require_once("common.php");
if (milpacs_is_admin()) {

if (isset($op) AND ($op == "chpass")) {
	$pass = stripslashes(check_html(FixQuotes($_POST['pass'], "nohtml")));
	$pass2 = stripslashes(check_html(FixQuotes($_POST['pass2'], "nohtml")));

    if ($pass == $pass2) {
		$query = "UPDATE ".$prefix."_milpacs_pass SET pass = MD5('" . $pass . "') WHERE id = 'admin'";
		$result = $db->sql_query($query);
	    $_SESSION['pass'] = $pass;
    }

    Header("Location: milpacs.php");
    die();
} elseif (isset($op) AND ($op == "chpass2")) {
	$pass = stripslashes(check_html(FixQuotes($_POST['pass'], "nohtml")));
	$pass2 = stripslashes(check_html(FixQuotes($_POST['pass2'], "nohtml")));

    if ($pass == $pass2) {
		$query = "UPDATE ".$prefix."_milpacs_pass SET pass = MD5('" . $pass . "') WHERE id = 'user'";
		$result = $db->sql_query($query);
    }

    Header("Location: milpacs.php");
    die();
} elseif (isset($aop)) {
$aop = strtolower($aop);
switch($aop) {
    case "addmedal":
    case "addpoints":
    case "addrank":
    case "addsoldier":
    case "addunit":
    case "addweapon":
    case "editmedal":   
    case "editrank":        
    case "editsoldier":
    case "editsotm":
    case "editsubunit":
    case "editunit":
    case "editwar":
    case "editweapon":
    case "removepoints":
    case "servicerecord":
	case "editservice":	
	case "addservicerecord":
	case "editservicerecord":
	case "delservicerecord":
	case "medalrecord":
	case "addmedalrecord":
	case "editmedalrecord":
	case "delmedalrecord":
	case "adddrillreport":
	case "editdrillreport":	
    case "delsubunit":
	case "addsubunit":
	case "addadminunit":
	case "deladminunit":
    include_once($aop.".php");
    break;
}
} else {
    milpacs();
}

} elseif (isset($aop) AND ($aop == "accessdenied")) {
    include_once("accessdenied.php");
} elseif (isset($op) AND ($op == "login")) {
	$pass = stripslashes(check_html(FixQuotes($_POST['pass'], "nohtml")));
	$query = "SELECT * FROM ".$prefix."_milpacs_pass WHERE id = 'admin' AND pass = MD5('" . $pass . "')";		
	$result = $db->sql_query($query);
	if ($row = $db->sql_fetchrow($result)) {
       $_SESSION['loggedin'] = 1;
	   $_SESSION['pass'] = $pass;
	    Header("Location: milpacs.php");
    } else {
       $_SESSION['loggedin'] = 0;
	    Header("Location: milpacs.php?aop=accessdenied");
    }
    die();
} else {
   include_once("header.php");
   OpenTable();
   echo "<center><H1><strong>MILPACS Administration</strong></H1></center><br>";
   echo "<form action=\"milpacs.php\" method=\"post\">";
   echo "<input type=hidden name=\"op\" value=\"login\">";
   echo "<table align=\"center\"><tr><td>Password: </td><td><input type=password name=\"pass\"></td></tr>";
   echo "<tr><td colspan=2><center><input type=submit value=\"Login\"></center></td></tr></table></form>";
   CloseTable();
   include_once("footer.php");
}

###############################################################


function milpacs() {
global $db, $prefix, $module_name;
include_once("header.php");
@include_once("includes/meta.php");
@include_once("includes/javascript.php");
@include_once("includes/my_header.php");
?>
<!DOCTYPE HTML PUBLIC "-/W3C/DTD HTML 4.01 Transitional/EN">
<html>
<head>
<SCRIPT LANGUAGE="JavaScript" SRC="modules/MILPACS/js/switch.js"></SCRIPT>
</head>

<?php
OpenTable();
?>
<center><H1><strong>MILPACS 1.0 Administration </strong></H1></center><br>

<form name="dropmsgform">
<center>Administration Menu<br>
<select name="dropmsgoption" size="1" onChange="expandone()">
<option selected>Roster Manager</option>
<option>Combat Unit Manager</option>
<option>Admin Unit Manager</option>
<option>Sub Unit Manager</option>
<option>Medal Manager</option>
<option>Weapons Manager</option>
<option>Rank Manager</option>
<option>Attendance Manager</option>
<option>Combat Record Manager</option>
<option>Password Manager</option>
<option>Drill Report Manager</option>
</select></center>
</form><div id="dropmsg0" class="dropcontent">
<br>

<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
<H3><center>Roster Management</center></H3>
<HR>
<table border=0 width="100%" cellpadding="3"><tr><th width="5%">Rank</th><th width="10%">Name</th><th width="10%"><b>Main Info</b></th><th width="10%">Service Record</th><th width="10%">Medal Record</th><!--<th width="10%">Points</th>-->
<tr>
<?php
$sql = "SELECT mm.uniqueid, mm.unit_id, mr.rank_abbr, mm.u_name FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.rank_id = mr.rank_id AND mm.unit_id != '' AND mm.status IN ('Active','LOA') ORDER BY mm.rank_id ";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["uniqueid"];
	$rank = $row["rank_abbr"];
	$u_name = $row["u_name"];
	?>
	<tr>
		<td align="center" width="5%">
		<b><font color="#000000"><?php echo $rank ?></font></b>
		</td>
		<td align="center" width="15%">
		<b><font color="#000000"><?php echo $u_name ?></font></b>
		</td>
		<td align="center" width="10%"><a href="milpacs.php?aop=editsoldier&id=<?php echo $id ?>">Edit</a><p>
		</td>
		<td align="center" width="10%"><a href="milpacs.php?aop=servicerecord&id=<?php echo $id ?>">Edit</a><p>
		</td>
		<td align="center" width="10%"><a href="milpacs.php?aop=medalrecord&id=<?php echo $id ?>">Edit</a><p>
		</td>
		<!--<td align="center" width="10%"><a href="modules.php?name=MILPACS&file=points&id=<?php echo $id ?>">Edit</a><p>-->
	</tr>
	<?php
}
?>
</ul>
<p><a href="milpacs.php?aop=addsoldier">Add a new troop</a></p>
</table>
</form>

</div><div id="dropmsg1" class="dropcontent">
<br>
<form>
<H3><center>Combat Unit Management</center></H3>
<HR>
<p><a href="milpacs.php?aop=addUnit">Add a new Combat Unit!</a></p>
<table border=0 width="100%" cellpadding="3"><tr><th width="15%">Combat Unit</th><th width="15%">Name</th><th width="15%"><b>Edit</th><th width="15%"><b>Delete</b><tr>
<?php
$sql = "SELECT mu.unit_id, mu.unit_name, mu.unit_nick FROM " . $prefix . "_milpacs_units mu ORDER BY mu.unit_id ";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["unit_id"];
	$unit_name = $row["unit_name"];
	$unit_nick = $row["unit_nick"];
	?>
<tr>
<td align="center" width="15%"><b><font color="#000000"><?php echo $unit_name ?></font></b>
</td>
<td align="center" width="15%"><b><font color="#000000"><?php echo $unit_nick ?></font></b>
</td>
<td align="center" width="15%"><a href="milpacs.php?aop=editUnit&id=<?php echo $id ?>">Edit</a><p>
</tr>
<td align="center" width="15%"><a href="milpacs.php?aop=editunit&op=delUnit&id=<?php echo $id ?>">Delete</a><p>
</tr>
	<?php
}
?>
</table>
</form>


</div><div id="dropmsg2" class="dropcontent">
<br>
<form>
<H3><center>Admin Unit Management</center></H3>
<HR>
<p><a href="milpacs.php?aop=addadminunit">Add a New Administrative Unit!</a></p>
<table border=0 width="100%" cellpadding="3"><tr><th width="15%">Admin Unit</th><th width="15%"><b>Edit</th><th width="15%"><b>Delete</b><tr>
<?php
$sql = "SELECT mau.admin_unit_id, mau.admin_unit_name FROM " . $prefix . "_milpacs_adminunit mau ORDER BY mau.admin_unit_id ";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["admin_unit_id"];
	$adminunit_name = $row["admin_unit_name"];	
	?>
<tr>
<td align="center" width="15%"><b><font color="#000000"><?php echo $adminunit_name ?></font></b>
</td>
<td align="center" width="15%"><a href="milpacs.php?aop=editadminunit&id=<?php echo $id ?>">Edit</a><p>
</tr>
<td align="center" width="15%"><a href="milpacs.php?aop=deladminunit&id=<?php echo $id ?>">Delete</a><p>
</tr>
	<?php
}
?>
</table>
</form>

</div><div id="dropmsg3" class="dropcontent">
<br>

<form>
<H3><center>Sub Unit Management</center></H3>
<HR>
<p><a href="milpacs.php?aop=addsubunit">Add a new Sub Unit!</a></p>
<table border=0 width="100%" cellpadding="3"><tr><th width="15%">Sub Unit</th><th width="15%">Assigned To</th><th width="15%"><b>Edit</th><th width="15%"><b>Delete</b><tr>
<?php
$sql = "SELECT * FROM " . $prefix . "_milpacs_subunit msu, " . $prefix . "_milpacs_units mu WHERE msu.unit_id = mu.unit_id ORDER BY msu.subunit_id ";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["subunit_id"];
	$subunit_name = $row["subunit_name"];
	$unit_name = $row["unit_name"];
	?>
<tr>
<td align="center" width="15%"><b><font color="#000000"><?php echo $subunit_name ?></font></b>
</td>
<td align="center" width="15%"><b><font color="#000000"><?php echo $unit_name ?></font></b>
</td>
<td align="center" width="15%"><a href="milpacs.php?aop=editSubUnit&id=<?php echo $id ?>">Edit</a><p>
</tr>
<td align="center" width="15%"><a href="milpacs.php?aop=delsubunit&id=<?php echo $id ?>">Delete</a><p>
</tr>
	<?php
}
?>
</table>
</form>

</div><div id="dropmsg4" class="dropcontent">
<br>

<form>
<H3><center>Medal Management</center></H3>
<HR>
<p><a href="milpacs.php?aop=addMedal">Add a new medal!</a></p>
<table border=0 width="100%" cellpadding="3"><tr><th width="15%">Medal</th><th width="15%">Class</th><th width="15%"><b>Edit</th><th width="15%"><b>Delete</b><tr>
<?php
$sql = "SELECT ma.award_id, ma.award_name, ma.award_class FROM " . $prefix . "_milpacs_awards ma ORDER BY ma.award_id";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["award_id"];
	$award_name = $row["award_name"];
	$award_class = $row["award_class"];
	?>
	<tr>
		<td align="left" width="25%">
		<b><font color="#000000"><?php echo $award_name ?></font></b>
		</td>
		<td align="center" width="15%">
		<b><font color="#000000"><?php echo $award_class ?></font></b>
		</td>
		<td align="center" width="15%"><a href="milpacs.php?aop=editMedal&id=<?php echo $id ?>">Edit</a><p>	
	</tr>
	<td align="center" width="15%"><a href="milpacs.php?aop=editmedal&op=delMedal&id=<?php echo $id ?>">Delete</a><p>
	</tr>
	<?php
}
?>
</table>
</form>

</div><div id="dropmsg5" class="dropcontent">
<br>

<form> 
<H3><center>Weapon Management</center></H3>
<HR>
<p><a href="milpacs.php?aop=addWeapon">Add a new weapon!</a></p>
<table border=0 width="100%" cellpadding="3"><tr><th width="15%">Weapon</th><th width="15%">Make</th><th width="15%"><b>Edit</b><th width="15%"><b>Delete</b></th>
<?php
$sql = "SELECT mw.weapon_id, mw.model, mw.make FROM " . $prefix . "_milpacs_weapons mw ORDER BY mw.weapon_id";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["weapon_id"];
	$model = $row["model"];
	$make = $row["make"];
	?>
	<tr>
		<td align="center" width="25%">
		<b><font color="#000000"><?php echo $model ?></font></b>
		</td>
		<td align="center" width="15%">
		<b><font color="#000000"><?php echo $make ?></font></b>
		</td>
		<td align="center" width="15%"><a href="milpacs.php?aop=editWeapon&id=<?php echo $id ?>">Edit</a><p>	
	</tr>
	<td align="center" width="15%"><a href="milpacs.php?aop=editweapon&op=delWeapon&id=<?php echo $id ?>">Delete</a><p>
	</tr>
	<?php
}
?>
</table>
</form>

</div><div id="dropmsg6" class="dropcontent">
<br>

<form>
<H3><center>Rank Management</center></H3>
<HR>
<p><a href="milpacs.php?aop=addRank">Add a new Rank!</a></p>
<table border=0 width="100%" cellpadding="3"><tr><th width="15%">Rank Image</th><th width="15%">Rank Name</th><th width="15%"><b>Edit</b><tr>
<?php
$sql = "SELECT mr.rank_id, mr.rank_image, mr.rankname FROM " . $prefix . "_milpacs_ranks mr ORDER BY mr.rank_order";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["rank_id"];
//	$image = $row["rank_image"];
	$name = $row["rankname"];

	if ($row["rank_image"] =="") {
		$image = "&nbsp;"; 
	} else {
		$image = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 

	}
	?>
	<tr>
		<td align="center" width="15%">
		<b><font color="#000000"><?php echo $image ?></font></b>
		</td>
		<td align="center" width="15%">
		<b><font color="#000000"><?php echo $name ?></font></b>
		</td>
		<td align="center" width="15%"><a href="milpacs.php?aop=editRank&id=<?php echo $id ?>">Edit</a><p>	
	</tr>
	<?php
}
?>
</table>
</form>


</div><div id="dropmsg7" class="dropcontent">
<br>
<form name="attendTimeForm">
<H3><center>Attendance Management</center></H3>
<HR>
<p>Timeframe : <select name="attendTimeOption" size="1" onChange="expandTime()">
<option selected>Last 30 Days</option>
<option>Last 60 Days</option>
<option>Last 90 Days</option>
<option>Last 120 Days</option>
<option>All Drills</option>
</select></p>
</form>


<?php
$end = 4;	// NOTE: $i is how many months PLUS current month will be included in table... $end tells at what point to display all drills
for( $i=0; $i<=$end; $i++ ) {
	?>
	<div id="attendTime<?php echo $i ?>" class="dropcontent">
	<br>

	<table border=0 width="100%" cellpadding="3"><tr><th width="25%">Name</th><th width="10%"><b>Drills Available</b></th><th width="10%">Drills Attended</th><th width="10%">Drills Excused</th><th width="10%">Drills Absent</th><th width="10%">Attendance Record</th>
	<?php
	$sql = "SELECT mm.uniqueid, mm.unit_id, mm.u_name FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.rank_id = mr.rank_id AND mm.status IN ('Active','LOA','Medical LOA') ORDER BY mm.rank_id";
	$result = $db->sql_query($sql);
	while ( $row = $db->sql_fetchrow($result) ) {
		$u_name = $row["u_name"];
		$id2 = $row["uniqueid"];
		$drills_present = 0;
		$drills_excused = 0;
		$drills_absent = 0;
		$drills_available = 0;
		if ($i == $end)
			$sql2 = "SELECT mdlk.status FROM " . $prefix . "_milpacs_drill_lkup mdlk JOIN " . $prefix . "_milpacs_drills md WHERE mdlk.uniqueid = $id2 AND mdlk.drill_id = md.drill_id ORDER BY md.drill_dt";
		else
			$days = ($i + 1) * 30;
			$sql2 = "SELECT mdlk.status FROM " . $prefix . "_milpacs_drill_lkup mdlk JOIN " . $prefix . "_milpacs_drills md WHERE mdlk.uniqueid = $id2 AND mdlk.drill_id = md.drill_id AND DATE_SUB(CURDATE(),INTERVAL $days DAY) <= md.drill_dt ORDER BY md.drill_dt";
//			$sql2 = "SELECT mdlk.status FROM " . $prefix . "_milpacs_drill_lkup mdlk JOIN " . $prefix . "_milpacs_drills md WHERE mdlk.uniqueid = $id2 AND mdlk.drill_id = md.drill_id AND MONTH(md.drill_dt) >= (MONTH(NOW()) - $i) ORDER BY md.drill_dt";
		$result2 = $db->sql_query($sql2);
		while ( $row2 = $db->sql_fetchrow($result2) ) {
			$drills_available += 1;
			$status = $row2['status'];
			if ($status == 'Present')
				$drills_present += 1;
			else if ($status == 'Excused')
				$drills_excused += 1;
			else if ($status == 'Absent')
				$drills_absent += 1;
		}
		if ($drills_available <= 0)
			$per_attend = 0;
		else
			$per_attend = ($drills_present / $drills_available) * 100;
		settype($per_attend, 'integer');
		echo <<< _HTML_1_
		<tr>
			<td align="center" width="25%">
			<b><font color="#000000">$u_name</font></b>
			</td>
			<td align="center" width="10%">
			<b><font color="#000000">$drills_available</font></b>
			</td>
			<td align="center" width="10%"><font color="#00FF00">$drills_present</font>
			</td>
			<td align="center" width="10%"><font color="#FFFF00">$drills_excused</font>
			</td>
			<td align="center" width="10%"><font color="#FF0000">$drills_absent</font>
			</td>
			<td align="center" width="10%">$per_attend%
		</tr>
_HTML_1_;
	}
	?></table></div><?php
}
?>

</div><div id="dropmsg8" class="dropcontent">
<br>

<form> 
<H3><center>Combat Record Management</center></H3>
<HR>
<table border=0 width="100%" cellpadding="3"><tr><th width="15%">Combat Date</th><th width="15%">Enemy</th><th width="15%"><b>Edit</b><tr>
<?php
@include("modules/MILPACS/includes/milpacs.inc.php");
$sql = "SELECT v.warid, v.status, v.matchtypeid, v.dateline, vo.oppname, vo.oppid FROM vwar" . $n . " v INNER JOIN vwar" . $n . "_opponents vo WHERE v.oppid = vo.oppid AND v.status = 1 ORDER BY dateline DESC";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$warid = $row["warid"];
	$date = date("F j, Y", $row["dateline"]);
	$enemy = $row["oppname"];	
	?>
	<tr>
		<td align="left" width="15%">
		<b><font color="#000000"><?php echo $date ?></font></b>
		</td>
		<td align="center" width="25%">
		<b><font color="#000000"><?php echo $enemy ?></font></b>
		</td>
		<td align="center" width="15%"><a href="milpacs.php?aop=editwar&warid=<?php echo $warid ?>">Edit</a><p>
	</tr>
	<?php
}
?>
</table>
</form>

</div><div id="dropmsg9" class="dropcontent">
<br>

<H3><center>Password Management</center></H3>
<HR>
<table border=0 width="100%" cellpadding="3">
	<tr>	
		<td align="center" width="15%"><b>
<?
   echo "<center><strong>Change Admin Password</strong></center><br>";
   echo "<form action=\"milpacs.php\" method=\"post\">";
   echo "<input type=hidden name=\"op\" value=\"chpass\">";
   echo "<table align=\"center\"><tr><td>Password: </td><td><input type=password name=\"pass\"></td></tr>";
   echo "<tr><td>Retype Password: </td><td><input type=password name=\"pass2\"></td></tr>";
   echo "<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr></table></form>";


   echo "<center><strong>Change Drill Report Password</strong></center><br>";
   echo "<form action=\"milpacs.php\" method=\"post\">";
   echo "<input type=hidden name=\"op\" value=\"chpass2\">";
   echo "<table align=\"center\"><tr><td>Password: </td><td><input type=password name=\"pass\"></td></tr>";
   echo "<tr><td>Retype Password: </td><td><input type=password name=\"pass2\"></td></tr>";
   echo "<tr><td colspan=2><center><input type=submit value=\"Update\"></center></td></tr></table></form>";
?>
		</td>			
	</tr>	
</table>

</div><div id="dropmsg10" class="dropcontent">
<br>

<form> 
<H3><center>Drill Report Manager</center></H3>
<HR>
<table border=0>
<tr>
<td><a href="milpacs.php?aop=adddrillreport"><img src="modules/MILPACS/images/add_drill.gif" alt="Add Drill Report" title="Add Drill Report"></a>
</td>
</tr></table>
<form>
<table border=0 width='100%' cellpadding='5'><tr>
<table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Drill Date</th><th width='20%'>Edit Drill
</th></tr>
<?php
// create the SQL statement
$sql = "SELECT drill_id, drill_dt FROM " . $prefix . "_milpacs_drills ORDER BY drill_dt DESC";
//fill the table with values from drill table
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	list($Year,$Month,$Day) = split('-',$drill_dt);
    $formatdrilldate = date("F j, Y",mktime(12,0,0,$Month,$Day,$Year));
	?>
	<td class='row1' width='20%' class='row1' align='center'><?php echo $formatdrilldate ?></td><td class='row1' width='20%' align='center'><a class="mainroster" href="milpacs.php?aop=editdrillreport&amp;drill_id=<?php echo $drill_id ?>">Click here to edit!</a>			
	</td></tr>
	<?php
}
?>
</table>
</form>
<?php
CloseTable();
?>
</body>
</html>
<?php
include_once("footer.php");
}
//@include_once("footer.php");
?>