<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Unit                                             */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "editunit.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

//Required Files
require_once("mainfile.php");
include_once("header.php");
global $module_name, $db, $prefix;

// Delete or Update values in unit table
if ($op == "delUnit") {
	$unit_id = intval($_GET['id']);
	$result1 = $db->sql_query("SELECT unit_id FROM " . $prefix . "_milpacs_units WHERE unit_id ='$id'");
	$info = $db->sql_fetchrow($result1);
    $id = $info[unit_id];
	$result2 = $db->sql_query("DELETE FROM " . $prefix . "_milpacs_units WHERE unit_id ='$id'");
	Header("Location: /milpacs.php");
	die();
} else if ($op == "saveUnit") {		
		$sql = "UPDATE " . $prefix . "_milpacs_units SET
			unit_name = '$unit_name',
			unit_order = '$unit_order',
			unit_image = '$unit_image',
			unit_nick = '$unit_nick',
			unit_creed = '$unit_creed',
			unit_motto = '$unit_motto',
			unit_goal_one = '$unit_goal_one',
			unit_goal_two = '$unit_goal_two',
			unit_goal_three = '$unit_goal_three',
			unit_bio = '$unit_bio'			
		 WHERE unit_id ='$id'";
		$result = $db->sql_query($sql);
		//echo "<META HTTP-EQUIV=\"refresh\" content=\"0;URL=milpacs.php\">";
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();		
	}
}
		
// Display page with values from the unit table
if ($op != "saveUnit") {
$id = intval($_GET['id']);
$result = $db->sql_query("SELECT unit_name, unit_id, unit_order, unit_image, unit_nick, unit_creed, unit_motto, unit_goal_one, unit_goal_two, unit_goal_three, unit_bio  FROM " . $prefix . "_milpacs_units mu WHERE unit_id ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
	} else {
		$unit_name = stripslashes($info[unit_name]);		
		$unit_image = $info[unit_image];
		$unit_order = $info[unit_order];
		$unit_nick = htmlspecialchars($info[unit_nick]);
		$unit_creed = stripslashes($info[unit_creed]);
		$unit_motto = stripslashes ($info[unit_motto]);
		$unit_goal_one = stripslashes ($info[unit_goal_one]);
		$unit_goal_two = stripslashes ($info[unit_goal_two]);
		$unit_goal_three = stripslashes ($info[unit_goal_three]);
		$unit_bio = stripslashes ($info[unit_bio]);
	}
}

// Load Unit image
$urlofimages="$DOCUMENT_ROOT/modules/MILPACS/images/units/";
$unitselecthtml = "<select name=\"unit_image\">";
$unitselecthtml .= "<option value=\"\">Select Unit Image</option>";
if ($handle=@opendir($urlofimages)) { 
	while ($imgfile = readdir($handle)) {
		if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
			if ($imgfile==$unit_image) {
				$unitselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
			} else {
				$unitselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
			}
		}
	}
	@closedir($handle);
}
$unitselecthtml .= "</select></td>";
OpenTable();
echo "<p><a href=\"milpacs.php\">Return to Main Administration</a></p>";
?>
<!-- Display Form -->
<form name="editunit" action="milpacs.php?aop=editunit" method="POST">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="100%"><tr>
         <td align="center" bgcolor="#777777"><b><font color="#000000">Combat Unit Profile of <?php echo $unit_name ?></font></b>
         </td>
       </tr>
	   <tr>
         <td align="center" bgcolor="#777777"> Unit Name: <input type="text" name="unit_name" value="<?php echo $unit_name ?>">
         </td>
      </tr>
		<tr>
         <td align="center" bgcolor="#777777"> Unit Image: <?php echo $unitselecthtml ?>
         </td>
      </tr>
		<tr>
         <td align="center" bgcolor="#777777"> Unit Call Sign: <input type="text" name="unit_nick" value ="<?php echo $unit_nick ?>">
         </td>
      </tr>
	  <tr>
         <td align="center" bgcolor="#777777"> Unit Order: <input type="text" name="unit_order" value ="<?php echo $unit_order ?>">
         </td>
      </tr>
      <tr>
			<td align="center" bgcolor="#666633"><b><font color="#000000">Unit Creed</font></b>
			</td>
      </tr>
      <tr>
			<td align="center" bgcolor="#999999"><textarea name="unit_creed" cols="130" colspan="1" rows="4"><?php echo $unit_creed ?></textarea>
			 </td>
		</tr>
      <tr>
      <tr>
			<td align="center" bgcolor="#666633"><b><font color="#000000">Unit Motto</font></b>
			</td>
      </tr>
      <tr>
			<td align="center" bgcolor="#999999"><textarea name="unit_motto" cols="130" colspan="1" rows="4"><?php echo $unit_motto ?></textarea>
			 </td>
		</tr>
      <tr>
			<td align="center" bgcolor="#666633"><b><font color="#000000">Unit Goals</font></b>
			</td>
      </tr>
      <tr>
			<td align="center" bgcolor="#999999"><textarea name="unit_goal_one" cols="130" colspan="1" rows="2"><?php echo $unit_goal_one ?></textarea>
			 </td>
		</tr>
      <tr>
			<td align="center" bgcolor="#999999"><textarea name="unit_goal_two" cols="130" colspan="1" rows="2"><?php echo $unit_goal_two ?></textarea>
			 </td>
		</tr>
      <tr>
			<td align="center" bgcolor="#999999"><textarea name="unit_goal_three" cols="130" colspan="1" rows="2"><?php echo $unit_goal_three ?></textarea>
			 </td>
		</tr>
      <tr>
			<td align="center" bgcolor="#666633"><b><font color="#000000">Unit Bio</font></b>
			</td>
      </tr>
      <tr>
			<td align="center" bgcolor="#999999"><textarea name="unit_bio" cols="130" colspan="1" rows="4"><?php echo $unit_bio ?></textarea>
			 </td>
		</tr>
		</table>
<br>
<input type="hidden" name="op" value="saveUnit"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Update"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>