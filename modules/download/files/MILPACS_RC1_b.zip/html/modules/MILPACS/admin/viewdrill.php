<?php

/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* View Drill                                            */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "viewdrill.php")) {
    Header("Location: ../../index.php");
    die();
}
require_once("common.php");

if (!milpacs_is_user())
{
    Header("Location: modules.php?name=MILPACS&file=checkuser");
}

$index=0;
@require_once("mainfile.php");
//finds the server's root directory
$self = dirname(__FILE__ );
$nukemod = basename($self);
$rootdir = eregi_replace("/modules/$nukemod", "", $self);
global $module_name, $db, $prefix;
$module_name = basename(dirname(__FILE__ ));
@include_once("header.php");
OpenTable();
?>
<style type="text/css"><!--
p.content		{ font-size: 12px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF;}
h1 {text-align: center}
--></style>
<table border=0><tr><td width=100%>
<font class="mainroster"><big><b>[3rd ID] Drill Page</b></big></font><hr width=200 align="left">
</td></tr></table>
<form name="viewdrill" method="post" action="modules.php?name=MILPACS&file=drillreport">
<?php
CloseTable();
OpenTable();
?>
<table border=0 width='100%' cellpadding='5'><tr>
<table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Drill Date</th><th width='20%'><b>Drill Leader</b></th><th width='20%'>View Drill
		&nbsp;<a href="modules.php?name=MILPACS&aop=makedrillreport"><img src="modules/<?php echo $module_name ?>/images/add.gif" alt="Add Drill Report" title="Add Drill Report"></a>
</th></tr>
<?php
// create the SQL statement
$sql = "SELECT drill_id, drill_dt, drill_leader FROM " . $prefix . "_milpacs_drills ORDER BY drill_dt DESC";
//fill the table with values from drill table
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	list($Year,$Month,$Day) = split('-',$drill_dt);
    $formatdrilldate = date("F j, Y",mktime(12,0,0,$Month,$Day,$Year));
	?>
	<td class='row1' width='20%' class='row1' align='center'><?php echo $formatdrilldate ?></td><td width='20%' class='row1' align='center'><?php echo $drill_leader ?></td><td class='row1' width='20%' align='center'><a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=drillreport&amp;drill_id=<?php echo $drill_id ?>">Click Here!</a>
			&nbsp;<a href="modules.php?name=MILPACS&aop=editdrillreport&drid=<?php echo $drill_id ?>"><img src="modules/<?php echo $module_name ?>/images/pencil.gif" alt="Edit Drill Report" title="Edit Drill Report"></a>	
	</td></tr>
	<?php
}
?>
</table><br/><hr noShade>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>