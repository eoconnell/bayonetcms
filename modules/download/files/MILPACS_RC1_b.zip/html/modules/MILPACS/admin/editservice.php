<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Service Record                                   */
/*********************************************************/


if (stristr($_SERVER['SCRIPT_NAME'], "editservice.php")) {
    Header("Location: ../../index.php");
    die();
}
include_once("common.php");
if (!milpacs_is_admin()) {
   Header("Location: /milpacs.php");
}

include_once("header.php");
OpenTable();
if ($op == "delservice") {
	$record_id = intval($_GET['record_id']);
	$result1 = $db->sql_query("SELECT uniqueid FROM " . $prefix . "_milpacs_service_record WHERE record_id ='$record_id'");
	$info = $db->sql_fetchrow($result1);
    $id = $info[uniqueid];
	$result2 = $db->sql_query("DELETE FROM " . $prefix . "_milpacs_service_record WHERE record_id ='$record_id'");
	Header("Location: /modules.php?name=MILPACS&file=servicerecord&id=$id");
	die();
} else if ($op == "saveservice") {
	// Validations go here
	// If all validations passed, save and exit, otherwise, redisplay with errors
	$record_id = intval($_POST['record_id']);
	$id = intval($_POST['id']);
	$record_dt = addslashes($_POST['record_dt']);
	$date = explode("-",$record_dt,3);
	$date[0] = intval($date[0]);
	$date[1] = intval($date[1]);
	$date[2] = intval($date[2]);
	if(checkdate($date[1],$date[2],$date[0])) {
		$dt_error = "";
		$dt_valid = true;
	} else {
		$dt_error = "Error: Date is invalid.  Please enter date in the yyyy-mm-dd format.";
		$dt_valid = false;
	}
	$details = addslashes($_POST['details']);
	if ($dt_valid) {
		if ($record_id == 0) {
			$sql = "INSERT INTO " . $prefix . "_milpacs_service_record (
				 record_id, 
				 uniqueid, 
				 record_dt, 
				 details
				 ) VALUES (
				 null, 
				 $id, 
				 '$record_dt', 
				 '$details'
				 )";
		} else {
			$sql = "UPDATE " . $prefix . "_milpacs_service_record set
				record_dt = '$record_dt',
				details = '$details'
			 WHERE record_id = '$record_id'";
		}
		$result = $db->sql_query($sql);
		echo "<META HTTP-EQUIV=\"refresh\" content=\"0;URL=modules.php?name=MILPACS&file=servicerecord&id=$id\">";
	} else {
		if ($record_id == 0) {
			$sql = "INSERT INTO " . $prefix . "_milpacs_service_record (
				 record_id, 
				 uniqueid, 
				 details
				 ) VALUES (
				 null, 
				 $id, 
				 '$details'
				 )";
		} else {
			$sql = "UPDATE " . $prefix . "_milpacs_service_record set
				details = '$details'
			 WHERE record_id = '$record_id'";
		}
		$result = $db->sql_query($sql);
	}
} else {
	$record_id = intval($_GET['record_id']);
	$id = intval($_GET['id']);
}

if ($record_id > 0) {
	$result = $db->sql_query("SELECT uniqueid, record_dt, details FROM " . $prefix . "_milpacs_service_record WHERE record_id ='$record_id'");
	$info = $db->sql_fetchrow($result);
    if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	} else {
		$id = $info[uniqueid];
		$record_dt = $info[record_dt];
		$details = $info[details];
   }
}

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
} else {
	$name = $info[name];
}
?>
<br><br><form name="editservice" action="milpacs.php?aop=editservice" method="post">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#666633" bordercolor="#111111" width="100%">
	<tr>
		<td colspan=2 align="center" bgcolor="#777777">
		<b><font color="#666633">Service Record for <?php echo $name ?></font></b>
		</td>
	</tr>
	<tr>
		<td width="50%" align="right">
		<b><font color="#999999">Record Date:</font></b>
		</td>
		<td width="50%">
		<input type="text" name="record_dt" value="<?php echo $record_dt ?>">
		<a href="javascript:showCal('ServiceRecord');"><img src="images/javascript/calendar.jpg" title="Select Date" alt="Select Date"></a>
		<font style="color: red;"><?php echo $dt_error ?></font>
		</td>
	</tr>
	<tr>
		<td width="50%" align="right">
		<b><font color="#999999">Details:</font></b>
		</td>
		<td width="50%">
		<textarea name="details" cols="60" colspan="1" rows="4"><?php echo $details ?></textarea>
		</td>
	</tr>
	<tr>
</table>
<br>
<input type="hidden" name="op" value="saveservice"/>
<input type="hidden" name="record_id" value="<?php echo $record_id ?>"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Update"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>