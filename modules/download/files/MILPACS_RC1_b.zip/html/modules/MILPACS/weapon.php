<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Weapons page                                          */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "weapon.php")) {
    Header("Location: ../../index.php");
    die();
}

//Required Files
$module_name = basename(dirname(__FILE__));
@include_once("header.php");
@require_once("mainfile.php");
global $module_name, $db, $prefix;
get_lang($module_name);

OpenTable();
echo"<style type=\"text/css\"><!--"
  . ".mainrosterbig		{ font-size: 13px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF; font-weight:bold; }"
  . ".mainroster		{ font-size: 10.5px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF; font-weight:bold; }"
  . "a.mainroster,a.mainroster:visited		{ color: #FFFFFF; text-decoration: none;}"
  . "a.mainroster:hover { color:#FEFEFE; text-decoration: underline;}"
  . "--></style>"
  . "<table border=0><tr><td width=100%>"
  . "<font class=\"mainroster\"><big><b>Arsenal of the "._MILPACS_UNIT."</b></big></font><hr width=200 align=\"left\">"
  . "</td></tr></table>"
 .""
 ."<br>";
CloseTable();
OpenTable();
//returns all weapons in the weapon table
?>
<table border=0 width='100%' cellpadding='5'><tr>
<table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Make</th><th width='20%'><b>Model</b></th><th width='20%'>Caliber</th><th width='20%'>Class</th>
</tr>
<?php
$sql = "SELECT * FROM " . $prefix . "_milpacs_weapons ORDER BY weapon_id";
//fill the table with values from weapon table
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);  
	?>  
	<td class='row1' width='20%' align='center'><a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=weaponprofile&amp;weapon_id=<?php echo $weapon_id ?>"><?php echo $make ?></a><td class='row1' width='20%' class='row1' align='center'><?php echo $model ?></td><td width='20%' class='row1' align='center'><?php echo $caliber ?></td><td width='20%' class='row1' align='center'><?php echo $weapon_class ?></td>
	</tr>
	<?php
}
echo "</table><br/><hr noShade>";
CloseTable();
@include_once("footer.php");
?>