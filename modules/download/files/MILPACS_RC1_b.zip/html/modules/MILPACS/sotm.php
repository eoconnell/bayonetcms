<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Soldier of the Month                                  */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "sotm.php")) {
    Header("Location: ../../index.php");
    die();
}
$index=0;
@require_once("mainfile.php");
//finds the server's root directory
$self = dirname(__FILE__);
$nukemod = basename($self);
$rootdir = eregi_replace("/modules/$nukemod", "", $self);

global $module_name, $db, $prefix;
$module_name = basename(dirname(__FILE__));
@include_once("header.php");
OpenTable();
?>
<style type="text/css"><!--
.mainrosterbig		{ font-size: 13px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF; font-weight:bold; }
.mainroster		{ font-size: 10.5px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF; font-weight:bold; }
a.mainroster,a.mainroster:visited		{ color: #FFFFFF; text-decoration: none;}
a.mainroster:hover { color:#FEFEFE; text-decoration: underline;}
--></style>
<style type="text/css"><!--
p.content		{ font-size: 12.5px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF;}
--></style>
<?php
$uniqueid = $_GET['uniqueid'];
$result = $db->sql_query("SELECT mm.uniqueid, mm.name, mr.rank_abbr, sotm.citation, sotm.criteria, sotm.plaque FROM " . $prefix . "_milpacs_members mm, " . $prefix . "_milpacs_ranks mr, " . $prefix . "_milpacs_sotm sotm WHERE mm.uniqueid = sotm.uniqueid AND mr.rank_id = mm.rank_id");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}
?>

<table border=0><tr><td width=100%>
<font class="mainroster"><big><b>3rd Infantry Division Soldier of the Month</b></big></font><hr width=600 align="left">
</td></tr>
<tr><td width=100%>
<font class="mainroster"><big><b>Criteria:</b></big></font><hr width=600 align="left">
</td></tr>
<tr><td width=100%>
<font class="mainroster"><big><b><?php echo $info[criteria] ?></b></big></font><hr width=600 align="left">
</td></tr>
</table>

<table border="2" cellpadding="4" cellspacing="0" style="border-collapse: collapse" bgcolor="#000000" bordercolor="#111111" width="675">  <tr>
         <td align="center" bgcolor="#777777">
            <b><font class="mainroster"><big><b>3rd Infantry Division Soldier of the Month</b></big></font></b>
         </td>
		  </tr>     <tr>
         <td align="center" bgcolor="#777777">
            <b><font class="mainroster"><big><b>is awarded to <?php echo $info[rank_abbr] .' '. $info[name] ?></b></big></font>
         </td>
         </tr>     <tr>
         <td align="center" bgcolor="#777777" valign="top">
            <img border="0" src="modules/MILPACS/images/sotm/<?php echo $info[plaque] ?>">
         </td>
         </tr>    <tr>
         <td align="center" bgcolor="#757575">
            <b><font color="#000000">Citation</font></b>
         </td>
      </tr>      <tr>
         <td align="center" bgcolor="#999999">
            <p class="content"><?php echo $info[citation] ?>
         </td>   </tr>
   </table>
<?php
CloseTable();
@include_once("footer.php");
?>