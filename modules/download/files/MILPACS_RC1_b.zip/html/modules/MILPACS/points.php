 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Points                                           */
/*********************************************************/
if (!eregi("modules.php", $PHP_SELF)) {
	die ("You can't access this file directly...");
    }

//if (stristr($_SERVER['SCRIPT_NAME'], "points.php")) {
//    Header("Location: ../../index.php");
//    die();
//}
if (!in_groups('1-10-23')) {
	// Not authorized
	echo "<META HTTP-EQUIV=\"refresh\" content=\".1;URL=modules.php?name=MILPACS&file=accessdenied\">";
	echo "<a href=\"modules.php?name=MILPACS&file=accessdenied\">";
	exit();
}
$index = 0;

//finds the server's root directory
$self = dirname(__FILE__);
$nukemod = basename($self);
$rootdir = eregi_replace("/modules/$nukemod", "", $self);
@require_once("mainfile.php");	// added @
@include_once("header.php");	// added @ and _once
$module_name = basename(dirname(__FILE__));
global $module_name, $db, $prefix; 

OpenTable();
$id = $_GET['id'];
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_points_lkup lkup JOIN " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}
echo "<table border=\"2\" cellpadding=\"2\" align =\"center\" cellspacing=\"0\" style=\"border-collapse: collapse\" bgcolor=\"#000000\" bordercolor=\"#111111\" width=\"100%\"><tr>"
  . "         <td align=\"center\" bgcolor=\"#777777\">"
  . "            <b><font color=\"#000000\">Points for $info[name]</font></b>"
  . "         </td>"
  . "       <tr>"
  . "			<td align=\"left\" bgcolor=\"#666633\">"
  . "			 <b><font color=\"#000000\">Detailed point record showing points awarded or removed.</font></b>"
  . "			</td>"
  . "		</tr>";
echo "<table border=0 width='100%' cellpadding='3'><tr><th width='25%'>Reason for Action</th><th width='10%'>Date of Action</th><th width='10%'>Points Awarded/Removed</th><th width='35%'><b>Details</b></th></tr>";  
	
$sql = "SELECT lkup.pid, lkup.pdetails, mp.point_class, lkup.points, lkup.point_dt, lkup.uniqueid FROM " . $prefix . "_milpacs_points_lkup lkup, " . $prefix . "_milpacs_points mp WHERE lkup.uniqueid ='$id' AND mp.point_id = lkup.point_id ORDER BY lkup.point_dt DESC";
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	$class = $row["point_class"];	
	$point_id = $row["point_id"];
	$date = $row["point_dt"];	
	$pdetails = $row["pdetails"];
	$points = $row["points"];	
	list($Year,$Month,$Day) = split('-',$date);
    $formatpointdate = date("F j, Y",mktime(12,0,0,$Month,$Day,$Year));

	echo "		<tr>";
	echo "			<td align=\"center\" bgcolor=\"#777777\">$class</td>";
	echo "			<td align=\"center\" bgcolor=\"#777777\">$formatpointdate</td>";
	echo "          <td align=\"center\" bgcolor=\"#777777\">$points</td>";
	echo "          <td align=\"center\" bgcolor=\"#777777\">$pdetails</td>";
	echo "      </tr>";
}

echo		 "</table>";
echo		"<br>";
echo "<b><font color=\"#000000\"><a href=modules.php?name=$module_name&amp;&op=addpoints&amp;id=$id title=\"Add\">Add Points</a></font></b>";
echo		"<br>";
echo "<b><font color=\"#000000\"><a href=modules.php?name=$module_name&amp;&op=removepoints&amp;id=$id title=\"Remove\">Remove Points</a></font></b>";
CloseTable();
include("footer.php");
?>