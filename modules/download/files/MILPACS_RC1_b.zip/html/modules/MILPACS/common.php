<?
if (stristr($_SERVER['SCRIPT_NAME'], "common.php")) {
    Header("Location: ../index.php");
    die();
}

session_start();

function milpacs_is_user()
{
    global $db, $prefix;

	if (isset($_SESSION['loggedin1']) AND $_SESSION['loggedin1'] == 1 AND !empty($_SESSION['password']))
    {
	    $pass11 = stripslashes(check_html(FixQuotes($_SESSION['password'], "nohtml")));
		$query = "SELECT * FROM ".$prefix."_milpacs_pass WHERE id = 'user' AND pass = MD5('" . $pass11 . "')";
		$result = $db->sql_query($query);
		if ($row = $db->sql_fetchrow($result)) {
           return true;
        } else {
           return false;
        }
    } else {
       return false;
    }
}
?>