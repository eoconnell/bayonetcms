<?php

/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/
/*********************************************************/
/* Login Script                                          */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "logindrill.php")) {
    Header("Location: ../../index.php");
    die();
}
$index = 0;
require_once("mainfile.php");
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
global $module_name, $db, $prefix;
OpenTable();
// we must never forget to start the session
session_start();
?>
<html>
<head>
<title>Basic Login</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head> 
<body>
<?php
if ($errorMessage != '') {
?>
<p align="center"><strong><font color="#990000"><?php echo $errorMessage; ?></font></strong></p>
<?php
}
?>
<form name="logindrill" action="modules.php?name=<?php echo $module_name ?>" method="post">
<table width="600" border="0" align="center" cellpadding="2" cellspacing="2">
<tr>
<td colspan=2 align="center" bgcolor="#666633"><b><font color="#000000">Enter the 3rd ID Drill Password.  This password is posted in the Barracks</td>
</tr>
<tr>
<td><input name="txtPassword" align="center" type="password" id="txtPassword"></td>
</tr>
<tr>
<td><input type="submit" name="btnLogin" align="center" value="Login"></td>
</tr>
</table>
</form>
</body>
</html>
<?php
$errorMessage = '';
if (isset($_POST['txtPassword'])) {   
   
   $password = $_POST['txtPassword'];

   // check if the password exist in database
   $sql = "SELECT drillpass FROM " . $prefix . "_milpacs_main WHERE drillpass = PASSWORD('$password')";

   $result = mysql_query($sql) 
             or die('Query failed. ' . mysql_error()); 

   if (mysql_num_rows($result) == 1) {
      // the password match, 
      // set the session
	  $_SESSION['password'] = $password;      

      // after login we move to the drillpage      
	  Header("Location: /modules.php?name=MILPACS&file=drillreport");
      exit;
   } else {
      $errorMessage = 'Sorry, wrong password';
   }
}
CloseTable();
@include_once("footer.php");
?>