<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "roster.php")) {
    Header("Location: ../index.php");
    die();
}

//Required Files
@require_once("mainfile.php");
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
@get_lang($module_name);
global $module_name, $db, $prefix;
$index = 0;

OpenTable();
echo"<style type=\"text/css\"><!--"
  . ".mainrosterbig	{ font-size: 13px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF; font-weight:bold; }"
  . ".mainroster		{ font-size: 10.5px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF; font-weight:bold; }"
  . "a.mainroster,a.mainroster:visited		{ color: #FFFFFF; text-decoration: none;}"
  . "a.mainroster:hover { color:#FEFEFE; text-decoration: underline;}"
  . "--></style>"
  . "<SCRIPT LANGUAGE=\"JavaScript\" SRC=\"modules/MILPACS/js/switch.js\"></SCRIPT>"
  . "<table border=0><tr><td width=100%>"
  . "<font class=\"mainroster\"><big><center><b>"._MILPACS_UNIT." Roster</b></center></big></font><br>"
  . "<form name=\"dropmsgform\">"
  . "Select Roster: "
  . "<select name=\"dropmsgoption\" size=\"1\" onChange=\"expandone()\">"
  . "<option selected>Combat Roster</option>"
  . "<option>Administrative Roster</option>"
  . "<option>Past Member Roster</option>"
  . "</select></form>"
  . "<hr width=200 align=\"left\">"
  . "</td></tr></table>"
 ."";
CloseTable();
?>
<br>
<div id="dropmsg0" class="dropcontent">
<?php
OpenTable();
?>
<H3><center>Combat Roster</center></H3>
<?php

$sql = "SELECT mm.uniqueid, mr.rank_image, mm.u_name, mw.make, mm.unit_id, mm.position, mm.status, mm.weapon_id, mu.unit_name, mu.unit_nick, mm.promotion_dt, mm.subunit_id FROM " . $prefix . "_milpacs_units mu, " . $prefix . "_milpacs_members mm, " . $prefix . "_milpacs_weapons mw, " . $prefix . "_milpacs_ranks mr WHERE mu.unit_id = mm.unit_id AND mw.weapon_id = mm.weapon_id AND mm.rank_id = mr.rank_id AND mm.status IN ('Active','LOA','Medical LOA') ORDER BY mu.unit_order, mm.subunit_id, mr.rank_order, mm.promotion_dt asc";
$unitname = "";
$subunitName = "";
$ifTitled = false;
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	if ( $unitname != $unit_name ) {
		$unitname = $unit_name;
		$unitnick = $unit_nick;
		?>
		<table border=0 width='100%' cellpadding='5'><tr>
		<table border=0 width='100%' cellpadding='3'><tr><th width='100%'><?php echo $unitname .' '. $unitnick ?></th>
		<?php
		$ifTitled = false;
		$subunitName = "";
	}
	$sql_sub = "SELECT subunit_name FROM " . $prefix . "_milpacs_subunit WHERE subunit_id = '$subunit_id' AND unit_id = '$unit_id'";
	$result_sub = $db->sql_query($sql_sub);
	if ( ( $row_sub = $db->sql_fetchrow($result_sub) ) && ( $subunitName != $row_sub['subunit_name'] ) ) {
		$subunit_name = $row_sub['subunit_name'];
		$subunitName = $subunit_name;
		?>
		<tr><td colspan="6"><table border=0 width='100%' cellpadding='3'><tr><th width='100%' colspan="6"><?php echo $subunitName ?></th>		
		</tr></table></td></tr>
		<?php
	} else if ( ( $subunit_id == 0 ) && ( $subunitName != "NULL" ) ) {
		$subunitName = "NULL";
		$ifTitled = true;
		?>		
		<table border=0 width='100%' cellpadding='3'><tr><th width='11%'>Rank</th><th width='30%'><b>Name</b></th><th width='25%'>Unit</th><th width='25%'>Position</th><th width='14%'>Weapon</th><th width='8%'>Status</th>
		</tr>
		<?php
	}
	if ($row["rank_image"] =="") {
		$ri = "&nbsp;"; 
	} else {
		$ri = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 
	}
	if ( !$ifTitled ) {
		$ifTitled = true;
		?>
		<table border=0 width='100%' cellpadding='3'><tr><th width='11%'>Rank</th><th width='30%'><b>Name</b></th><th width='25%'>Unit</th><th width='25%'>Position</th><th width='14%'>Weapon</th><th width='8%'>Status</th>
		</tr>
		<?php
	}
	?>
	<td width='15%' class='row1' align='center'><?php echo $ri ?></td><td class='row1' width='30%'>
	&nbsp;<a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=soldierprofile&amp;uniqueid=<?php echo $uniqueid ?>"><?php echo $u_name ?></a>
	</td><td class='row1' align='center' width='25%'><a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=unitprofile&amp;unit_id=<?php echo $unit_id ?>"><?php echo $unitname ?></a></td><td width='25%' class='row1' align='center'><?php echo $position ?></td><td width='14%' class='row1' align='center'><a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=weaponprofile&amp;weapon_id=<?php echo $weapon_id ?>"><?php echo $make ?></a></td><td width='8%' class='row1' align='center'><?php echo $status ?></td>
	</tr>
	<?php
}
echo "</table><br /><hr noShade>";
CloseTable();
?>
</div><div id="dropmsg1" class="dropcontent">
<?php
OpenTable();
?>
<H3><center>Administrative Roster</center></H3>
<?php
$admin_unitname = "";
$sql = "SELECT * FROM " . $prefix . "_milpacs_adminunit mau JOIN " . $prefix . "_milpacs_units mu JOIN " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_weapons mw JOIN " . $prefix . "_milpacs_ranks mr WHERE mu.unit_id = mm.unit_id AND mw.weapon_id = mm.weapon_id AND mm.rank_id = mr.rank_id AND FIND_IN_SET(mau.admin_unit_id,mm.adminunits) > 0 AND mm.status IN ('Active','LOA','Medical LOA') ORDER BY mau.admin_unit_name, mr.rank_order, mm.promotion_dt asc";
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	if ( $admin_unitname != $admin_unit_name) {
			$admin_unitname = $admin_unit_name;
			?>
			<table border=0 width='100%' cellpadding='5'><tr>
			<table border=0 width='100%' cellpadding='3'><tr><th width='100%'><?php echo $admin_unitname ?></th>
			<table border=0 width='100%' cellpadding='3'><tr><th width='11%'>Rank</th><th width='30%'><b>Name</b></th><th width='16%'>Combat Unit</th><th width='25%'>Position</th><th width='14%'>Weapon</th><th width='8%'>Status</th>
			</tr>
			<?php
	}
	if ($row["rank_image"] =="") {
		$ri = "&nbsp;"; 
	} else {
		$ri = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 
	}
	?>
	<td width='15%' class='row1' align='center'><?php echo $ri ?></td><td class='row1' width='30%'>
	&nbsp;<a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=soldierprofile&amp;uniqueid=<?php echo $uniqueid ?>"><?php echo $u_name ?></a>
	</td><td class='row1' align='center' width='16%'><a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=unitprofile&amp;unit_id=<?php echo $unit_id ?>"><?php echo $unit_name ?></a><td width='25%' class='row1' align='center'><?php echo $position ?></td><td width='14%' class='row1' align='center'><a href="modules.php?name=<?php echo $module_name ?>&amp;file=weaponprofile&amp;weapon_id=<?php echo $weapon_id ?>"><?php echo $make ?></a></td><td width='8%' class='row1' align='center'><?php echo $status ?></td>
	</tr>
	<?php
}
echo "</table><br /><hr noShade>";
CloseTable();
?>
</div><div id="dropmsg2" class="dropcontent">
<?php
OpenTable();
?>
<H3><center>Past Members Roster</center></H3>
<?php

$sql = "SELECT mm.uniqueid, mr.rank_image, mm.u_name, mw.make, mm.unit_id, mm.position, mm.status, mm.weapon_id, mu.unit_name, mu.unit_nick, mm.promotion_dt FROM " . $prefix . "_milpacs_units mu, " . $prefix . "_milpacs_members mm, " . $prefix . "_milpacs_weapons mw, " . $prefix . "_milpacs_ranks mr WHERE mu.unit_id = mm.unit_id AND mw.weapon_id = mm.weapon_id AND mm.rank_id = mr.rank_id AND mm.status IN ('Discharged','Retired','Long Term LOA') ORDER BY mr.rank_order, mu.unit_id, mm.promotion_dt asc";
$wRow =0;
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
    if ( $wRow == 0 ) {
            $wRow++;
			$unitname = $unit_name;
			$unitnick = $unit_nick;
			?>
			<table border=0 width='100%' cellpadding='5'><tr><th width='11%'>Rank</th><th width='30%'><b>Name</b></th><th width='16%'>Combat Unit</th><th width='25%'>Position</th><th width='14%'>Weapon</th><th width='15%'>Status</th>
			</tr>
			<?php
	}
	if ($row["rank_image"] =="") {
		$ri = "&nbsp;"; 
	} else {
		$ri = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 
	}
	?>
	<td width='15%' class='row1' align='center'><?php echo $ri ?></td><td class='row1' width='30%'>
	&nbsp;<a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=soldierprofile&amp;uniqueid=<?php echo $uniqueid ?>"><?php echo $u_name ?></a>
	</td><td class='row1' align='center' align='center' width='25%'><a class="mainroster" href="modules.php?name=<?php echo $module_name ?>&amp;file=unitprofile&amp;unit_id=<?php echo $unit_id ?>"><?php echo $unit_name ?></a><td width='25%' class='row1' align='center'><?php echo $position ?></td><td width='14%' class='row1' align='center'><a href="modules.php?name=<?php echo $module_name ?>&amp;file=weaponprofile&amp;weapon_id=<?php echo $weapon_id ?>"><?php echo $make ?></a></td><td width='8%' class='row1' align='center'><?php echo $status ?></td>
	</tr>
	<?php
}
echo "</table><br /><hr noShade>";
CloseTable();
?>
</div>
<?php
@include_once("footer.php");
?>