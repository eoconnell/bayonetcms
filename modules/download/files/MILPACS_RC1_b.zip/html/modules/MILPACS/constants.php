<?php
if (eregi("constants.php", $_SERVER['SCRIPT_NAME'])) {
    Header("Location: index.php");
    die();
}

define ('DRILL_ACCESS', 'permit');
define ('ADMIN_ACCESS', 'p@55w0rd');
?>