<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Medal Page                                            */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "award.php"))	{
	Header("Location: ../../index.php");
	die();
}
//finds the server's root directory
$index=0;
@require_once("mainfile.php");
@include_once("header.php");
global $module_name, $db, $prefix;
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
OpenTable();

echo"<style type=\"text/css\"><!--"
  . "p.content	{ font-size: 12px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF;}"
  . "h1 			{text-align: center}"
  . "--></style>"
  . "<table border=0><tr><td width=100%>"
  . "<font class=\"mainroster\"><big><b>"._MILPACS_UNIT." Medals</b></big></font><hr width=\"100%\" align=\"center\">"
  . "</td></tr></table>";
  CloseTable();
  OpenTable();
  echo "<TABLE cellSpacing=0 cellPadding=0 width=100% border=0>"
  . "<BODY>"
  . "<br>"
  . "<h1><p class=\"content\" align=\"center\">The practice of awarding medals to the common soldier started long ago.  The first formal system for rewarding acts of individual gallantry by this nation's fighting men was established by General George Washington on August 7, 1782. Designed to recognize \"any singularly meritorious action,\" the award consisted of a purple cloth heart."
  . "<br>"
  . "<br>"
  . "World War I saw the first Victory Medal and the use of devices such as stars, oak leafs and bars to denote additional awards or campaigns. New decorations were added to maintain the prestige of the Medal of Honor. "
  . "<br>"
  . "<br>"
  . "World War II saw the award system expand to provide a wider degree of decorations for valor and merit and more service medals to signify campaigns in Europe, Asia and the Americas."
  . "<br>"
  . "<br>"
  . "The "._MILPACS_UNIT." continues this time honored tradition of recognizing individual gallantry on the field of battle."
  . "<br>"
  . "<br>"
  . "</TABLE>"
  . ""
  . "<!-- Header row for Individual Medal table  -->"
  . "<tr>"
  . "<td align=\"left\" bgcolor=\"#333333\">"
  . "<table border=\"1\" cellpadding=\"2\" cellspacing=\"1\" style=\"border-collapse: collapse;\" width=\"100%\" id=\"AutoNumber2\" bordercolor=\"#111111\">"
  . "<table border=0 width='100%' cellpadding='3'><tr><th width='100%'>Individual Medals</th>"
  . "<table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Image</th><th width='20%'><b>Name</b></th><th width='60%'>Description</th>"
  . "</tr>"
 ."";

$result = $db->sql_query("SELECT award_image, award_name, award_description, award_class FROM " . $prefix . "_milpacs_awards WHERE award_class = 'Individual Medal' ORDER BY award_id");

while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	// Populate award page from database
	$ai = "<img src='modules/MILPACS/images/medals/$row[award_image]'>"; 
	?>
    <TR>
	<td width="20%" align="center"><?php echo $ai ?></td>
	<td width="20%" align="left"><?php echo $row[award_name] ?></td>
	<td width="60%" align="left"><?php echo $row[award_description] ?></td>
	</TR>
    <?php
}          
?>
</BODY>
</TABLE>

<!-- Header row for Unit Citations table -->
<tr>
<td align="left" bgcolor="#333333">
<table border="1" cellpadding="2" cellspacing="1" style="border-collapse: collapse;" width="100%" id="AutoNumber2" bordercolor="#111111">
<table border=0 width='100%' cellpadding='3'><tr><th width='100%'>Combat Unit Citations</th>
<table border=0 width='100%' cellpadding='3'><tr><th width='15%'>Image</th><th width='25%'><b>Name</b></th><th width='60%'>Description</th>
</tr>
<?php

$result = $db->sql_query("SELECT award_image, award_name, award_description, award_class FROM " . $prefix . "_milpacs_awards WHERE award_class = 'Unit Citation' ORDER BY award_id");
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	// Populate award page from database
	$ai = "<img src='modules/MILPACS/images/medals/$row[award_image]'>";
	?>
	<TR>
	<td width="20%" align="center"><?php echo $ai ?></td>
	<td width="20%" align="left"><?php echo $row[award_name] ?></td>
	<td width="60%" align="left"><?php echo $row[award_description] ?></td>
	</TR>
	<?php
}
?>
</BODY>
</TABLE>
	 
<!-- Header row for Skill Badges table -->
<tr>
<td align="left" bgcolor="#333333">
<table border="1" cellpadding="2" cellspacing="1" style="border-collapse: collapse;" width="100%" id="AutoNumber2" bordercolor="#111111">
<table border=0 width='100%' cellpadding='3'><tr><th width='100%'>Skill Badges</th>
<table border=0 width='100%' cellpadding='3'><tr><th width='15%'>Image</th><th width='25%'><b>Name</b></th><th width='60%'>Description</th>
</tr>
<?php
$result = $db->sql_query("SELECT award_image, award_name, award_description, award_class FROM " . $prefix . "_milpacs_awards WHERE award_class = 'Skill Badge' ORDER BY award_id");
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	// Populate award page from database
	$ai = "<img src='modules/MILPACS/images/medals/$row[award_image]'>";
	?>
	<TR>
	<td width="20%" align="center"><?php echo $ai ?></td>
	<td width="20%" align="center"><?php echo $row[award_name] ?></td>
	<td width="60%" align="left"><?php echo $row[award_description] ?></td>
	</TR>
	<?php
}
?>
</BODY>
</TABLE>
<?php
CloseTable(); 
@include_once("footer.php"); 
?>