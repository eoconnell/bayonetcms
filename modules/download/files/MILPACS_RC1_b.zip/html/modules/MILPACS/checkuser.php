<? 
//////////////////////////////////////////////////////////////////////
//===========================
// MILPACS
//
// This is the Military Personell and Classification System.
// 
//
//
///////////////////////////////////////////////////////////////////////

if (!eregi("modules.php", $PHP_SELF )) {
	die ("You can't access this file directly...");
    }

if (isset($dop) AND ($dop == "login")) {
	$pass11 = stripslashes(check_html(FixQuotes($_POST['pass123'], "nohtml")));
	$query = "SELECT * FROM ".$prefix."_milpacs_pass WHERE id = 'user' AND pass = MD5('" . $pass11 . "')";
	$result = $db->sql_query($query);
	if ($row = $db->sql_fetchrow($result)) {
       @session_destroy();
       session_start();
       $_SESSION['loggedin1'] = 1;
	   $_SESSION['password'] = $pass11;
	    Header("Location: modules.php?name=MILPACS&file=viewdrill");
    } else {
       @session_destroy();
       session_start();
       $_SESSION['loggedin1'] = 0;
	   $_SESSION['password'] = "";
	    Header("Location: modules.php?name=MILPACS&file=accessdenied");
    }
    die();
} else {
   @session_destroy();
   include_once("header.php");
   OpenTable();
   echo "<center><H1><strong>Drill Report Administration</strong></H1></center><br>";
   echo "<form action=\"modules.php?name=MILPACS&file=checkuser\" method=\"post\">";
   echo "<input type=hidden name=\"dop\" value=\"login\">";
   echo "<table align=\"center\"><tr><td>Password: </td><td><input type=password name=\"pass123\"></td></tr>";
   echo "<tr><td colspan=2><center><input type=submit value=\"Login\"></center></td></tr></table></form>";
   CloseTable();
   include_once("footer.php");
}
?>