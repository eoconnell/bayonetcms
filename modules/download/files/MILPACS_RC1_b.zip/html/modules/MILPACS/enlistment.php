<?php 
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net							*/
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Enlistment                                            */
/*********************************************************/
if (stristr($_SERVER['SCRIPT_NAME'], "enlistment.php")) {
    Header("Location: ../../index.php");
    die();
}
@require_once("mainfile.php");
@include_once("modules/MILPACS/includes/milpacs.inc.php");
$module_name = basename(dirname(__FILE__)); 
get_lang($module_name);
@include_once("header.php");

/**********************************/ 
/* Configuration                  */ 
/*                                */ 
/* You can change this:           */ 
/* $index = 0; (right side off)   */ 
/**********************************/ 
$index = 0; 
$subject = "$sitename ".Recruitment.""; 
/**********************************/ 
 

if ($cookie[1] != "") { 
    $sql = "SELECT name, username, user_email FROM ".$user_prefix."_users WHERE user_id='$cookie[0]'"; 
    $result = $db->sql_query($sql); 
    $row = $db->sql_fetchrow($result); 
    if ($row[name] != "") { 
   $sender_name = $row[name]; 
    } else { 
   $sender_name = $row[username]; 
    } 
    $sender_email = $row[user_email]; 
} 
OpenTable();
?>
<style type="text/css"><!-- p.content		{ font-size: 11.5px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF;} --></style>
<table border="0" width=100%>
  <tr>
	<th colspan="3" height="25" nowrap="nowrap">&nbsp;Becoming a <?=_MILPACS_NAME?>&nbsp;</th>
  </tr>
  <tr>
	<td class="row1"><span class="gen"> <p class="content">
You need to decide right now that you are 100% sure you want to join this unit before you fill out your enlistment papers. If you are not 100% sure that this is the unit for you, then by all means ask as many questions as you need to. Our soldiers and officers will be more than happy to assist you in any way possible. Once you make your decision, we expect you to stick with it. Commitment is the most important thing in the <?=_MILPACS_UNIT?>. 

If this is indeed what you are looking for and you believe that you have what it takes to become a <?=_MILPACS_NAME?>, then your next step is Basic Combat Training or BCT. BCT is conducted under proven tactics by experienced Drill Sergeants and is the crucible in which all soldiers are forged into lethal warriors; where a soldier's character is sharpened into the true grit of honor and integrity. It is here where you will have to prove that you have what it takes. Your assignment in BCT will last for five weeks, and here's what you can expect: 
<UL>
<LI><p class="content">You will undergo rigorous training on individual skills and team coordination. 
<LI><p class="content">You will undergo Close Order Rifle Drill (CORD) training until your skill with your weapon is second nature. 
<LI><p class="content">You will be taught the chain of command, rules and regulations, and how to act like a soldier on and off the battlefield 
<LI><p class="content">You will learn to love your Drill Sergeant like your mother, and how to take care of your fellow squad mates like the brothers that they will become. </UL>

<p class="content">It takes effort on your part to be a member of the <?=_MILPACS_UNIT?>. We are a unit of principles and of honor. We do not accept everyone, and only the soldiers that are the true epitome of our expectations will wear the <?=_MILPACS_TAG?> tag. Your tenure in BCT is your defining moment. It is the time that you show us that you are indeed <?=_MILPACS_UNIT?> material. 

Are you prepared to take on the task of becoming a <?=_MILPACS_NAME?>? 

Then step up and fill out your enlistment papers today! Our recruiters are standing by to assist you in any way. 

Thank you for your interest, and good luck!
</span></td>
  </tr>

</table>

<?php
CloseTable();

OpenTable();
if ($op == "SendEnlistment") {
if ($opi != "ds") { 
    //echo "$block";
} elseif ($opi == "ds") { 
    if ($sender_name == "") { 
   $name_err = "<center><font class=\"option\"><b><i>"._FBENTERNAME."</i></b></font></center><br>"; 
   $send = "no"; 
    } 
    if ($sender_email == "") { 
   $email_err = "<center><font class=\"option\"><b><i>"._FBENTEREMAIL."</i></b></font></center><br>"; 
   $send = "no"; 
    } 
    if ($send != "no") { 
   $sender_name = removecrlf($sender_name); 
   $sender_email = removecrlf($sender_email); 
   $msg = "$sitename\n\n"; 
   $msg .= ""._SENDERNAME.": $sender_name\n"; 
   $msg .= ""._SENDER_CALLSIGN.": $sender_callsign\n"; 
   $msg .= ""._SENDEREMAIL.": $sender_email\n"; 
   $msg .= ""._SENDER_ICQ.": $sender_icq\n"; 
   $msg .= ""._WEAPON.": $weapon\n"; 
   $msg .= ""._CLANED.": $claned\n"; 
   $msg .= ""._WHYPLAY.": $whyplay\n"; 
   $msg .= ""._SKILLS_TALENT.": $Skills_Talents\n"; 
   $msg .= ""._ADDITIONAL.": $Additional\n"; 
   $msg .= ""._WEARIT.": $wearit\n";     
   $mailheaders = "From: $sender_name <$sender_email>\n"; 
   $mailheaders .= "Reply-To: $sender_email\n\n"; 
   mail($recruitemail, $subject, $msg, $mailheaders); 
   echo "<P><center><b><FONT SIZE=6  COLOR=#00FF00>"._FBMAILSENT."</FONT></center></p>"; 
   echo "<P><center><b><FONT SIZE=6  COLOR=#00FF00>"._FBTHANKSFORCONTACT."</FONT></center></p>"; 
    } elseif ($send == "no") { 
   OpenTable2(); 
   echo "$name_err"; 
   echo "$email_err"; 
   echo "$message_err"; 
   CloseTable2(); 
   echo "<br><br>"; 
   //echo "$block";    
    } 
}
}

?>
<html>
<head>
<title>Recruitment</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor="#CCCCCC"><table width="100%" border="1" cellspacing="1" cellpadding="1">
<tr><td>
      <center><b><font color="#FF0000" face="Army, Army Condensed, Army Expanded, Army Hollow, Army Thin, Army Wide"><h2><?=_MILPACS_UNIT?> Enlistment Form</h2></font></b></center>
     <font color="#000000" face="Army, Army Condensed, Army Expanded, Army Hollow, Army Thin, Army Wide"><br>
      <br><center><b>Are you ready to become a <?=_MILPACS_NAME?>?</b><br>
      <b>Are you are looking for a serious realism unit, dedicated to emulating actual tactics used in World War Two?</b><br>
      <b>Do you believe that character and values are among the most important traits to look for in a unit, regardless of personal skill?</b><br>
      <b>Are you looking for an atmosphere that will take you back to 1940�s Europe, both in game and in our forums?</b><br>
      <b>Are you willing to have fun?</b><br>
      <b>Then the <?=_MILPACS_UNIT?> is for you!</b>
   </center></font>   
<form name="enlistment" action="modules.php?name=MILPACS&file=enlistment" method="post">
      <font color="#FFFFFF">
      <INPUT type="hidden" name="opi" value="ds">
      </font>
      <TABLE BORDER="0" WIDTH="100%">
        <TR>
          <TD COLSPAN="2" ALIGN="CENTER"> <font color="#FFFFFF" class="content">Please provide the following contact information:</font></TD>
        </TR>
        <TR>
          <TD ALIGN="RIGHT" WIDTH="50%"> <font color="#FFFFFF"><b>Please provide your real name:</b><br></font></TD>
          <TD ALIGN="LEFT" WIDTH="50%"> <font color="#FFFFFF"><INPUT type="text" NAME="sender_name" VALUE="" SIZE=30></font></TD>
        </TR>
        <TR>
          <TD ALIGN="RIGHT"> <font color="#FFFFFF"><b>Please provide your Call of Duty name:</b><br></font></TD>
          <TD> <font color="#FFFFFF"><INPUT type="text" NAME="sender_callsign" VALUE="" SIZE=30></font></TD>
        </TR>
        <TR>
          <TD ALIGN="RIGHT"> <font color="#FFFFFF"><b>Please provide your email address:</b><br></td>
          <TD> <font color="#FFFFFF"><INPUT type="text" NAME="sender_email" VALUE="" SIZE=30></font></TD>
        </TR>
        <TR>
          <TD ALIGN="right"> <font color="#FFFFFF"><b>Please provide your ICQ number:</b> <font color="#FF0000">(ICQ required)</font></TD>
          <TD> <font color="#FFFFFF"><INPUT type="text" NAME="sender_icq" VALUE="" SIZE=30></font></TD>
        </TR>
        <TR>
          <TD ALIGN="right"> <font color="#FFFFFF"><b>Primary weapon of choice</b>: </font></TD>
          <TD ALIGN="LEFT"> <font color="#FFFFFF"><B>
		  <SELECT NAME="weapon">
              <OPTION VALUE="---">Pick One</OPTION>
              <OPTION VALUE="M1 Garand">M1 Garand</OPTION>
              <OPTION VALUE="M1 Carbine">M1 Carbine</OPTION>
              <OPTION VALUE="Thompson SMG M1A1">Thompson SMG M1A1</OPTION>
              <OPTION VALUE="Browning Automatic Rifle (BAR) M1918A2">Browning
              Automatic Rifle (BAR) M1918A2</OPTION>
            </SELECT>
            </B> </font></TD>
        </TR>
      </table>
      <table>
        <TR>
          <TD VALIGN="MIDDLE" ALIGN="right"> <font color="#FFFFFF"><b>Have you ever been in a realism unit before</b>: </font></TD>
          <TD ALIGN="LEFT"> <font color="#FFFFFF"><INPUT TYPE="RADIO" NAME="claned" VALUE="Yes" CHECKED> Yes <INPUT TYPE="RADIO" NAME="claned" VALUE="No"> No </font></TD>
        </TR>
        <TR>
          <TD VALIGN="TOP" ALIGN="right"> <font color="#FFFFFF"><b>Why do you play Call of Duty?</b> </font></TD>
          <TD ALIGN="LEFT"> <font color="#FFFFFF"><TEXTAREA NAME="whyplay" ROWS="5" COLS="35"></TEXTAREA></font></TD>
        </TR>
        <TR>
          <TD VALIGN="TOP" ALIGN="right"> <font color="#FFFFFF"><b>What skill,talent or other item will you bring to the unit?</b> </font></TD>
          <TD ALIGN="LEFT"> <font color="#FFFFFF"><TEXTAREA NAME="Skills_Talents" ROWS="5" COLS="35"></TEXTAREA></font></TD>
        </TR>
        <TR>
          <TD VALIGN="TOP" ALIGN="right"> <font color="#FFFFFF"><b>Any additional comments or things we should know?</b> </font></TD>
          <TD ALIGN="LEFT"> <font color="#FFFFFF"><TEXTAREA NAME="Additional" ROWS="5" COLS="35"></TEXTAREA></font></TD>
        </TR>
        <TR>
          <TD VALIGN="MIDDLE" ALIGN="right" WIDTH="40%"> <font color="#FFFFFF"><b>Are you willing to wear the <?=_MILPACS_TAG?> tag after your name at all times?</b>: </font></TD>
          <TD ALIGN="left"> <font color="#FFFFFF"><INPUT TYPE="RADIO" NAME="wearit" VALUE="Yes" CHECKED> Yes <INPUT TYPE="RADIO" NAME="wearit" VALUE="No"> No </font></TD>
        </TR>
        <TR>
          <TD COLSPAN="2" ALIGN="CENTER"><p><font color="#FFFFFF"> Please note
              that applying does not mean you are in the <?=_MILPACS_TAG?>. You'll be watched
              closely on the forum and in game on our server for a length of time.
              Stay active on the server and on the forums (cant stress this enough).
              If you display the dedication, commitment, maturity, and will uphold
              the honor of the <?=_MILPACS_UNIT?>, then after this trial period
              will you be given your draft notice and recruited.
              Skill alone does not determine admittance, as attitude plays a big
              part in the decision as well.<font color="#FF0000"><b> Please visit our forums and post this same
              information in the Recruitment forums.</b></font><font color="#FFFFFF">This way your enlistment is tracked in
              two different places and will not get lost.  Welcome to the <?=_MILPACS_UNIT?> Forums
             <p><font color="#FFFFFF">Good luck Soldier!!</font></p></TD>
        </TR>
        <TR>
          <TD COLSPAN="2" ALIGN="CENTER"> <font color="#FFFFFF"><INPUT TYPE="submit" NAME="op" VALUE="SendEnlistment">
            <INPUT TYPE="reset"VALUE="Reset"></font></TD>
        </TR>
      </TABLE>
    </FORM></center>
        </td></TR>
      </TABLE>
</body>
</html>
<?php

CloseTable();      
@include_once("footer.php"); 
?> 