<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Soldier Profile                                       */
/*********************************************************/

if (stristr($_SERVER['SCRIPT_NAME'], "soldierprofile.php")) {
    Header("Location: ../../index.php");
    die();
}

//Required Files
$module_name = basename(dirname(__FILE__));
@include_once("header.php");
@require_once("mainfile.php");
@include("modules/MILPACS/includes/milpacs.inc.php");
global $module_name, $db, $prefix;


OpenTable();
?>
<style type=text/css><!--
p.content		{ font-size: 10.5px; font-family: Verdana, Arial, Helvetica, sans-serif; color: #FFFFFF;}
--></style>
<?php
$uniqueid = $_GET['uniqueid'];
$result = $db->sql_query("SELECT *, date_format(enlistment_dt,'%e %b %Y') as enlistment_dt FROM " . $prefix . "_milpacs_members WHERE uniqueid ='$uniqueid'");
$info = $db->sql_fetchrow($result);
$bio = stripslashes($info[bio]); 
$admin_units = explode(",",$info[adminunits]);
$admin_names;
for ($i=0; $i < (sizeof($admin_units)-1); $i++) {
	if ($i > 0)
		$admin_names .= ", ";
	$result_au = $db->sql_query("SELECT admin_unit_name FROM " . $prefix . "_milpacs_adminunit WHERE admin_unit_id = '$admin_units[$i]' ORDER BY admin_unit_name");
	$info_au = $db->sql_fetchrow($result_au);
	$admin_names .= $info_au[admin_unit_name];
}
$hname = "$u_handle";
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}
$enlistment_dt = $info['enlistment_dt'];
$reports = $info[reports];
$reportsto = $db->sql_query("SELECT u_name FROM " . $prefix . "_milpacs_members WHERE $reports = uniqueid");

$drills_available = 0;
$sql_0 = "SELECT mdlk.status FROM " . $prefix . "_milpacs_drill_lkup mdlk JOIN " . $prefix . "_milpacs_drills md WHERE mdlk.uniqueid = '$uniqueid' AND mdlk.drill_id = md.drill_id AND MONTH(md.drill_dt) >= (MONTH(NOW()) - 1)";
$result_0 = $db->sql_query($sql_0);
while ( $row_0 = $db->sql_fetchrow($result_0) ) {
	$drills_available += 1;
	$status = $row_0['status'];
	if ($status == 'Present')
		$drills_present += 1;
}
if ($drills_available == 0)
	$per_attend = 0;
else
	$per_attend = ($drills_present / $drills_available) * 100;
settype($per_attend, 'integer');

$result1 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_ranks a JOIN " . $prefix . "_milpacs_members b JOIN " . $prefix . "_milpacs_units c WHERE b.uniqueid='$uniqueid' AND a.rank_id = b.rank_id");
$info1 = $db->sql_fetchrow($result1);
if (!$result1) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}

$result2 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_units mu JOIN " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_weapons mw WHERE mm.uniqueid = '$uniqueid' AND mm.unit_id = mu.unit_id AND mm.weapon_id = mw.weapon_id");
$info2 = $db->sql_fetchrow($result2);
$uname = "$unit_name";
$uid = $unit_id;
if (!$result2) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}

$result5 = $db->sql_query("SELECT msu.subunit_name FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_subunit msu WHERE mm.uniqueid = '$uniqueid' AND mm.subunit_id = msu.subunit_id");
$info5 = $db->sql_fetchrow($result5);
if (!$result5) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}

// Testing the Time is service / Time in Grade date.
// Time is Service TIS will be from enlisted_dt to present.
// Time is Grade TIG will be from promotion_dt to present.

$result3 = $db->sql_query("SELECT enlistment_dt, promotion_dt FROM " . $prefix . "_milpacs_members WHERE uniqueid ='$uniqueid'");
$info3 = $db->sql_fetchrow($result3);
$newestDate= date("j F Y");
$enlistDate= $info3[enlistment_dt];
$promoDate= $info3[promotion_dt];
$TISdaysElapsed=round((strtotime($newestDate) - strtotime($enlistDate))/(60*60*24)-1);
$TIGdaysElapsed=round((strtotime($newestDate) - strtotime($promoDate))/(60*60*24)-1);
$TISyrs=floor($TISdaysElapsed/365);
$TISmonths=floor(($TISdaysElapsed-($TISyrs*365))/30);
$TIGyrs=floor($TIGdaysElapsed/365);
$TIGmonths=floor(($TIGdaysElapsed-($TIGyrs*365))/30);

if (!$result3) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}	

// Promotion Points
//Promotion points was an idea of letting soldiers aquire points for attending drill, matches, and general good behavior and leaderhip.
//I left it here for possible future use.  Just uncomment.

//$result4 = $db->sql_query ("SELECT SUM(points) as totalpoints FROM ".$prefix . "_milpacs_points_lkup WHERE uniqueid ='$uniqueid'");
//$info4 = $db->sql_fetchrow($result4);
//$promopoints += $info4[totalpoints]; 
?>
<!-- Outer table -->
<center><a href="modules.php?name=MILPACS&file=roster">Back to Roster</a></center>
<br>
<table border="2" align="center" cellpadding="4" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111" width="680">
	<tr>
		<td align="center" bgcolor="#777777">
		<?php echo "<b><font color=\"#000000\">Profile of $info1[rank_abbr] $info[u_name] </font></b>"; ?>
		</td>
	</tr>
	<tr>
		<td align="center" bgcolor="#777777" valign="top">
		<img border="0" src="modules/MILPACS/images/uniform/<?php echo $info[uniform] ?>"/>
		</td>
	</tr>

	<!-- Vital Stats -->
	<tr>
		<td align="left" bgcolor="#666633"><b><font color="#000000">Vital Statistics</font></b></td>
	</tr>
	<tr>
		<td align="left" bgcolor="#999999">
<!-- Inner table -->
<table border="1" align="center" cellpadding="2" cellspacing="1" style="border-collapse: collapse;" width="100%" id="AutoNumber1" bordercolor="#111111">
				<tr>
					<td width="8%" rowspan="10" align="center"><img border="0" src="modules/MILPACS/images/ranks/large/<?php echo $info1[rank_image_l] ?>"/>
					<br><br><br>
					<img border="0" src="modules/MILPACS/images/flags/<?php echo $info[flag] ?>"/></td>
					<td width="12%" align="right"><b><font color="#660033">Location: </font></b></td>
					<td width="80%" colspan="5"><p class="content"><?php echo $info[location] ?></td>
				</tr>
				<tr>
					<td width="12%" align="right"><b><font color="#660033">Status:  </font></b></td>
					<td width="16%"><p class="content"><font color="#00FF00"><?php echo $info[status] ?></font></td>
					<td width="14%"><p align="right"><font color="#660033"><b>Primary MOS: </b></font></td>
					<td width="7%"><p class="content"><?php echo $info[p_mos] ?></td>					
				</tr>
				<tr>
					<td width="15%" align="right"><b><font color="#660033">Combat Unit: </font></b></td>
					<td width="30%" colspan="3"><p class="content"><a href="modules.php?name=<?php echo $module_name ?>&amp;file=unitprofile&amp;unit_id=<?php echo $info2[unit_id] ?>"><p class="content"><?php echo $info2[unit_name] ?></a>
					</td>
					<td width="10%"><p align="right"><font color="#660033"><b>Reports to: </b></font></td>
					<td width="35%"><p class="content"><?php echo $info[reports] ?></a></td>
				</tr>
				<tr>
					<td width="12%"><p align="right"><font color="#660033"><b>Combat Subunit: </b></font></td>
					<td width="16%"><p class="content"><?php echo $info5[subunit_name] ?></td>
					<td width="14%"><p align="right"><font color="#660033"><b>Admin Units: </b></font></td>
					<td width="30%" colspan="3"><p class="content"><?php echo $admin_names ?></td>
				</tr>
				<tr>
					<td width="17%" align="right"><b><font color="#660033">Position: </font></b></td>
					<td width="80%" colspan="5"><p class="content"><?php echo $info[position] ?></td>
				</tr>
				<tr>
					<td width="17%" align="right"><font color="#660033"><b>Weapon: </b></font></td>
					<td width="44%" colspan="3"><p class="content"><?php echo $info2[make] ?></td>
					<td width="13%"><p align="right"><font color="#660033"><b>Qualifications: </b></font></td>
					<td width="30%"><p class="content"><?php echo $info[qual] ?></td>
				</tr>
				<tr>
					<td width="12%" align="right"><b><font color="#660033">Enlisted: </font></b></td>
					<td width="15%" colspan="5"><p class="content"><?php echo $enlistment_dt ?></td>
				</tr>
				<tr>
					<td width="12%" align="right"><b><font color="#660033">Time in Service:</font></b></td>
					<td width="15%" colspan="2"><p class="content">Years:[<?php echo $TISyrs ?>] Months:[<?php echo $TISmonths ?>]</td>
					<td width="14%" align="right"><b><font color="#660033">Time in Grade:</font></b></td>
					<td width="46%" colspan="3"><p class="content">Years:[<?php echo $TIGyrs ?>] Months:[<?php echo $TIGmonths ?>]</td>
				</tr>
				<tr>
					<td width="12%" align="right"><b><font color="#660033">ICQ#:  </font></b></td>
					<td width="15%" colspan="2"><p class="content"><?php echo $info[icq] ?></td>
					<td width="14%" align="right"><b><font color="#660033">E-mail: </font></b></td>
					<td width="70%" colspan="3"><p class="content"><a href="mailto:<?php echo $info['email'] ?>"><p class="content"><?php echo $info['email'] ?></a></td>
				</tr>
				<tr>
				<!-- Commented out promotion points -->
					<!--<td width="12%" align="right">
					<b><font color="#660033">Promotion Points:  </font></b>
					</td>
					<td width="15%" colspan="2">
					<p class="content"><?php echo $promopoints ?>
					</td> -->
					<td width="18%" align="right"><b><font color="#660033">Attendance Record: </font></b></td>
					<td width="66%" colspan="3"><p class="content"><?php echo $per_attend ?>%</td>
				</tr>
			</table>
		</td>
	</tr>
	<tr>
		<td align="left" bgcolor="#666633"><b><font color="#000000">Personal Bio</font></b></td>
	</tr>
	<tr>
		<td align="left" bgcolor="#999999"><p class="content"><?php echo $bio ?></td>
	</tr>
	<tr>
		<td align="left" bgcolor="#666633"><b><font color="#000000">Service Record</font></b></td>
	</tr>
<?php
$result3 = $db->sql_query("SELECT record_dt, details FROM " . $prefix . "_milpacs_service_record WHERE uniqueid ='$uniqueid' ORDER BY record_dt desc");
while ( $row = $db->sql_fetchrow($result3) ) {
	$sdate = $row["record_dt"];
	$sdetail = stripslashes($row["details"]);
	list($Year,$Month,$Day) = split('-',$sdate);
	$formatrecorddate = date("M j, Y",mktime(12,0,0,$Month,$Day,$Year));
	if (!$result3) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	}
	?>
	<tr>
		<td align="left" bgcolor="#999999">
			<table border="1" cellpadding="2" cellspacing="1" style="border-collapse: collapse" width="100%" id="AutoNumber2" bordercolor="#111111">
				<tr>
					<td width="13%" valign="top" align="left"><p class="content"><?php echo $formatrecorddate ?></td>
					<td width="87%" valign="top" align="left"><p class="content"><?php echo $sdetail ?></td>
				</tr>
			</table>
		</td>
	</tr>
<?php
}
?>
<!-- Awards -->
	<tr>
		<td align="left" bgcolor="#666633"><b><font color="#000000">Awards & Recognition</font></b></td>
	</tr>
<?php
$result4 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_awards a JOIN " . $prefix . "_milpacs_award_lkup b JOIN " . $prefix . "_milpacs_members c WHERE b.uniqueid = c.uniqueid AND a.award_id = b.award_id AND b.uniqueid = $uniqueid ORDER BY award_dt desc");
while ( $row = $db->sql_fetchrow($result4) ) {
	$aname = $row["award_name"];
	$adetail = stripslashes($row["adetails"]);	
	$adate = $row["award_dt"];
	list($Year,$Month,$Day) = split('-',$adate);
	$formatawarddate = date("M j, Y",mktime(12,0,0,$Month,$Day,$Year));
	if (!$result4) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	}
?>
	<tr>
		<td align="left" bgcolor="#999999">
			<table border="1" cellpadding="2" cellspacing="1" style="border-collapse: collapse" width="100%" id="AutoNumber2" bordercolor="#111111">
				<tr>				
					<td width="13%" valign="top" align="left"><p class="content"><?php echo $formatawarddate ?></td>
					<td width="35%" valign="top" align="left"><p class="content"><?php echo $aname ?></td>
					<td width="70%" valign="top" align="left"><p class="content"><?php echo $adetail ?><A href="modules.php?name=MILPACS&file=award"><font color="#3333FF"> (Details)</font></A></td>
				</tr>
			</table>
		</td>
	</tr>
<?php
	}
?>	
<!-- Combat Record -->
<tr>
		<td align="left" bgcolor="#666633"><b><font color="#000000">Combat Record</font></b></td>
</tr>
<?php	
$result5 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_combat mc JOIN vwar" . $n . " v JOIN vwar" . $n . "_opponents vo JOIN vwar" . $n . "_scores vs JOIN vwar" . $n . "_locations vl WHERE mc.uniqueid = $uniqueid AND mc.warid = v.warid AND mc.oppid = vo.oppid AND mc.warid = vs.warid AND vs.locationid = vl.locationid ORDER BY dateline DESC");
while ( $row = $db->sql_fetchrow($result5) ) {	
	$date = date("M j, Y", $row["dateline"]);	
	$enemy = $row["oppname"];
	$own_score = $row["ownscore"];
	$enemy_score = $row["oppscore"];
	$locationname = $row["locationname"];
	if (!$result5) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	}

if ($own_score > $enemy_score) {    
    $COLOR = "#00FF00";
}	Else {
    $COLOR = "#FF0000";
}		
	echo	"<tr>";
	echo	"<td align=left bgcolor=#999999>";
	echo	"<table border='1' cellpadding='2' cellspacing='1' style=border-collapse: collapse width='100%' bordercolor=#111111>";
	echo	"<tr>";
	echo	"<td width='15%' valign=top align=left><p class=content>$date </td>";
	echo	"<td width='30%' valign=top align=left><p class=content>$enemy </td>";
	echo	"<td width='20%' valign=top align=left><p class=content>$locationname </td>";
	echo	"<td width='10%' valign=top align=center><FONT COLOR=$COLOR>$own_score </td>";
	echo	"<td width='10%' valign=top align=center><FONT COLOR=$COLOR>$enemy_score </td>";
	echo	"</tr>";
	echo	"</table>";
	echo	"</td>";
	echo	"</tr>";
}
echo "</table>";
CloseTable();
include("footer.php");
?>