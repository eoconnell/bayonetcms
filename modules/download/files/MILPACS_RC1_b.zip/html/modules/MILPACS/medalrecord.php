 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Medal Record                                     */
/*********************************************************/
if (stristr($_SERVER['SCRIPT_NAME'], "medalrecord.php")) {
    Header("Location: ../../index.php");
    die();
}
if (!in_groups(23)) {
	// Not authorized
	echo "<META HTTP-EQUIV=\"refresh\" content=\".1;URL=modules.php?name=MILPACS&file=accessdenied\">";
	echo "<a href=\"modules.php?name=MILPACS&file=accessdenied\">";
	exit();
}

//finds the server's root directory
$module_name = basename(dirname(__FILE__));
@require_once("mainfile.php");	
@include_once("header.php");
global $module_name, $db, $prefix; 

OpenTable();
$id = $_GET['id'];
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_award_lkup lkup JOIN " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}
echo "<table border=\"2\" cellpadding=\"2\" align =\"center\" cellspacing=\"0\" style=\"border-collapse: collapse\" bgcolor=\"#000000\" bordercolor=\"#111111\" width=\"100%\"><tr>"
  . "         <td align=\"center\" bgcolor=\"#777777\">"
  . "            <b><font color=\"#000000\">Medal Record of $info[u_name]</font></b>"
  . "         </td>"
  . "       <tr>"
  . "			<td align=\"left\" bgcolor=\"#666633\">"
  . "			 <b><font color=\"#000000\">Awards & Recognition</font></b>"
  . "			</td>"
  . "		</tr>";
echo "<table border=0 width='100%' cellpadding='3'><tr><th width='45%'>Medal Name</th><th width='10%'>Date of Award</th><th width='55%'><b>Award Details</b></th></tr>";  
	
$sql = "SELECT lkup.pid, ma.award_name, ma.award_id, lkup.adetails, date_format(lkup.award_dt,'%e %b %Y') as award_dt, lkup.uniqueid FROM " . $prefix . "_milpacs_award_lkup lkup, " . $prefix . "_milpacs_awards ma WHERE lkup.uniqueid ='$id' AND ma.award_id = lkup.award_id";
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	$pid = $row["pid"];
	$award_name = $row["award_name"];
	$award_id = $row["award_id"];
	$date = $row["award_dt"];	
	$details = $row["adetails"];
?>
	<tr>
		<td align="left" bgcolor="#999999"><?php echo $award_name ?>&nbsp<a href=modules.php?name= <?php echo $module_name ?>&amp;op=editmedal&amp;pid= <? echo ?>$pid title="Edit"><img src=modules/<? echo $module_name ?>/images/pencil.gif></a>&nbsp &nbsp<a href=modules.php?name= <? echo $module_name ?>&amp;op=delMedalrecord&amp;pid= <? echo $pid ?> title="Delete"><img src=modules/<?php echo $module_name ?>/images/delete.png></a></td>
		<td align="left" bgcolor="#999999"><?php echo $date ?></td>
	    <td align="left" bgcolor="#999999"><?php echo $details ?></td>
	</tr>
<?php
}
?>
</table>
<br>
<b><font color="#000000"><a href=modules.php?name=<?php echo $module_name ?>&amp;op=editmedal&amp;id=<?php echo $id ?> title="Add">Add a New Medal</a></font></b>
<?php
CloseTable();
include("footer.php");
?>