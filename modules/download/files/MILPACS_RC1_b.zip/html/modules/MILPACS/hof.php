<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/
$index = 0;

//finds the server's root directory
$self = dirname(__FILE__);
$nukemod = basename($self);
$rootdir = eregi_replace("/modules/$nukemod", "", $self);
@require_once("mainfile.php");
global $module_name, $db, $prefix;
$module_name = basename(dirname(__FILE__));
@include_once("header.php");
OpenTable();
?>
<html>
<head>
<center><H1><strong>The 3rd ID Hall Of Fame </strong></H1></center><br>
<p>
    <center><font face="Verdana" color="#000000"><H4>The 3rd ID Hall of Fame was 
    created on April 20 of 2005 to honour some of the key members of the [3rd ID] who 
    have contributed to the success and growth of this unit since its inception.&nbsp; 
    </H4></center></p>
<meta name="abstract" content="Call of Duty, Realism, [3rd ID], 3rd ID, 3rd Infantry Division">
<meta name="allow-search" content="YES">
<meta NAME="Keywords" CONTENT="3rd Infantry Division, Call of Duty, CoD">
<meta NAME="Description" CONTENT="3rd Infantry Division - The best military realism gaming community in the USA">
<meta name="searchtitle" content="3rd Infantry Division, Call of Duty, CoD, USA">
<title>3rd Infantry Division: Call of Duty: United Offensive</title>
</head> 
<table border="0" width="94%" cellspacing="0" cellpadding="0" height="8">
  <tr>
  <td align="center" colspan="3"><H4>The Marne Men</H4></td>
  </tr>
  <tr>
    <td align="center" height="21" colspan="3" style="float: left"> 
      <br><img border="0" src="modules/MILPACS/images/hof/man.gif" width="80" height="164">
	  </td>
  </tr>
  <tr> 
    <td align="center" style="border-top:1px double #8A8175; " height="114" colspan="3" valign="top"> 
      <font color="#000000" face="Verdana"><H4>To be inducted 
      into the Marne Men Category, the member must have demonstrated exceptional 
      dedication to the unit and have contributed to the growth of the 3rd ID.&nbsp; 
      Inductees' efforts go above and beyond looking out for their own personal 
      enjoyment and are targeted to enhancing the playing experience and encouraging 
      the camaraderie aspect of the unit.</H4></font></td>
  </tr>
  <tr> 
    <td align="center" style="border-bottom:1px solid #8A8175;" height="14" colspan="3"> 
      <b><font face="Georgia" color="#C4A83C"><H3>Inductees as a 3rd ID Marne Man</H3></font></b></td>
  </tr>
  <tr>
<?php
$sql = "SELECT mm.uniqueid, mm.name, mm.enlistment_dt, mh.hof_dt, mh.category, mh.narrative FROM " . $prefix . "_milpacs_members mm, " . $prefix . "_milpacs_hof mh WHERE mm.uniqueid = mh.uniqueid AND mh.category = 2";
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	$uniqueid = $row["uniqueid"];
	$name = $row["name"];
	$enlisted = $row["enlistment_dt"];
	$inducted = $row["hof_dt"];	
	$narrative = $row["narrative"];
?>
    <td width="24%" align="center" style="border-bottom:1px solid #8A8175;" height="3" rowspan="2" valign="top"> 
      <b><font color="#C0C0C0"><a class="mainroster" href="modules.php?name=<?php echo "$module_name&amp;file=soldierprofile&amp;uniqueid=$uniqueid"; ?>"><?php echo $name; ?></a></font></b></td>
    <td align="left" style="border-bottom:1px solid #8A8175;" height="2" colspan="2"> 
      <font face="Verdana" size="2"><font color="#C0C0C0"> 
      Enlistment Date:</font> <font color="#000000"><?php echo $enlisted; ?></font>&nbsp; &nbsp; <font color="#C0C0C0">Inducted into the Hall of Fame:</font> 
      <font color="#000000"><?php echo $inducted; ?></font></font><br></td>
  </tr>  
  <tr> 
    <td align="left" style="border-bottom:1px solid #8A8175;" height="1" colspan="2"> 
      <font face="Verdana" size="3"><font color="#000000"><?php echo $narrative; ?></font>
	</td>
  </tr>  
   </table>   
  <table border="0" width="94%" cellspacing="0" cellpadding="0" height="8">
  <tr> 
    <tr>
  <td align="center" colspan="3"><H4>The Marne Legend</H4></td>
  </tr>
  <tr>
    <td align="center" height="21" colspan="3" style="float: left"> 
      <br><img border="0" src="modules/MILPACS/images/hof/man.gif" width="80" height="164">
	  </td>
  </tr>
  <tr>  
    <td align="center" style="border-top:1px double #8A8175; " height="12" colspan="3"> 
      <font color="#000000" face="Verdana"><H4>This category, 
      above all, is reserved for people who have served the 3rd ID at the very highest 
      level.&nbsp; Their contribution to the 3rd Infantry Division and all it stands for is possibly 
      attainable by others, but never surpassed.&nbsp; They are the complete package 
      and absolutely irreplaceable. An inductee will have 
      earned the respect of his fellow soldiers and the CoD community through leading 
      by example and mentoring newer players while putting the team ahead of his 
      own personal glory.</H4></font><p>&nbsp;</td>
  </tr>
  </tr>
     <td align="center" style="border-bottom:1px solid #8A8175;" height="14" colspan="3"> 
      <b><font face="Georgia" color="#C4A83C"><H3>Inductees as a 3rd ID Marne Legend</H3></font></b></td>
  </tr>    
  <tr>
<?php
}
$sql = "SELECT mm.uniqueid, mm.name, mm.enlistment_dt, mh.hof_dt, mh.category, mh.narrative FROM " . $prefix . "_milpacs_members mm, " . $prefix . "_milpacs_hof mh WHERE mm.uniqueid = mh.uniqueid AND mh.category = 1";
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	$uniqueid = $row["uniqueid"];
	$name = $row["name"];
	$enlisted = $row["enlistment_dt"];
	$inducted = $row["hof_dt"];	
	$narrative = $row["narrative"];
?>
    <td width="24%" align="center" style="border-bottom:1px solid #8A8175;" height="3" rowspan="2" valign="top"> 
      <b><font color="#C0C0C0"><a class="mainroster" href="modules.php?name=<?php echo "$module_name&amp;file=soldierprofile&amp;uniqueid=$uniqueid"; ?>"><?php echo $name; ?></a></font></b></td>
    <td align="left" style="border-bottom:1px solid #8A8175;" height="2" colspan="2"> 
      <font face="Verdana" size="2"><font color="#C0C0C0"> 
      Enlistment Date:</font> <font color="#000000"><?php echo $enlisted; ?></font>&nbsp; &nbsp; <font color="#C0C0C0">Inducted into the Hall of Fame:</font> 
      <font color="#000000"><?php echo $inducted; ?></font></font></td>
  </tr>  
  <tr> 
    <td align="left" style="border-bottom:1px solid #8A8175;" height="1" colspan="2"> 
      <font face="Verdana" size="3"><font color="#000000"><?php echo $narrative; ?></font>
	</td>
	</tr>	
  <tr>
<?php
}
echo "</table>";
CloseTable();
@include_once("footer.php");
?>