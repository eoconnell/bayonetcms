***********************************************************************************
* MILPACS - Military Personnel and Classification System
* 
* � 2006 - Donovan [3rd ID]
* donovan _at_3rd-infantry DOT com
* 
* MILPACS is a PHPNuke module designed and offered to the First Person Shooter (FPS) Tactical Realism (TR) community.
*
* This is release candiate 1, beta version.  (RC1_b)
*
* 
* Created by: Donovan [3rd ID] http://www.3rd-infantry-division.net  
************************************************************************************

* This version of MILPACS will work on 7.x, although it has been created and tested on phpnuke 7.3 and 7.6 
* The creator nor the [3rd ID] are responsible for any losses whatsoever to your database or files.

************************************************************************************

CREDITS:  Thanks to the following people for all they did helping me with MILPACS.  They put up with at least 1000 questions from this PHP noob. :) 
Raven at ravenphpscripts.com
Kevin (kguske) at ravenphpscripts.com
Evaders99 at ravenphpscripts.com
Telli at codezwiz.com
The people at phpbuilder.com
Geary [3rd ID] for testing

Finally thanks to the 75th Rangers for deveoping thier MILPERS module.  Their work inspired me to develop my own module.
If MILPERS would have been available to the public then MILPACS would have never been born. :)

************************************************************************************


Installation Guide:
Unpack the zip to a folder on your hard drive

Edit the file modules/MILPACS/includes/milpacs.inc.php

1.  If you have vWar installed you do the following to link vWar to MILPACS, else you can skip to step 2.

During the installation for vWar you are asked -- "Number of VWar-Installation, if there's already an existing installation of vwar, 
please enter a prefix which will signify this installation" --   What they are doing is setting a value for  $n = ""
If you enter a number such as "1" then this will place a suffix on your vWar table names.
Make sure to make these two the same.  Whatever you set your $n variable to in vWar make it the same for MILPACS.
If you don't know what $n was set to during the initial setup of vWar you will have to access the config file
modules\vwar\includes\_config.inc and see what was written for this value.
(With this option you can link your vWar tables to the MILPACS soldierprofile page and display records in the Combat Record.


2.  Set the value for $recruitemail = "";
This is the email address that the enlistment page needs to send recruitment emails.
Don't forget to set up this email address in your cpanel on your host.
You can then forward your recruitment email address to whoever your want in your unit.

3.  Open your modules/MILPACS/language/lang-english.php  and set the following to your site.

define("_MILPACS_UNIT", ""); ...example...define("_MILPACS_UNIT", "3rd Infantry Division");  
define("_MILPACS_TAG", "");  ...example...define("_MILPACS_TAG", "[3rd ID]");
define("_MILPACS_NAME", ""); ...example...define("_MILPACS_NAME", "Marne Man");

Make other edits in this file and put your "unit tag" in such as for these lines.
define("_FBTHANKSFORCONTACT"
define("_WEARIT"

4. * NOTE* For PHPNuke version 7.6 and greater, a new folder called custom_files was added.
If you are running PHPNuke prior to 7.6 then you will have another option.
Instead of adding custom_header.php to the html/includes/custom_files directory you may need to add this in your header.php instead.
Add it to the top of your file above the <?php

//Calendar script for MILPACS popup calendar

 <script language="javascript" src="cal2.js">
/*
Xin's Popup calendar script-  Xin Yang (http://www.yxscripts.com/)
Script featured on/available at http://www.dynamicdrive.com/
This notice must stay intact for use
*/
</script>
<script language="javascript" src="cal_conf2.js"></script>

// END


5.  Upload all files from the package to your webspace of you Nuke install, please NOTE that all files must go in the right folder!!

README.txt (do not upload, your reading it)
html/*.* ---------------------------> root/*.*
html/blocks/*.* --------------------> root/blocks/*.*
html/includes/*.* ------------------> root/includes/*.*
html/modules/*.* -------------------> root/modules/*.*
* root = the root directory of your site, usually public_html or similiar.



6.  Database Instructions:
- Using phpmyadmin of your webhost click on the SQL tab and browse to the milpacs.sql and upload the file
- and click "Go" to create the MILPACS tables in your Nuke database.
- This will also preload the administrative password which is "admin" without the quotes.  You can change it later in the admin menu.
- You can also set the Drill Password as well.

 I have made two default pack files if you choose to use them.
 One contains the weapon images for the default WWII U.S. Army, and the weapons.sql to import to your weapons table.
 The other is the rank images for the default WWII U.S. Army, and ranks.sql  to import to the ranks table.

 You can load these or come up with your own if you want.  Images files will have to be ftp'd to there respective places for you
 to see them in the admin menu for ranks or weapons.  Insert the ranks.sql or weapons.sql into your database like before using phpmyadmin.

 Ranks - modules/MILPACS/images/ranks  ( large and small images are needed)
 Weapons - modules/MILPACS/images/weapons

 IMPORTANT NOTE**  You must have weapons and ranks loaded before you add soldiers to your roster.
 Soldiers without rank id or weapons id will not show in the admin menu or the public roster.
 It is reccomended that after you create units and add soldiers to those units, that the unit is not deleted afterwards.
 If so you would have orphaned records in your database.  
 
 Soldiers belonging to units that no longer exist is a bad thing ..no?


Please contact me if you find some bugs. (I'm sure you will find some)

Post in the MILPACS support forums at http://www.3rd-infantry-division.net, or shoot me a PM.

Regards
1Lt. Donovan [3rd ID]
MILPACS Developer