***********************************************************************************
* MILPACS - Military Personnel and Classification System
* 
* � 2006 - Donovan [3rd ID]
* donovan _at_3rd-infantry DOT com
* 
* MILPACS is a PHPNuke module designed and offered to the First Person Shooter (FPS) Tactical Realism (TR) community.
*
* REPEAT it is PHPNUKE module.  I do not support any other CMS including Nuke Evolution.
*
* This is release candiate 2, beta version.  (RC2)
*
* 
* Created by: Donovan [3rd ID] http://www.3rd-infantry-division.net  
************************************************************************************

* This version of MILPACS will work on 7.5 and greater, although it was initialy created on PHPNuke 7.3 it is no longer
* compatible with earlier version. 
* The creator nor the [3rd ID] are responsible for any losses whatsoever to your database or files.

************************************************************************************

CREDITS:  Thanks to the following people for all they did helping me with MILPACS.  They put up with at least a 1000 questions from this rookie. 
Raven at ravenphpscripts.com
Kevin (kguske) at ravenphpscripts.com
Evaders99 at ravenphpscripts.com
Montego at ravenphpscripts.com
Telli at codezwiz.com
The people at phpbuilder.com
The people at phpfreaks.com

I like to thank the following for testing, and helping me find bugs.
Geary [3rd ID]
-SWAT-sniper
CGSEAL
Copeland [45th ID]

Big thanks to Howard of the 505pir.com for making all the additional weapons for Allied and Axis.

Hope I haven't forgotton anybody.



************************************************************************************


Installation Guide:
Unpack the package to a folder on your hard drive

Edit the file modules/MILPACS/includes/milpacs.inc.php

1.  If you have vWar installed then do the following, else you can skip to step 2.
- Set a value for $n = ""; in the milpacs.inc.php file.
- Open the file html\modules\MILPACS\includes\milpacs.inc.php
- During the instructions for vWar they ask you to set a value for  $n = ""
- With this option you can install more than one VWar.
  the vwar install says If you set the value to $n = "1" this will place a suffix on your vWar table name such as vwar1_members
- All you need to do is duplicate this here so you can link your vWar tables to the MILPACS soldierprofile page and display records
  in the Combat Record.


2. For PHPNuke version 7.6 and greater, a new folder called custom_files was added. If you are running PHPNuke prior to 7.6,
instead of adding custom_header.php to the html/includes/custom_files directory you may need to add this in your header.php instead.
Add it to the top of your file above the <?php

//Calendar script for MILPACS popup calendar

 <script language="javascript" src="cal2.js">
/*
Xin's Popup calendar script-  Xin Yang (http://www.yxscripts.com/)
Script featured on/available at http://www.dynamicdrive.com/
This notice must stay intact for use
*/
</script>
<script language="javascript" src="cal_conf2.js"></script>

// END


3.  Upload all files from the package to your webspace of you Nuke install, please NOTE that all files must go in the right folder!!

README.txt (do not upload, your reading it)
html/milpacs_install.php -----------> PHP-Nuke_root/milpacs_install.php
html/milpacs_installer -------------> PHP-Nuke_root/milpacs_installer
html/images/admin/*.* --------------> PHP-Nuke_root/images/admin/*.*
html/blocks/*.* --------------------> PHP-Nuke_root/blocks/*.*
html/includes/*.* ------------------> PHP-Nuke_root/includes/*.*
html/modules/*.* -------------------> PHP-Nuke_root/modules/*.*
* PHP-Nuke_root = the root directory of your site, usually public_html or similiar.

In addition you can remove the following files if they exist.

html/milpacs.php
html/modules/MILPACS/hof.php
html/modules/MILPACS/points.php
html/modules/MILPACS/sotm.php
html/modules/MILPACS/drillaccess.php
html/modules/MILPACS/editsotm.php
html/modules/MILPACS/logindrill.php

These were ideas that never evolved into a worthwhile addition.


4. Install Instructions:
- Login to you site as the administrator using admin.php (http://www.yoursite.com/admin.php).
- Then run the install script called milpacs_install.php (http://www.yoursite.com/milpacs_install.php). If you are installing for
  the first time choose "First Time Install" option and then click on the "COMMIT" button.
   (This will install the tables you will need in your database.)
   Once that is done then remove the milpacs_install.php script and milpacs_installer directory from your server.

5. Upgrade Instructions:
- Login to you site as the administrator using admin.php (http://www.yoursite.com/admin.php).
- Run the install/upgrade script called milpacs_install.php (http://www.yoursite.com/milpacs_install.php).
- Simply choose the "upgradeRC1-RC2" option and then click on the "COMMIT" button.
- (This will update the tables you will need in your database.)
   Once that is done then remove the milpacs_install.php script and milpacs_installer directory from your server.

6. Activate the MILPACS module, and create your block.  


 I have made two default pack files if you choose to use them.
 One contains the images for U.S. Army allied weapons and the weapons.sql to import to your weapons table.
 The other is the rank images and ranks.sql for U.S. Army ranks of World War II.

 You can load these or come up with your own if you want.  Images files will have to be ftp'd to there respective places for you
 to see them in the admin menu for ranks or weapons.  Insert the ranks.sql or weapons.sql into your database using phpmyadmin.

 Ranks - modules/MILPACS/images/ranks  ( large and small images are needed)
 Weapons - modules/MILPACS/images/weapons

 IMPORTANT NOTE**  You no longer need weapons and ranks loaded before you add soldiers to your roster.
 They will now show on the roster but will be "unassigned".

 However, you still need to assign soldiers to units before they are displayed.
 I have added validation to error check this, but make sure you add your soldiers to units.
 Of course you will have to create your Combat Units first.  This is one of the first things your should do.


Please contact me if you find some bugs. (I'm sure you will find some)

Post in the MILPACS support forums at http://www.3rd-infantry-division.net, or shoot me a PM.

View the MILPACS development site at http://milpacs.3rd-infantry-division.net

Regards
1Lt. Donovan [3rd ID]
MILPACS Creator & Developer