<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Medal Page                                            */
/*********************************************************/

if (!defined('MODULE_FILE')) { 
    die ("You can't access this file directly..."); 
} 

define('INDEX_FILE', true);
$index = 1;
@include_once("header.php");
global $module_name, $db, $admin_file, $prefix;
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
OpenTable();

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name];
$unit_tag = $info[unit_tag];

?>
  <table border="0"><tr><td width="100%">
  <font class="content"><big><b><?=$unit_name?> Medals</b></big></font><hr width="100%" align="center">
  </td></tr></table>
  <?php
  CloseTable();
  OpenTable();
  ?>
  <TABLE cellSpacing="0" cellPadding="0" width="100%" border="1">
  <BODY>
  <br>
  <font class="content" align="center">The practice of awarding medals to the common soldier started long ago.  The first formal system for rewarding acts of individual gallantry by this nation's fighting men was established by General George Washington on August 7, 1782. Designed to recognize "any singularly meritorious action," the award consisted of a purple cloth heart.
  <br>
  <br>
  World War I saw the first Victory Medal and the use of devices such as stars, oak leafs and bars to denote additional awards or campaigns. New decorations were added to maintain the prestige of the Medal of Honor. 
  <br>
  <br>
  World War II saw the award system expand to provide a wider degree of decorations for valor and merit and more service medals to signify campaigns in Europe, Asia and the Americas.
  <br>
  <br>
  The <?=$unit_tag?> continues this time honored tradition of recognizing individual gallantry on the field of battle.
  <br>
  <br>
  </TABLE>
  <!-- Header row for Individual Medal table  -->  
  <table border="1" width='100%' cellpadding='3'><tr><th width='100%'>Individual Medals</th></table>
  <table border="1" width='100%' cellpadding='3'><tr><th width='20%'>Image</th><th width='30%'><b>Name</b></th><th width='50%'>Description</th>
  <?php
  $result = $db->sql_query("SELECT award_image, award_name, award_description, award_class FROM " . $prefix . "_milpacs_awards WHERE award_class = 'Individual Medal' ORDER BY award_id");

while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	// Populate award page from database
	$ai = "<img src='modules/MILPACS/images/medals/$row[award_image]'>"; 
	?>
    <TR>
	<td width="20%" align="center"><?php echo $ai ?></td>
	<td width="20%" align="left"><?php echo $row[award_name] ?></td>
	<td width="60%" align="left"><?php echo $row[award_description] ?></td>
	</TR>
    <?php
}          
?>
</TABLE>

<!-- Header row for Unit Citations table -->
<table border="1" width='100%' cellpadding='3'><tr><th width='100%'>Combat Unit Citations</th></table>
<table border="1" width='100%' cellpadding='3'><tr><th width='20%'>Image</th><th width='30%'><b>Name</b></th><th width='50%'>Description</th>
<?php
$result = $db->sql_query("SELECT award_image, award_name, award_description, award_class FROM " . $prefix . "_milpacs_awards WHERE award_class = 'Unit Citation' ORDER BY award_id");
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	// Populate award page from database
	$ai = "<img src='modules/MILPACS/images/medals/$row[award_image]'>";
	?>
	<TR>
	<td width="20%" align="center"><?php echo $ai ?></td>
	<td width="20%" align="left"><?php echo $row[award_name] ?></td>
	<td width="60%" align="left"><?php echo $row[award_description] ?></td>
	</TR>
	<?php
}
?>
</TABLE>

<!-- Header row for Skill Badges table -->
<table border="1" width='100%' cellpadding='3'><tr><th width='100%'>Skill Badges</th></table>
<table border="1" width='100%' cellpadding='3'><tr><th width='20%'>Image</th><th width='30%'><b>Name</b></th><th width='50%'>Description</th>
</tr>
<?php
$result = $db->sql_query("SELECT award_image, award_name, award_description, award_class FROM " . $prefix . "_milpacs_awards WHERE award_class = 'Skill Badge' ORDER BY award_id");
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	// Populate award page from database
	$ai = "<img src='modules/MILPACS/images/medals/$row[award_image]'>";
	?>
	<TR>
	<td width="20%" align="center"><?php echo $ai ?></td>
	<td width="20%" align="center"><?php echo $row[award_name] ?></td>
	<td width="60%" align="left"><?php echo $row[award_description] ?></td>
	</TR>
	<?php
}
?>
</TABLE>
<?php
CloseTable(); 
@include_once("footer.php"); 
?>