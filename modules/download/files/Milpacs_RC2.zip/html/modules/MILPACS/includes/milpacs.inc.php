<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if (stristr(htmlentities($_SERVER['PHP_SELF']), "milpacs.inc.php")) {
	Header("Location: index.php");
	die();
}

//	With this option you can link your vWar tables to the MILPACS pages.
//  The instructions for vWar ask you to set a value for  $n = "" in the modules/vwar/includes/_config.inc.php page
//  If you set the value to $n = "1" this will place a suffix on your vWar table such as vwar1_xxxxx and allow you
//  to have multiple vWar installs.
//  All you need to do is set this value $n = "" here to the same value you setup in your vWar install.
//  If you don't know what $n was set to during the initial setup of vWar you will have to access the config file
//  modules\vwar\includes\_config.inc and see what was written for this value.
//	--------
// 	
$n = "";

?>