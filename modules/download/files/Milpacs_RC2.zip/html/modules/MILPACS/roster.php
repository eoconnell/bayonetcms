<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if (!defined('MODULE_FILE')) { 
    die ("You can't access this file directly..."); 
} 

define('INDEX_FILE', false);
$index = 0;

//Required Files
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
@get_lang($module_name);
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name]; 

OpenTable();
echo"<SCRIPT LANGUAGE=\"JavaScript\" SRC=\"modules/MILPACS/js/switch.js\"></SCRIPT>"
  . "<table border=0><tr><td width=100%>"
  . "<font class=\"title\"><big><center><b>$unit_name Roster</b></center></big></font><br>"
  . "<form name=\"dropmsgform\">"
  . "Select Roster: "
  . "<select name=\"dropmsgoption\" size=\"1\" onChange=\"expandone()\">"
  . "<option selected>Combat Roster</option>"
  . "<option>Administrative Roster</option>"
  . "<option>Past Member Roster</option>"
  . "</select></form>"
  . "<hr width=200 align=\"left\">"
  . "</td></tr></table>"
 ."";
CloseTable();
?>
<br>
<div id="dropmsg0" class="dropcontent">
<?php
OpenTable();
?>
<H3><center>Combat Roster</center></H3>
<?php

$sql = "SELECT * FROM " . $prefix . "_milpacs_members mm 
INNER JOIN (" . $prefix . "_milpacs_units mu) ON (mu.unit_id = mm.unit_id) 
LEFT JOIN " . $prefix . "_milpacs_weapons mw ON (mw.weapon_id = mm.weapon_id) 
LEFT JOIN " . $prefix . "_milpacs_ranks mr ON (mr.rank_id = mm.rank_id) 
WHERE mm.status IN ('Active','LOA') 
ORDER BY mu.unit_order, mm.subunit_id, mr.rank_order, mm.promotion_dt asc";

$unitname = "";
$subunitName = "";
$ifTitled = false;
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	if ( $unitname != $unit_name ) {
		$unitname = $unit_name;
		$unitnick = $unit_nick;
		?>
		<table border=0 width='100%' cellpadding='5'><tr>
		<table border=0 width='100%' cellpadding='3'><tr><th width='100%'><?php echo $unitname .' '. $unitnick ?></th>
		<?php
		$ifTitled = false;
		$subunitName = "";
	}
	$sql_sub = "SELECT subunit_name FROM " . $prefix . "_milpacs_subunit WHERE subunit_id = '$subunit_id' AND unit_id = '$unit_id'";
	$result_sub = $db->sql_query($sql_sub);
	if ( ( $row_sub = $db->sql_fetchrow($result_sub) ) && ( $subunitName != $row_sub['subunit_name'] ) ) {
		$subunit_name = $row_sub['subunit_name'];
		$subunitName = $subunit_name;
		?>
		<tr><td colspan="6"><table border=0 width='100%' cellpadding='3'><tr><th width='100%' colspan="6"><?php echo $subunitName ?></th>		
		</tr></table></td></tr>
		<?php
	} else if ( ( $subunit_id == 0 ) && ( $subunitName != "NULL" ) ) {
		$subunitName = "NULL";
		$ifTitled = true;
		?>		
		<table border=1 width='100%' cellpadding='3'><tr><th width='11%'>Rank</th><th width='30%'><b>Name</b></th><th width='25%'>Unit</th><th width='25%'>Position</th><th width='14%'>Weapon</th><th width='8%'>Status</th>
		</tr>
		<?php
	}
		//if no rank assigned then display "not assigned"
	if ($row["rank_image"] =="") {
		$ri = "Not Assigned"; 
	} else {
		$ri = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 
	}
	//if no weapon assigned then display "not assigned"
	if ($row["weapon_id"]) { 
    $make = "<a class=\"content\" href=\"modules.php?name=$module_name&amp;file=weaponprofile&amp;weapon_id={$row['weapon_id']}\">$make</a>"; 
	} else { 
    $make = "Not Assigned"; 
	}
	if ( !$ifTitled ) {
		$ifTitled = true;
		?>
		<table border=1 width='100%' cellpadding='3'><tr><th width='11%'>Rank</th><th width='30%'><b>Name</b></th><th width='25%'>Unit</th><th width='25%'>Position</th><th width='14%'>Weapon</th><th width='8%'>Status</th>
		</tr>
		<?php
	}
	?>
	<td width='15%' align='center'><?php echo $ri ?></td><td width='30%'>&nbsp;<a class="content" href="modules.php?name=<?php echo $module_name ?>&amp;file=soldierprofile&amp;uniqueid=<?php echo $uniqueid ?>"><?php echo $u_name ?></a>
	</td><td align='center' width='25%'><a class="content" href="modules.php?name=<?php echo $module_name ?>&amp;file=unitprofile&amp;unit_id=<?php echo $unit_id ?>"><?php echo $unitname ?></a></td><td width='25%' align='center'><?php echo $position ?></td><td width='14%' align='center'><?php echo $make ?></td><td width='8%' align='center'><?php echo $status ?></td>
	</tr>
	<?php
}
echo "</table><br /><hr noShade>";
CloseTable();
?>
</div><div id="dropmsg1" class="dropcontent">
<?php
OpenTable();
?>
<H3><center>Administrative Roster</center></H3>
<?php
$admin_unitname = "";

$sql = "SELECT * FROM " . $prefix . "_milpacs_members mm
INNER JOIN (" . $prefix . "_milpacs_adminunit mau) ON FIND_IN_SET(mau.admin_unit_id,mm.adminunits) > 0
LEFT JOIN " . $prefix . "_milpacs_units mu ON (mu.unit_id = mm.unit_id)
LEFT JOIN " . $prefix . "_milpacs_weapons mw ON (mw.weapon_id = mm.weapon_id) 
LEFT JOIN " . $prefix . "_milpacs_ranks mr ON (mm.rank_id = mr.rank_id) 
WHERE mm.status IN ('Active','LOA') 
ORDER BY mau.admin_unit_name, mr.rank_order, mm.promotion_dt asc";

$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	if ( $admin_unitname != $admin_unit_name) {
			$admin_unitname = $admin_unit_name;
			?>
			<table border=1 width='100%' cellpadding='5'><tr>
			<table border=0 width='100%' cellpadding='3'><tr><th width='100%'><?php echo $admin_unitname ?></th>
			<table border=1 width='100%' cellpadding='3'><tr><th width='11%'>Rank</th><th width='30%'><b>Name</b></th><th width='16%'>Combat Unit</th><th width='25%'>Position</th><th width='14%'>Weapon</th><th width='8%'>Status</th>
			</tr>
			<?php
	}
	if ($row["rank_image"] =="") {
		$ri = "Not Assigned"; 
	} else {
		$ri = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 
	}
	//if no weapon assigned then display "not assigned"
	if ($row["weapon_id"]) { 
    $make = "<a class=\"content\" href=\"modules.php?name=$module_name&amp;file=weaponprofile&amp;weapon_id={$row['weapon_id']}\">$make</a>"; 
	} else { 
    $make = "Not Assigned"; 
	}
	?>
	<td width='15%' align='center'><?php echo $ri ?></td><td width='30%'>&nbsp;<a class="content" href="modules.php?name=<?php echo $module_name ?>&amp;file=soldierprofile&amp;uniqueid=<?php echo $uniqueid ?>"><?php echo $u_name ?></a>
	</td><td align='center' width='16%'><a class="content" href="modules.php?name=<?php echo $module_name ?>&amp;file=unitprofile&amp;unit_id=<?php echo $unit_id ?>"><?php echo $unit_name ?></a><td width='25%' align='center'><?php echo $position ?></td><td width='14%' align='center'><?php echo $make ?></td><td width='8%' align='center'><?php echo $status ?></td>
	</tr>
	<?php
}
echo "</table><br /><hr noShade>";
CloseTable();
?>
</div><div id="dropmsg2" class="dropcontent">
<?php
OpenTable();
?>
<H3><center>Past Members Roster</center></H3>
<?php

$sql = "SELECT * FROM " . $prefix . "_milpacs_members mm
INNER JOIN (" . $prefix . "_milpacs_units mu) ON (mu.unit_id = mm.unit_id)
LEFT JOIN " . $prefix . "_milpacs_weapons mw ON (mw.weapon_id = mm.weapon_id) 
LEFT JOIN " . $prefix . "_milpacs_ranks mr ON (mm.rank_id = mr.rank_id)
WHERE mm.status IN ('Discharged','Retired','Long Term LOA','Reserves') 
ORDER BY mr.rank_order, mu.unit_id, mm.promotion_dt asc";

$wRow =0;
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
    if ( $wRow == 0 ) {
            $wRow++;
			$unitname = $unit_name;
			$unitnick = $unit_nick;
			?>
			<table border=1 width='100%' cellpadding='5'><tr><th width='11%'>Rank</th><th width='30%'><b>Name</b></th><th width='16%'>Combat Unit</th><th width='25%'>Position</th><th width='14%'>Weapon</th><th width='15%'>Status</th>
			</tr>
			<?php
	}
	if ($row["rank_image"] =="") {
		$ri = "Not Assigned"; 
	} else {
		$ri = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 
	}
	//if no weapon assigned then display "not assigned"
	if ($row["weapon_id"]) { 
    $make = "<a class=\"content\" href=\"modules.php?name=$module_name&amp;file=weaponprofile&amp;weapon_id={$row['weapon_id']}\">$make</a>"; 
	} else { 
    $make = "Not Assigned"; 
	}
	?>
	<td width='15%' align='center'><?php echo $ri ?></td><td width='30%'>&nbsp;<a class="content" href="modules.php?name=<?php echo $module_name ?>&amp;file=soldierprofile&amp;uniqueid=<?php echo $uniqueid ?>"><?php echo $u_name ?></a></td><td align='center' width='25%'><a class="content" href="modules.php?name=<?php echo $module_name ?>&amp;file=unitprofile&amp;unit_id=<?php echo $unit_id ?>"><?php echo $unit_name ?></a><td width='25%' align='center'><?php echo $position ?></td><td width='14%' align='center'><?php echo $make ?></td><td width='8%' align='center'><?php echo $status ?></td>
	</tr>
	<?php
}
echo "</table><br /><hr noShade>";
CloseTable();
?>
</div>
<?php
@include_once("footer.php");
?>