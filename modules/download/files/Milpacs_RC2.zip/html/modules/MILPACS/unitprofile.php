<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if (!defined('MODULE_FILE')) { 
    die ("You can't access this file directly..."); 
}

define('INDEX_FILE', false);
$index = 0;

//Required Files
require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
@include_once("header.php");
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

OpenTable();
$unit_id = $_GET['unit_id'];
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_units a JOIN " . $prefix . "_milpacs_members b Where a.unit_id ='$unit_id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}
?>
<center><a href="modules.php?name=MILPACS&file=roster">Back to Roster</a></center>
<br>
<table width="100%" border="2" cellpadding="4" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="650">
		<tr>
			<td align="center" bgcolor= "<?php echo $bgcolor2 ?>"><b>Unit Profile: <?php echo $info[unit_name] .' '. $info[unit_nick] ?></font></b></td>
		</tr>
		<tr>
			<td align="left" bgcolor= "<?php echo $bgcolor1 ?>" valign="top" width="741"><img border="0" src="modules/MILPACS/images/units/<?php echo $info[unit_image] ?>" align="left">
                <p>
                                <P><i><center><font color="#8B0000"><span class="postbody">
                                <?php echo $info[unit_creed] ?></span></font></center></i></p>
                                <i><font color="#FFFF00"><span class="postbody">
                                <?php echo $info[unit_motto] ?></span></font></i></p>
                                
                                
                                <p>
                                <br>
                                <span class="postbody"><?php echo $info[unit_bio] ?></span> </p>
                                
                                <p>
                                <br>
                                <br>
                                <br>
                                <span style="font-weight: 700; font-size: 14px; color: #8B0000;">
                                Platoon Goals:</span></p>
                                <ul>
                                  <li><span class="postbody"><?php echo $info[unit_goal_one] ?>
                                  </span></li>
                                  <li><span class="postbody"><?php echo $info[unit_goal_two] ?>
								   </span></li>
                                  <li><span class="postbody"><?php echo $info[unit_goal_three] ?>
                                </ul>                           
                                
			</td>
	</tr>
		<tr>
			<td align="center" bgcolor= "<?php echo $bgcolor2 ?>"><b>Unit Personnel</font></b></td>
		</tr>
		<tr>
			<td align="left" bgcolor= "<?php echo $bgcolor2 ?>" valign="top" width="741"><table border="1" cellpadding="2" cellspacing="1" width="100%" bordercolor="#111111">
		<tr>
			<td width="23%"><b>Rank</font></b></td>
			<td width="77%"><b>Name</font></b></td>
	</tr>
<?php
	//returns all units personnel assigned to the chosen platoon
$unit_id = $_GET['unit_id'];
$sql = "SELECT mm.u_name, mm.unit_id, mr.rankname, mm.rank_id FROM " . $prefix . "_milpacs_members mm, " . $prefix . "_milpacs_ranks mr, " . $prefix . "_milpacs_units mu WHERE mm.unit_id = '$unit_id' AND mm.rank_id = mr.rank_id AND mm.unit_id = mu.unit_id AND mm.status IN ('Active','LOA') ORDER BY mm.rank_id";
$result1 = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result1) ) {
	extract($row);
?>
	<tr>
		<td width="23%" bgcolor= "<?php echo $bgcolor1?>"><b><?php echo $rankname ?></b></td>
		<td width="77%" bgcolor= "<?php echo $bgcolor1?>"><b><?php echo $u_name ?></b></td>
	</tr>
<?php
}
?>
</table>
</table>
</body>
</html>
<?php
CloseTable();
include("footer.php");
?>