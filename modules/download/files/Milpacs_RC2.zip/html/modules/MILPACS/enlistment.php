<?php 
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net							*/
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Enlistment                                            */
/*********************************************************/
if (!defined('MODULE_FILE')) { 
    die ("You can't access this file directly..."); 
}
define('INDEX_FILE', true);
$index = 1;
@include_once("modules/MILPACS/includes/milpacs.inc.php");
$module_name = "MILPACS";
get_lang($module_name);
@include_once("header.php");

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name];
$unit_tag = $info[unit_tag];
$unit_nick = $info[unit_nick];
$recruitemail = $info[recruitemail];


/**********************************/ 
/* Configuration                  */ 
/*                                */ 
/* You can change this:           */ 
/* $index = 0; (right side off)   */ 
/**********************************/ 
$index = 0; 
$subject = "$unit_name ".Recruitment.""; 
/**********************************/ 
 

if ($cookie[1] != "") { 
    $sql = "SELECT name, username, user_email FROM ".$user_prefix."_users WHERE user_id='$cookie[0]'"; 
    $result = $db->sql_query($sql); 
    $row = $db->sql_fetchrow($result); 
    if ($row[name] != "") { 
   $sender_name = $row[name]; 
    } else { 
   $sender_name = $row[username]; 
    } 
    $sender_email = $row[user_email]; 
} 
OpenTable();
?>
<table border="0" width=100%>
  <tr>
	<th colspan="3" height="25" nowrap="nowrap">&nbsp;Becoming a <?=$unit_nick?>&nbsp;</th>
  </tr>
  <tr>
	<td><span class="gen"> <font class="content">
You need to decide right now that you are 100% sure you want to join this unit before you fill out your enlistment papers. If you are not 100% sure that this is the unit for you, then by all means ask as many questions as you need to. Our soldiers and officers will be more than happy to assist you in any way possible. Once you make your decision, we expect you to stick with it. Commitment is the most important thing in the <?=$unit_name?>. 

If this is indeed what you are looking for and you believe that you have what it takes to become a <?=$unit_name?>, then your next step is Basic Combat Training or BCT. BCT is conducted under proven tactics by experienced Drill Sergeants and is the crucible in which all soldiers are forged into lethal warriors; where a soldier's character is sharpened into the true grit of honor and integrity. It is here where you will have to prove that you have what it takes. Your assignment in BCT will last for five weeks, and here's what you can expect: 
<UL>
<LI><font class="content">You will undergo rigorous training on individual skills and team coordination. 
<LI><font class="content">You will undergo Close Order Rifle Drill (CORD) training until your skill with your weapon is second nature. 
<LI><font class="content">You will be taught the chain of command, rules and regulations, and how to act like a soldier on and off the battlefield 
<LI><font class="content">You will learn to love your Drill Sergeant like your mother, and how to take care of your fellow squad mates like the brothers that they will become. </UL>

<font class="content">It takes effort on your part to be a member of the <?=$unit_name?>. We are a unit of principles and of honor. We do not accept everyone, and only the soldiers that are the true epitome of our expectations will wear the <?=$unit_tag?> tag. Your tenure in BCT is your defining moment. It is the time that you show us that you are indeed <?=$unit_name?> material. 

Are you prepared to take on the task of becoming a <?=$unit_nick?>? 

Then step up and fill out your enlistment papers today! Our recruiters are standing by to assist you in any way. 

Thank you for your interest, and good luck!
</span></td>
  </tr>

</table>

<?php
CloseTable();

OpenTable();
if ($op == "SendEnlistment") {
if ($opi != "ds") { 
    //echo "$block";
} elseif ($opi == "ds") { 
    if ($sender_name == "") { 
   $name_err = "<center><font class=\"option\"><b><i>"._FBENTERNAME."</i></b></font></center><br>"; 
   $send = "no"; 
    } 
    if ($sender_email == "") { 
   $email_err = "<center><font class=\"option\"><b><i>"._FBENTEREMAIL."</i></b></font></center><br>"; 
   $send = "no"; 
    } 
    if ($send != "no") { 
   $sender_name = removecrlf($sender_name); 
   $sender_email = removecrlf($sender_email); 
   $msg = "$sitename\n\n"; 
   $msg .= ""._SENDERNAME.": $sender_name\n"; 
   $msg .= ""._SENDER_CALLSIGN.": $sender_callsign\n"; 
   $msg .= ""._SENDEREMAIL.": $sender_email\n"; 
   $msg .= ""._SENDER_XFIRE.": $sender_xfire\n"; 
   $msg .= ""._WEAPON.": $weapon\n"; 
   $msg .= ""._CLANED.": $claned\n"; 
   $msg .= ""._WHYPLAY.": $whyplay\n"; 
   $msg .= ""._SKILLS_TALENT.": $Skills_Talents\n"; 
   $msg .= ""._ADDITIONAL.": $Additional\n"; 
   $msg .= ""._WEARIT.": $wearit\n";     
   $mailheaders = "From: $sender_name <$sender_email>\n"; 
   $mailheaders .= "Reply-To: $sender_email\n\n"; 
   mail($recruitemail, $subject, $msg, $mailheaders); 
   echo "<P><center><b><FONT SIZE=6  COLOR=#00FF00>"._FBMAILSENT."</FONT></center></p>"; 
   echo "<P><center><b><FONT SIZE=6  COLOR=#00FF00>"._FBTHANKSFORCONTACT."</FONT></center></p>"; 
    } elseif ($send == "no") { 
   OpenTable2(); 
   echo "$name_err"; 
   echo "$email_err"; 
   echo "$message_err"; 
   CloseTable2(); 
   echo "<br><br>"; 
   //echo "$block";    
    } 
}
}

?>
<html>
<head>
<title>Recruitment</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>
<body bgcolor= <?php echo $bgcolor2 ?>><table width="100%" border="1" cellspacing="1" cellpadding="1">
<tr><td>
      <center><b><font face="Army, Army Condensed, Army Expanded, Army Hollow, Army Thin, Army Wide"><h2><?=$unit_name?> Enlistment Form</h2></font></b></center>
     <font face="Army, Army Condensed, Army Expanded, Army Hollow, Army Thin, Army Wide"><br>
      <br><center><b>Are you ready to become a <?=$unit_nick?>?</b><br>
      <b>Are you are looking for a serious realism unit, dedicated to emulating actual tactics used in World War Two?</b><br>
      <b>Do you believe that character and values are among the most important traits to look for in a unit, regardless of personal skill?</b><br>
      <b>Are you looking for an atmosphere that will take you back to 1940�s Europe, both in game and in our forums?</b><br>
      <b>Are you willing to have fun?</b><br>
      <b>Then the <?=$unit_tag?> is for you!</b>
   </center></font>   
<form name="enlistment" action="modules.php?name=MILPACS&file=enlistment" method="post">
      <INPUT type="hidden" name="opi" value="ds">
      <TABLE BORDER="0" WIDTH="100%">
        <TR>
          <TD COLSPAN="2" ALIGN="CENTER"> <font class="content">Please provide the following contact information:</font></TD>
        </TR>
        <TR>
          <TD ALIGN="RIGHT" WIDTH="50%"><b>Please provide your real name:</b><br></font></TD>
          <TD ALIGN="LEFT" WIDTH="50%"><INPUT type="text" NAME="sender_name" VALUE="" SIZE=30></font></TD>
        </TR>
        <TR>
          <TD ALIGN="RIGHT"><b>Please provide your Call of Duty name:</b><br></TD>
          <TD><INPUT type="text" NAME="sender_callsign" VALUE="" SIZE=30></TD>
        </TR>        
        <TR>
          <TD ALIGN="right"><b>Please provide your Xfire name: </b><FONT COLOR=RED>(Xfire required)</FONT></TD>
          <TD><INPUT type="text" NAME="sender_xfire" VALUE="" SIZE=30></TD>
        </TR>
        <TR>
          <TD ALIGN="right"><b>Primary weapon of choice</b>: </TD>
          <TD ALIGN="LEFT"><B>
		  <SELECT NAME="weapon">
              <OPTION VALUE="---">Pick One</OPTION>
              <OPTION VALUE="M1 Garand">M1 Garand</OPTION>
              <OPTION VALUE="M1 Carbine">M1 Carbine</OPTION>
              <OPTION VALUE="Thompson SMG M1A1">Thompson SMG M1A1</OPTION>
              <OPTION VALUE="Browning Automatic Rifle (BAR) M1918A2">Browning
              Automatic Rifle (BAR) M1918A2</OPTION>
            </SELECT>
            </B></TD>
        </TR>
      </table>
      <table>
        <TR>
          <TD VALIGN="MIDDLE" ALIGN="right"><b>Have you ever been in a realism unit before</b>: </TD>
          <TD ALIGN="LEFT"><INPUT TYPE="RADIO" NAME="claned" VALUE="Yes" CHECKED> Yes <INPUT TYPE="RADIO" NAME="claned" VALUE="No"> No </TD>
        </TR>
        <TR>
          <TD VALIGN="TOP" ALIGN="right"> <b>Why do you play Call of Duty?</b> </TD>
          <TD ALIGN="LEFT"><TEXTAREA NAME="whyplay" ROWS="5" COLS="35"></TEXTAREA></TD>
        </TR>
        <TR>
          <TD VALIGN="TOP" ALIGN="right"><b>What skill,talent or other item will you bring to the unit?</b> </TD>
          <TD ALIGN="LEFT"><TEXTAREA NAME="Skills_Talents" ROWS="5" COLS="35"></TEXTAREA></TD>
        </TR>
        <TR>
          <TD VALIGN="TOP" ALIGN="right"><b>Any additional comments or things we should know?</b></TD>
          <TD ALIGN="LEFT"><TEXTAREA NAME="Additional" ROWS="5" COLS="35"></TEXTAREA></TD>
        </TR>
        <TR>
          <TD VALIGN="MIDDLE" ALIGN="right" WIDTH="40%"><b>Are you willing to wear the <?=$unit_tag?> tag after your name at all times?</b>: </TD>
          <TD ALIGN="left"><INPUT TYPE="RADIO" NAME="wearit" VALUE="Yes" CHECKED> Yes <INPUT TYPE="RADIO" NAME="wearit" VALUE="No"> No </TD>
        </TR>
        <TR>
          <TD COLSPAN="2" ALIGN="CENTER"><p> Please note
              that applying does not mean you are in the <?=$unit_tag?>. You'll be watched
              closely on the forum and in game on our server for a length of time.
              Stay active on the server and on the forums (cant stress this enough).
              If you display the dedication, commitment, maturity, and will uphold
              the honor of the <?=$unit_name?>, then after this trial period
              will you be given your draft notice and recruited.
              Skill alone does not determine admittance, as attitude plays a big
              part in the decision as well.<b> Please visit our forums and post this same
              information in the Recruitment forums.</b>This way your enlistment is tracked in
              two different places and will not get lost.  Welcome to the <?=$unit_name?> Forums
             <p>Good luck Soldier!!</p></TD>
        </TR>
        <TR>
          <TD COLSPAN="2" ALIGN="CENTER"><INPUT TYPE="submit" NAME="op" VALUE="SendEnlistment">
            <INPUT TYPE="reset"VALUE="Reset"></TD>
        </TR>
      </TABLE>
    </FORM></center>
        </td></TR>
      </TABLE>
</body>
</html>
<?php

CloseTable();      
@include_once("footer.php"); 
?> 