<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net							*/
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

//Edit to your specs

define("_MILPACS_MENU", "MILPACS");
define("_FBTHANKSFORCONTACT", "Thank you for enlisting.  Soldier...FRONT AND CENTER!  Your next task will be to post this same information in the Recruitment Forum.");
define("_FBMAILSENT","Enlistment notice has been sent!");
define("_SENDERNAME","Your Name");
define("_SENDER_CALLSIGN", "Your in-game call sign");
define("_SENDEREMAIL", "Your e-mail address");
define("_SENDER_ICQ", "Your ICQ info");
define("_WEAPON", "Your prefered weapon");
define("_CLANED", "Have you ever been in a realism clan before");
define("_WHYPLAY", "Why do you play on our server");
define("_SKILLS_TALENT", "What skill do you bring");
define("_ADDITIONAL",  "Additional Info");
define("_WEARIT", "Will you wear our tag?");
?>