<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Weapon Profile                                        */
/*********************************************************/

if (!defined('MODULE_FILE')) { 
    die ("You can't access this file directly..."); 
} 

define('INDEX_FILE', false);
$index = 0;

//Required Files
require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
@include_once("header.php");
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

OpenTable();
$weapon_id = $_GET['weapon_id'];
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_weapons WHERE weapon_id = '$weapon_id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}
?>
<!-- Display page -->
<center><a href="modules.php?name=MILPACS&file=weapon">Back to Arsenal</a></center>
<br>
<table border="2" align="center" cellpadding="4" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="675">
      <tr>
         <td align="center" bgcolor= "<?php echo $bgcolor2 ?>"><b>Profile of <?php echo $info[make] ." ". $info[model] ?></b></td>
      </tr>    
	  <tr>
         <td align="center" bgcolor= "<?php echo $bgcolor1 ?>" valign="top"><img border="0" src="modules/MILPACS/images/weapons/<?php echo $info[weapon_image] ?>"></td>
      </tr>   
	  <tr>
         <td align="left" bgcolor= "<?php echo $bgcolor2 ?>"><b>Weapon Statistics</font></b></td>
      </tr>
	  <tr>
      <td align="center"><table border="1" align="center" cellpadding="2" cellspacing="1" style="border-collapse: collapse;" width="100%" id="AutoNumber1" bordercolor="#111111">
                  <td width="15%" align="right"><b>Make and Model:</font></b></td>
                  <td width="30%" colspan="2"><font class="content"><?php echo $info[make] .' '. $info[model] ?></td>
                  <td width="15%" align="right"><b>Class of Weapon:</font></b></td>
                  <td width="40%" colspan="5"><font class="content"><?php echo "$info[weapon_class]"; ?></td>
               </tr>
               <tr>
                  <td width="12%" align="right"><b>Caliber:</font></b></td>
                  <td width="10%"><font class="content"><?php echo $info[caliber] ?></td>
                  <td width="18%"><p align="right"><b>Rounds:</b></font></td>
                  <td width="7%"><font class="content"><?php echo $info[rounds] ?></td>
                  <td width="18%"><p align="right"><b>Weight:</b></font></td>
                  <td width="7%"><font class="content"><?php echo $info[weight] ?></td>
               </tr>
				 <tr>
                  <td width="18%" align="right"><b>Date of Introduction:</font></b></td>
                  <td width="80%" colspan="5"><font class="content"><?php echo $info[intro_dt] ?></td>
               </tr>
                <tr>
                  <td width="12%" align="right"><b>Type of Fire:</font></b></td>
                  <td width="80%" colspan="5"><font class="content"><?php echo $info[type_fire] ?></td>
               </tr>
                <tr>
                  <td width="12%" align="right"><b>Rate of Fire:</font></b></td>
                  <td width="80%" colspan="5"><font class="content"><?php echo $info[rate_fire] ?></td>
               </tr>
                <tr>
                  <td width="12%" align="right"><b>Effective Range:</font></b></td>
                  <td width="80%" colspan="5"><font class="content"><?php echo $info[eff_range] ?></td>
               </tr>
                <tr>
                  <td width="12%" align="right"><b>Maximum Range:</font></b></td>
                  <td width="80%" colspan="5"><font class="content"><?php echo $info[max_range] ?></td>
               </tr>
                </table>
                <tr>
         <td align="left" bgcolor= "<?php echo $bgcolor2 ?>"><b>Decription</font></b></td>
      </tr>
	  <tr>
         <td align="left"><font class="content"><b><?php echo $info[weapon_descr] ?></b></td>
      </tr>
</table>
<?php
CloseTable();
@include_once("footer.php");
?>