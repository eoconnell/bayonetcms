<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if ( !defined('MODULE_FILE') )
{
	die("You can't access this file directly...");
}

define('INDEX_FILE', true);
$index = 1;
@require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);

global $module_name, $db, $prefix;
@include_once("header.php");
OpenTable();
$sql = "SELECT motd FROM " . $prefix . "_milpacs_main";
$result = $db->sql_query($sql);
$row = $db->sql_fetchrow($result);
$info = $row["motd"];
?>
<table border=0><tr><td width=100%>
<font class="title"><big><center><b>Military Personnel and Classification System</b></center></big></font><hr width=100% align="center">
</td></tr></table>
<table border=0><tr><td width=100%>
<big><center><b><?php echo $info ?></b></center></big></td></tr></table>
<br/><br/>
<table border="0" width=100%>
<tr>
<td width=20% align=center class=menu><a href="modules.php?name=<?php echo $module_name ?>&amp;file=roster">Roster</a></td>
<td width=20% align=center class=menu><a href="modules.php?name=<?php echo $module_name ?>&amp;file=award">Medals</a></td>
<td width=20% align=center class=menu><a href="modules.php?name=<?php echo $module_name ?>&amp;file=weapon">Weapons</a></td>
<td width=20% align=center class=menu><a href="modules.php?name=<?php echo $module_name ?>&amp;file=enlistment">Enlistment</a></td>
</tr>
</table>
<?php
CloseTable();
echo "<br>";
@include_once("footer.php");
?>
