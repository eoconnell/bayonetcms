<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Ranks page                                            */
/*********************************************************/

if (!defined('MODULE_FILE')) { 
    die ("You can't access this file directly..."); 
} 

define('INDEX_FILE', true);
$index = 1;

//Required Files
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name]; 
OpenTable();
echo"<table border=0><tr><td width=100%>"
  . "<font class=\"title\"><big><b>Ranks of the $unit_name</b></big></font><hr width=200 align=\"left\">"
  . "</td></tr></table>"
  .""
  ."<br>";
CloseTable();
OpenTable();
?>
<br>
<br>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Rank Image</th><th width="15%">Rank Name</th><th width="15%"><b>Abbreviation</b><tr>
<?php

$sql2 = "SELECT mr.rank_id, mr.rank_image, mr.rankname, mr.rank_abbr, mr.rank_order FROM " . $prefix . "_milpacs_ranks mr ORDER BY mr.rank_order";
$result2 = $db->sql_query($sql2);	
while ( $row = $db->sql_fetchrow($result2) ) {
	$abbr = $row["rank_abbr"];
//	$image = $row["rank_image"];
	$rankname = $row["rankname"];

	if ($row["rank_image"] =="") {
		$image = "&nbsp;"; 
	} else {
		$image = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 

	}
	?>
	<tr>
		<td align="center" width="15%"><b><?php echo $image ?></font></b></td>
		<td align="center" width="15%"><b><?php echo $rankname ?></font></b></td>
		<td align="center" width="15%"><b><?php echo $abbr ?></font></b></td>		
	<?php
}

?>
</table>
<?php
CloseTable();
include("footer.php");
?>