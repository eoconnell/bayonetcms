<?php 
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if (!defined('MODULE_FILE')) { 
    die ("You can't access this file directly..."); 
} 

require_once("mainfile.php"); 
$module_name = basename(dirname(__FILE__)); 
get_lang($module_name); 
global $prefix, $db; 

/* Get list of valid authors */
$row = $db->sql_fetchrow($db->sql_query("SELECT title, admins FROM ".$prefix."_modules WHERE title='$module_name'"));
$row2 = $db->sql_fetchrow($db->sql_query("SELECT name, radminsuper FROM ".$prefix."_authors WHERE aid='$aid'"));
$admins = explode(",", $row['admins']);
$auth_user = 0;
for ($i=0; $i < sizeof($admins); $i++) {
    if ($row2['name'] == "$admins[$i]" AND $row['admins'] != "") {
        $auth_user = 1;   
    }
}

//Store logged username 
$nukeusername = $userinfo['username']; 

$sql = "SELECT * FROM ".$prefix."_milpacs_members WHERE nukeusername = '$nukeusername' AND ismember = '1'"; 
   $result = $db->sql_query($sql); 
   if  ($db->sql_numrows($result) > 0) { 	   
       session_start(); 
       $_SESSION['loggedin1'] = 1;       
       Header("Location: modules.php?name=MILPACS&file=viewdrill"); 
		} else {         
       session_start(); 
       $_SESSION['loggedin1'] = 0;       
       Header("Location: modules.php?name=MILPACS&file=accessdenied"); 
    } 	
?>