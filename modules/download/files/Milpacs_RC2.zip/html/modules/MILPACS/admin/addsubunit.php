<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Sub Unit                                          */
/*********************************************************/

if ( !defined('ADMIN_FILE')) {
	die("Illegal File Access");
}

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $admin_file, $bgcolor1, $bgcolor2;

// Add values to subunit table
if ($op == "NewSubUnit") {			
		$unit_id = intval($_POST['parent_unit']);
		$subunit_name = $_POST['subunit_name'];
		

	$sql = "INSERT INTO " . $prefix . "_milpacs_subunit (
		subunit_id,
		subunit_name,
		unit_id
		) VALUES (
			'NULL',
			'$subunit_name',
			'$unit_id'
			)";
	$result = $db->sql_query($sql);
		
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		}
		else {
			Header("Location: /admin.php?op=milpacs");
}
}
OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo "<form name=\"addsubunit\" action=\"".$admin_file.".php\" method=\"post\">";
?>
<!-- Display Form -->
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="100%">
<tr>
 <td align="center" bgcolor= "<?php echo $bgcolor2 ?>">SubUnit of 
<select name="parent_unit">
<?
$sql2 = "SELECT unit_id, unit_name FROM " . $prefix . "_milpacs_units ORDER BY unit_order";
$result2 = $db->sql_query($sql2);
while ( $row2 = $db->sql_fetchrow($result2) ) {
   $selected = "";
   echo "<option value=\"" . $row2['unit_id'] . "\" $selected >" . $row2['unit_name'] . "</option>";   
}
?>
</select>		
         </td>
       </tr>
	   <tr>
         <td align="center" bgcolor= "<?php echo $bgcolor1 ?>"> Unit Name <input type="text" name="subunit_name"></td>      
		</tr>
		</table>
<br>
<input type="hidden" name="op" value="NewSubUnit"/>
<input type="hidden" name="unit_id" value="<?php echo $unit_id ?>"/>
<input type="submit" align="center" name="Submit" value="Add"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>