 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Rank                                             */
/*********************************************************/
if ( !defined('ADMIN_FILE')) {
	die("Illegal File Access");
}

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
global $module_name, $db, $admin_file, $prefix, $bgcolor1, $bgcolor2; 

// Load Small Rank image
$IMAGEPATH = $_SERVER['DOCUMENT_ROOT'];
	$urlofimages="$IMAGEPATH/modules/MILPACS/images/ranks/small/";
	$smallrankselecthtml = "<select name=\"rank_image\">";
	$smallrankselecthtml .= "<option value=\"\">Select Small Rank Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$rank_image) {
					$smallrankselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$smallrankselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$samllrankselecthtml .= "</select></td>";

// Load Large Rank image
	$urlofimages="$IMAGEPATH/modules/MILPACS/images/ranks/large/";
	$largerankselecthtml = "<select name=\"rank_image_l\">";
	$largerankselecthtml .= "<option value=\"\">Select Large Rank Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$rank_image) {
					$largerankselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$largerankselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$largerankselecthtml .= "</select></td>";

	// Add data to Ranks table
if ($op == "NewRank") {

		$rankname = $_POST['rankname'];
		$rank_abbr = $_POST['rank_abbr'];
		$rank_image = $_POST['rank_image'];
		$rank_image_l = $_POST['rank_image_l'];
		$rank_order = $_POST['rank_order'];
		//Insert the values into the database 
	$sql = "INSERT INTO " . $prefix . "_milpacs_ranks (rank_id, rankname, rank_abbr, rank_image, rank_image_l, rank_order)". "VALUES ('NULL','$rankname','$rank_abbr','$rank_image','$rank_image_l','$rank_order')";
	$result = $db->sql_query($sql);
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		}		
		Header("Location: /admin.php?op=AddRank");
}

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name];
$unit_tag = $info[unit_tag];

OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo " <form name=\"addrank\" action=\"".$admin_file.".php\" method=\"post\">";
?>	
 <table width="100%" border="2" cellpadding="2" align ="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111">
  <tr>
           <td align="center" bgcolor= "<?php echo $bgcolor2 ?>">
              <b><font class="content"><?php echo"$unit_name"?> Ranks <?php echo $rank_name ?></font></b>
           </td>
         <tr>
  			<td align="left" bgcolor= "<?php echo $bgcolor2 ?>">
  			 <b>Rank Information</font></b>
  			</td>
  		</tr>
  <table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Small Rank Image</th><th width='30%'>Large Rank Image</th><th width='20%'><b>Rank Name</b></th><th width='10%'><b>Rank Abbreviation</b></th><th width='10%'><b>Rank Order</b></th></tr>  
		<tr>
			<td align="center" size="20"> <?php echo $smallrankselecthtml ?>
			</td>
			<td align="center" size="20"> <?php echo $largerankselecthtml ?>
			</td>
			<td align="center"><input type="text" size="30" name="rankname">
			</td>
			<td align="center"><input type="text" size="20" name="rank_abbr">
			</td>
			<td align="center"><input type="text" size="5" name="rank_order">
			</td>
      </tr>
</table>
<br>
<br>
<hr>
<input type="hidden" name="op" value="NewRank">
<input type="hidden" name="rank_id" value="<?php echo $rank_id ?>"/>
<input type="submit" align="center" name="Submit" value="Add"/>
</form>
<?php
CloseTable();
OpenTable();
?>
<br>
<br>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Rank Image</th><th width="15%">Rank Name</th><th width="15%"><b>Order</b><tr>
<?php

$sql2 = "SELECT mr.rank_id, mr.rank_image, mr.rankname, mr.rank_order FROM " . $prefix . "_milpacs_ranks mr ORDER BY mr.rank_order";
$result2 = $db->sql_query($sql2);	
while ( $row = $db->sql_fetchrow($result2) ) {
	$order = $row["rank_order"];
//	$image = $row["rank_image"];
	$rankname = $row["rankname"];

	if ($row["rank_image"] =="") {
		$image = "&nbsp;"; 
	} else {
		$image = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 

	}
	?>
	<tr>
		<td align="center" width="15%"><b><?php echo $image ?></font></b></td>
		<td align="center" width="15%"><b><?php echo $rankname ?></font></b></td>
		<td align="center" width="15%"><b><?php echo $order ?></font></b></td>		
	<?php
}

?>
</table>
<?php
CloseTable();
include("footer.php");
?>