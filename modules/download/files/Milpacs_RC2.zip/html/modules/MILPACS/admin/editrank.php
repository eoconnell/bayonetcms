 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Ranks                                            */
/*********************************************************/
if (!defined('ADMIN_FILE')) { 
die ("Access Denied"); 
} 

define('INDEX_FILE', true);
$index = 1;
require_once("mainfile.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
@include_once("header.php");
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

// Update values in rank table
if ($op == "SaveRank") {		 
			$sql = "UPDATE " . $prefix . "_milpacs_ranks SET rankname = '$rankname', rank_abbr = '$rank_abbr', rank_image = '$rank_image', rank_image_l = '$rank_image_l', rank_order = '$rank_order' WHERE rank_id = '$id'";		
		$result = $db->sql_query($sql);
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	}
}

// Display page with values from the ranks table

	$id = intval($_GET['id']);
	$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_ranks WHERE rank_id ='$id'");
	$info = $db->sql_fetchrow($result);
	if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	} else {
		$rankname = $info[rankname];		
		$rank_abbr = $info[rank_abbr];
		$rank_order = $info[rank_order];
		$rank_image = $info[rank_image];
		$rank_image_l = $info[rank_image_l];
	}


// Load Small Rank image
$IMAGEPATH = $_SERVER['DOCUMENT_ROOT'];
	$urlofimages="$IMAGEPATH/modules/MILPACS/images/ranks/small/";
	$smallrankselecthtml = "<select name=\"rank_image\">";
	$smallrankselecthtml .= "<option value=\"\">Select Small Rank Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$rank_image) {
					$smallrankselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$smallrankselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$samllrankselecthtml .= "</select></td>";


// Load Large Rank image
	$urlofimages="$IMAGEPATH/modules/MILPACS/images/ranks/large/";
	$largerankselecthtml = "<select name=\"rank_image_l\">";
	$largerankselecthtml .= "<option value=\"\">Select Large Rank Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$rank_image_l) {
					$largerankselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$largerankselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$largerankselecthtml .= "</select></td>";
	
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name];
$unit_tag = $info[unit_tag];

OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo " <form name=\"editrank\" action=\"".$admin_file.".php\" method=\"post\">";

?>
<!-- Display Form -->
 <table width="100%" border="2" cellpadding="2" align ="center" cellspacing="0" style="border-collapse: collapse;" bgcolor="#000000" bordercolor="#111111">
  <tr>
           <td align="center" bgcolor= "<?php echo $bgcolor2 ?>">
              <b><?php echo"$unit_name"?> Ranks <?php echo $rankname ?></font></b>
           </td>
         <tr>
  			<td align="left" bgcolor= "<?php echo $bgcolor2 ?>"><b>Rank Information</font></b>
  			</td>
  		</tr>
  <table border=0 width='100%' cellpadding='3'><tr><th width='20%'>Small Rank Image</th><th width='30%'>Large Rank Image</th><th width='20%'><b>Rank Name</b></th><th width='10%'><b>Rank Abbreviation</b></th><th width='10%'><b>Rank Order</b></th></tr>  
		<tr>
			<td align="center" size="20"> <?php echo $smallrankselecthtml ?>
			</td>
			<td align="center" size="20"> <?php echo $largerankselecthtml ?>
			</td>
			<td align="center"><input type="text" size="20" name="rankname" value="<?php echo $rankname ?>">
			</td>
			<td align="center"><input type="text" size="15" name="rank_abbr" value="<?php echo $rank_abbr ?>">
			</td>
			<td align="center"><input type="text" size="5" name="rank_order" value="<?php echo $rank_order ?>">
			</td>
      </tr>
</table>
<br>
<br>
<hr>
<input type="hidden" name="op" value="SaveRank">
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Update"/>
</form>
<?php
CloseTable();
include("footer.php");
?>