<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Info                                             */
/*********************************************************/

if (!defined('ADMIN_FILE')) { 
die ("Access Denied"); 
} 

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $admin_file, $bgcolor1, $bgcolor2;

if ($op != "UpdateInfo") {
	$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
	$info = $db->sql_fetchrow($result);
	$unit_name = $info[unit_name];
	$unit_tag = $info[unit_tag];
	$unit_nick = $info[unit_nick];
	$motd = stripslashes($info[motd]);	
	$recruitemail = $info[recruitemail];
	
	// Update Main Information
	} elseif($op == "UpdateInfo") {		
		$sql = "UPDATE " . $prefix . "_milpacs_main set
				unit_name = '$unit_name',				
				unit_tag = '$unit_tag',
				unit_nick = '$unit_nick',
				motd = '$motd',
				recruitemail = '$recruitemail'";
				$result = $db->sql_query($sql);
		}

OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo "<form name=\"editinfo\" action=\"".$admin_file.".php\" method=\"post\">";
?>
<br>
<HR>
<table border="2" align="center" width="100%">
	<tr>
		<td width="70%" align="right"><b>Unit Name: </b></td>
		<td width="30%"><font class="content"><input type="text" size="50" name="unit_name" value="<?php echo $unit_name ?>"></td>
	</tr>
	<tr>
		<td width="70%" align="right"><b>Unit Nickname: </b></td>
		<td width="30%"><font class="content"><input type="text" size="50" name="unit_nick" value="<?php echo $unit_nick ?>"></td>
	</tr>
		<td width="70%" align="right"><b>Unit Tag: </b></td>
		<td width="30%"><font class="content"><input type="text" size="50" name="unit_tag" value="<?php echo $unit_tag ?>"></td>
	<tr>
		<td width="70%" align="right"><b>Recruitment Email: </b></td>
		<td width="30%"><font class="content"><input type="text" size="50" name="recruitemail" value="<?php echo $recruitemail ?>"></td>
	</tr>
	<tr>
		<td width="70%" align="right"><b>Information Page: </b></td>		
		<td width="30%"><font class="content"><textarea name="motd" cols="70" colspan="1" rows="12"><?php echo $motd ?></textarea></td>
	</tr>	
</table>
<br>
<hr>
<input type="hidden" name="op" value="UpdateInfo">
<input type="submit" align="center" name="Submit" value="Update">
</form>
<?php
CloseTable();
@include_once("footer.php");
?>