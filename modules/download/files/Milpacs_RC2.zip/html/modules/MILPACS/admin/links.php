<?php
/************************************************************/
/* MILPACS (Military Personell and Classification System)   */
/* Author::Donovan [3rd ID]								    */
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]*/
/* Email:: donovan@3rd-infantry-division.net                */
/* Homepage::http://www.3rd-infantry-division.net		 	*/
/************************************************************/

if(!defined('ADMIN_FILE')) {
    Header("Location: ../../admin.php");
    die();
}
$modname = "MILPACS";
get_lang($modname);
if ($radminsuper==1 || $auth_user == 1) {
    adminmenu("admin.php?op=milpacs", _MILPACS_MENU, "milpacs.png");
}

?>
