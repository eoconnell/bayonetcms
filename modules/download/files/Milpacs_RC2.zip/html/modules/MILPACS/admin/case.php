<?php

/************************************************************************/
/* PHP-NUKE: Web Portal System                                          */
/* ===========================                                          */
/*                                                                      */
/* Copyright (c) 2002 by Francisco Burzi                                */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/

/*************************************************************/
/* MILPACS (Military Personell and Classification System)    */
/* Author::Donovan [3rd ID]									 */
/* Copyright (c) 2006 by Steven Donovan AKA Donovan [3rd ID] */
/* Email:: donovan@3rd-infantry-division.net			     */
/* Homepage::http://www.3rd-infantry-division.net			 */
/*************************************************************/

if ( !defined('ADMIN_FILE') )
{
	die("Illegal File Access");
}

$module_name = "MILPACS";
//include_once("modules/$module_name/language/lang-".$currentlang.".php");

switch($op) {
	    case "milpacs":
		case "UpdateInfo":
		case "EditInfo":
		case "ViewMainInfo":
		case "AddMedal":
		case "NewMedal":
		case "SaveMedal":
		case "DelMedal":
		case "ConfirmDelMedal":
		case "AddRank":
		case "NewRank":
		case "EditRank":
		case "SaveRank":
		case "DelRank":
		case "ConfirmDelRank":
		case "AddSoldier":
		case "DelSoldier":
		case "ConfirmDelSoldier":	
		case "NewSoldier":
		case "EditSoldier":
		case "SaveSoldier":
		case "AddWeapon":
		case "NewWeapon":
		case "EditWeapon":
		case "SaveWeapon":
		case "DelWeapon":
		case "ConfirmDelWeapon":
		case "AddServiceRecord":
		case "NewServiceRecord":
		case "AddMedalRecord":
		case "SaveMedalRecord":
		case "NewMedalRecord":
		case "AddDrillReport":
		case "NewDrillReport":
		case "SaveDrillReport":
		case "EditDrillReport":			
		case "AddUnit":
		case "NewUnit":
		case "AddSubUnit":
		case "NewSubUnit":
		case "AddAdminUnit":
		case "EditAdminUnit":
		case "SaveAdminUnit":
		case "NewAdminUnit":
		case "EditMedal":			
		case "EditServiceRecord":
		case "SaveServiceRecord":
		case "EditMedalRecord":		
		case "EditSubUnit":
		case "SaveSubUnit":	
		case "EditUnit":
		case "SaveUnit":
		case "EditWar":	
		case "SaveWar":
		case "EditService":
		case "DelServiceRecord":	
		case "DelMedalRecord":		
		case "DelSubUnit":
		case "ConfirmDelSubUnit":
		case "DelUnit":
		case "ConfirmDelUnit":	
		case "DelAdminUnit":
		case "ConfirmDelAdminUnit":
		case "ServiceRecord":
		case "MedalRecord":		
				
include("modules/$module_name/admin/index.php");
	break;
}

?>