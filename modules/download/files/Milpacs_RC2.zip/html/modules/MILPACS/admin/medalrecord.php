 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Soldier Medal Record                                  */
/*********************************************************/
if ( !defined('ADMIN_FILE')) {
	die("Illegal File Access");
}

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

$id = $_GET['id'];
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_award_lkup lkup JOIN " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
}
OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
?>
<table border="2" cellpadding="2" align ="center" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111" width="100%">
	<tr>
           <td align="center" bgcolor= <?php echo $bgcolor2 ?>><b><font class="title">Medal Record of <?php echo $info[u_name] ?></font></b></td>
    <tr>
  			<td align="left"><b><font class="content">Awards & Recognition</font></b></td>
  	</tr>
	<tr>
		<td align="left"><b><font class="content"><a href="admin.php?op=AddMedalRecord&amp;id=<?php echo $id ?>" title="Add">Add a New Medal</a></font></b>
		</td>
	</tr>
<table border=0 width='100%' cellpadding='3'><tr><th width='45%'>Medal Name</th><th width='15%'>Date of Award</th><th width='50%'><b>Award Details</b></th></tr>
<?php	
$sql = "SELECT lkup.pid, ma.award_name, ma.award_id, lkup.adetails, date_format(lkup.award_dt,'%e %b %Y') as award_dt, lkup.uniqueid FROM " . $prefix . "_milpacs_award_lkup lkup, " . $prefix . "_milpacs_awards ma WHERE lkup.uniqueid ='$id' AND ma.award_id = lkup.award_id";
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	$pid = $row["pid"];
	$award_name = $row["award_name"];
	$award_id = $row["award_id"];
	$date = $row["award_dt"];	
	$details = $row["adetails"];
?>
	<tr>
		<td align="center"><fieldset><?php echo $award_name ?>&nbsp<a href="admin.php?op=EditMedalRecord&amp;pid=<?php echo $pid ?>" title="Edit"><img src="modules/MILPACS/images/pencil.gif"></a>&nbsp &nbsp<a href="admin.php?op=DelMedalRecord&amp;pid=<?php echo $pid ?>" title="Delete"><img src="modules/MILPACS/images/delete.png"></a></fieldset></td>
		<td align="left"><fieldset><?php echo $date ?></fieldset></td>
	    <td align="left"><fieldset><?php echo $details ?></fieldset></td>
	</tr>
<?php
}
?>
</table>
<br>
<?php
CloseTable();
include("footer.php");
?>