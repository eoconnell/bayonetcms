<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Delete Service Record                                 */
/*********************************************************/

if ( !defined('ADMIN_FILE')) {
	die("Illegal File Access");
}

define('INDEX_FILE', false);
$index = 0;
include_once("header.php");
global $module_name, $db, $prefix;

if ($op == "DelServiceRecord") {
	$record_id = intval($_GET['record_id']);
	$result = $db->sql_query("SELECT uniqueid FROM " . $prefix . "_milpacs_service_record WHERE record_id ='$record_id'");
	$info = $db->sql_fetchrow($result);
    $id = $info[uniqueid];
	$sql = "DELETE FROM " . $prefix . "_milpacs_service_record WHERE record_id ='$record_id'";	
	$result = $db->sql_query($sql);
	Header("Location: /admin.php?op=ServiceRecord&id=$id");	
	}
?>