<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Soldier Medal Record                             */
/*********************************************************/

if (!defined('ADMIN_FILE')) { 
die ("Access Denied"); 
} 

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $admin_file, $bgcolor1, $bgcolor2;

if ($op == "SaveMedalRecord") {
	// Validations go here	
	$date = explode("-",$award_dt,3);
	$date[0] = intval($date[0]);
	$date[1] = intval($date[1]);
	$date[2] = intval($date[2]);
	if(checkdate($date[1],$date[2],$date[0])) {
		$dt_error = "";
		$dt_valid = true;
	} else {
		$dt_error = "Error: Date is invalid.  Please enter date in the yyyy-mm-dd format.";
		$dt_valid = false;
	}	
	if ($dt_valid) {		
			$sql = "UPDATE " . $prefix . "_milpacs_award_lkup SET
				award_id = '$award_id',
				award_dt = '$award_dt',
				adetails = '$adetails'
			 WHERE pid = '$pid'";
		}
		$result = $db->sql_query($sql);
		Header("Location: /admin.php?op=MedalRecord&id=$id");
}
//Display page
	$result = $db->sql_query("SELECT uniqueid, award_id, award_dt, adetails FROM " . $prefix . "_milpacs_award_lkup WHERE pid ='$pid'");
	$info = $db->sql_fetchrow($result);
    if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	} else {
		$id = $info[uniqueid];
		$award_id = $info[award_id];
		$award_dt = $info[award_dt];
		$adetails = $info[adetails];
   }

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
} else {
	$u_name = $info[u_name];
}
OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo "<p><a href=\"admin.php?op=MedalRecord&id=$id\">Return to Medal Record</a></p>";
echo "<form name=\"editmedalrecord\" action=\"".$admin_file.".php\" method=\"post\">";
?>
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="100%">
	<tr>
		<td align="center" bgcolor= "<?php echo $bgcolor2 ?>">
		<b><font color="#000000">Medal Record of <?php echo $u_name ?></font></b>
		</td>	
<table border=0 width="100%" cellpadding="3">
	<tr>
		<th width="40%">Medal Name</th>
		<th width="25%">Date of Award</th>
		<th width="35%"><b>Award Details</b></th>
	</tr>
	<tr>
		<td align="left" bgcolor= "<?php echo $bgcolor1 ?>">
		<select name="award_id" size="1">
		<option value="">--- Select Medal ---</option>
<?php
$result = $db->sql_query("SELECT award_id, award_name FROM " . $prefix . "_milpacs_awards");
while ( $row = $db->sql_fetchrow($result) ) {
	$award_name = $row["award_name"];
	$medal_id = $row["award_id"];
	if ($medal_id == $award_id) {
		echo "<option selected value='$medal_id'>$award_name</option>";
	} else {
		echo "<option value='$medal_id'>$award_name</option>";
	}
}
?>
		</select>
		</td>
		<td align="center" bgcolor= "<?php echo $bgcolor1 ?>">
		<input type="text" name="award_dt" value="<?php echo $award_dt ?>">
		<a href="javascript:showCal('EditMedalDate');"><img src="modules/MILPACS/images/icon_calendar.gif" title="Select Date" alt="Select Date"></a>
		<font style="color: red;"><?php echo $dt_error ?></font>
		</td>
		<td align="left" bgcolor= "<?php echo $bgcolor1 ?>">
		<textarea name="adetails" cols="30" colspan="1" rows="4"><?php echo $adetails ?></textarea>
		</td>
	</tr>
</table>
<br>
<input type="hidden" name="op" value="SaveMedalRecord"/>
<input type="hidden" name="pid" value="<?php echo $pid ?>"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Update"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>