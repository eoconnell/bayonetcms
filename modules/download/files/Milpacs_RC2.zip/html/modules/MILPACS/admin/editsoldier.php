<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/
/*********************************************************/
/* Edit Soldier                                          */
/*********************************************************/

if (!defined('ADMIN_FILE')) { 
die ("Access Denied"); 
} 

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $admin_file, $bgcolor1, $bgcolor2;
$IMAGEPATH = $_SERVER['DOCUMENT_ROOT'];

	if ($op == "SaveSoldier") {
	// Validations go here
	// If all validations passed, save and exit, otherwise, redisplay with errors
	$id = intval($_POST['id']);
	$ismember = $_POST['ismember'];
	$rank_id = intval($rank_id);
	$unit_id = intval($unit_id);
	$weapon_id = intval($weapon_id);
	$subunit_id = intval($subunit_id);
	$adminunits;
	$num_of_adminunits = sizeof($_POST[admin_unit_id]);
	$k = 0;
	for ($i=0; $i < $num_of_adminunits; $i++) {
		$ifDuplicated = false;
		$test_for_duplication = explode(",",$adminunits);
		if ($_POST[admin_unit_id][$i]) {
			for ($j=0; $j < sizeof($test_for_duplication); $j++) {
				if ($_POST[admin_unit_id][$i] == $test_for_duplication[$j])
					$ifDuplicated = true;
			}
			if (!$ifDuplicated) {
				if ($k > 0)
					$adminunits .= ",";
				$adminunits .= $_POST[admin_unit_id][$i];
				$k++;
			}
		}
	}
//		Order in increasing numerical order
	$admin_array = explode(",",$adminunits);
	sort($admin_array);
	$adminunits = "";
	for ($i=0; $i <= sizeof($admin_array); $i++) {
		if ($admin_array[$i] != "")
			$adminunits .= $admin_array[$i] . ",";
	}
//	$email = addslashes($email);
	$bio = addslashes($bio);
	$sql = "UPDATE " . $prefix . "_milpacs_members set
		uniform = '$uniform',
		rank_id = '$rank_id',
		ismember = '$ismember',
		flag = '$flag',
		u_name = '$soldierName',
		nukeusername = '$nukeusername',
		location = '$location',
		status = '$status',
		p_mos = '$p_mos',
		unit_id = '$unit_id',
		subunit_id = '$subunit_id',
		adminunits = '$adminunits',
		reports = '$reports',
		position = '$position',
		weapon_id = '$weapon_id',
		enlistment_dt = '$enlistment_dt',
		promotion_dt = '$promotion_dt',
		xfire = '$xfire',
		email = '$email',
		bio = '$bio'
		WHERE uniqueid ='$id'";
	$update = $db->sql_query($sql);
}

	// If not saving, load values from database
if ($op != "SaveSoldier") {
	$id = intval($_GET['id']);
	$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_members mm
	INNER JOIN (" . $prefix . "_milpacs_units mu) ON (mm.unit_id = mu.unit_id)
	LEFT JOIN " . $prefix . "_milpacs_weapons mw ON (mw.weapon_id = mm.weapon_id)
	WHERE mm.uniqueid ='$id'");
	$info = $db->sql_fetchrow($result);		 
	if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	} else {
		$soldierName = $info['u_name'];
		$nukeusername = $info['nukeusername'];
		$ismember = $info['ismember'];
		$uniform = $info['uniform'];
		$rank_id = $info['rank_id'];
		$flag = $info['flag'];
		$location = $info['location'];
		$status = $info['status'];
		$p_mos = $info['p_mos'];
		$unit_id = $info['unit_id'];
		$subunit_id = $info['subunit_id'];
		$adminunits = $info['adminunits'];
		$reports = $info['reports'];
		$position = $info['position'];
		$weapon_id = $info['weapon_id'];
		$qual = $info['qual'];
		$enlistment_dt = $info['enlistment_dt'];
		$promotion_dt = $info['promotion_dt'];
		$xfire = $info['xfire'];
		$email = $info['email'];
		$bio = stripslashes($info['bio']);
	}
}

// Load Uniform images (Rank, Flag)
$urlofimages="$IMAGEPATH/modules/MILPACS/images/uniform/";
$uniformselecthtml = "<select name=\"uniform\">";
$uniformselecthtml .= "<option value=\"\">Select Uniform Image</option>";
if ($handle=@opendir($urlofimages)) { 
	while ($imgfile = readdir($handle)) {
		if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
			if ($imgfile==$uniform) {
				$uniformselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
			} else {
				$uniformselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
			}
		}
	}
	@closedir($handle);
}
$uniformselecthtml .= "</select>";
// Load Ranks
$rankselecthtml = "<select name=\"rank_id\">";
$rankselecthtml .= "<option value=\"\">Select Rank</option>";
$result2 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_ranks order by rankname");
while ($rankrow = $db->sql_fetchrow($result2)) {
	if ($rankrow[rank_id]==$rank_id) {
		$rankselecthtml .= "<option value =\"$rankrow[rank_id]\" selected>$rankrow[rankname]</option>";
	} else {
		$rankselecthtml .= "<option value =\"$rankrow[rank_id]\" >$rankrow[rankname]</option>";
	}
}
$rankselecthtml .= "</select>";
// Load Flag images
$urlofimages="$IMAGEPATH/modules/MILPACS/images/flags/";
$flagselecthtml = "<select name=\"flag\">";
$flagselecthtml .= "<option value=\"\">Select Flag Image</option>";
if ($handle=@opendir($urlofimages)) { 
	while ($imgfile = readdir($handle)) {
		if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
			if ($imgfile==$flag) {
				$flagselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
			} else {
				$flagselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
			}
		}
	}
	@closedir($handle);
}
$flagselecthtml .= "</select>";

// Load Weapons
$weaponselecthtml = "<select name=\"weapon_id\">";
$weaponselecthtml .= "<option value=\"\">Select Weapon</option>";
$result3 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_weapons order by make");
while ($weaponrow = $db->sql_fetchrow($result3)) {
	if ($weaponrow[weapon_id]==$weapon_id) {
		$weaponselecthtml .= "<option value =\"$weaponrow[weapon_id]\" selected>$weaponrow[make]</option>";
	} else {
		$weaponselecthtml .= "<option value =\"$weaponrow[weapon_id]\" >$weaponrow[make]</option>";
	}
}
$weaponselecthtml .= "</select>";

// Load Unit
$unitselecthtml = "<select name=\"unit_id\">";
$unitselecthtml .= "<option value=\"\">Select Unit</option>";
$result4 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_units order by unit_name");
while ($unitrow = $db->sql_fetchrow($result4)) {
	if ($unitrow[unit_id]==$unit_id) {
		$unitselecthtml .= "<option value =\"$unitrow[unit_id]\" selected>$unitrow[unit_name]</option>";
	} else {
		$unitselecthtml .= "<option value =\"$unitrow[unit_id]\" >$unitrow[unit_name]</option>";
	}
}
$unitselecthtml .= "</select>";

// Load Status
$statusselecthtml = "<select name=\"status\">\n<option value=\"\">Select Status</option>";
$wStatus = array("Active", "LOA", "Long Term LOA", "Retired", "Discharged");
for ($i=0; $i < sizeof($wStatus); $i++) {
	if ($status == $wStatus[$i])
		$statusselecthtml .= "<option value='$wStatus[$i]' selected>$wStatus[$i]</option>";
	else
		$statusselecthtml .= "<option value='$wStatus[$i]'>$wStatus[$i]</option>";
}
$statusselecthtml .= "</select>";

// Load Subunit
$subunitselecthtml = "<select name=\"subunit_id\">\n<option value=\"\">Select Subunit</option>";
$result5 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_subunit WHERE unit_id = '$unit_id' ORDER BY subunit_name");
while ($subunit_row2 = $db->sql_fetchrow($result5)) {
	if ($subunit_row2[subunit_id] == $subunit_id)
		$subunitselecthtml .= "<option value =\"$subunit_row2[subunit_id]\" selected>$subunit_row2[subunit_name]</option>";
	else
		$subunitselecthtml .= "<option value =\"$subunit_row2[subunit_id]\">$subunit_row2[subunit_name]</option>";
}
$subunitselecthtml .= "</select>";

// Load Admin Units
$num_of_admin_units = 0;
$adminunitselecthtml = "";
$result8 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_adminunit");
while ( $adminunits_row = $db->sql_fetchrow($result8) ) {
	$num_of_admin_units++;
}
$adminunitarray = explode(",",$adminunits);
$noa_admin_units = sizeof($adminunitarray);
for ($i=0; $i < $noa_admin_units; $i++) {
	if ($i > 0)
		$adminunitselecthtml .= "<br>\n";
	$adminunitselecthtml .= "<select name=\"admin_unit_id[]\">\n<option value=\"\">Add New Admin Unit</option>";
	$result7 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_adminunit ORDER BY admin_unit_name");
	while ( $adminunit_row = $db->sql_fetchrow($result7) ) {
		$adminunit_id[$i] = $adminunit_row[admin_unit_id];
		$adminunit_name[$i] = $adminunit_row[admin_unit_name];
		if ($adminunit_id[$i] == $adminunitarray[$i-1])
			$adminunitselecthtml .= "<option value=\"$adminunit_id[$i]\" selected>$adminunit_name[$i]</option>";
		else
			$adminunitselecthtml .= "<option value=\"$adminunit_id[$i]\">$adminunit_name[$i]</option>";
	}
	$adminunitselecthtml .= "</select>";
}

OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo " <form name=\"editsoldier\" action=\"".$admin_file.".php\" method=\"post\">";
?>
<table width="100%" border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111">
	<tr>
		<td align="center" bgcolor= "<?php echo $bgcolor2 ?>"><b><font class="title">Personnel File of <?php echo $soldierName ?></font></b></td>
	</tr>	
	<tr>
		<td align="center"> Uniform image: <?php echo $uniformselecthtml ?></td>
	</tr>
	<tr>
		<td align="center"> Rank image: <?php echo $rankselecthtml ?></td>
	</tr>
	<tr>
		<td align="center"> Flag image: <?php echo $flagselecthtml ?></td>
	</tr> 
	<tr> 
   <td align="center">Is Member: <input type="checkbox" name="ismember" value="1" <?php if($ismember == "1"){echo " CHECKED";}?>>            
   </tr>	
</table>
<table width="100%" border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111">
	<tr>
		<td height="25" colspan="2" align="left" bgcolor= <?php echo $bgcolor1 ?>><b><font class="title">Vital Statistics</font></b></td>
	</tr>
	<tr>
		<td align="center">
<table width="100%" border="1" cellpadding="2" cellspacing="1" style="border-collapse: collapse;" id="AutoNumber1" bordercolor="#111111"> 
		</td>
	<tr>
		<td width="50%" align="right"><b><font class="content">Name:</font></b></td>
		<td width="50%"><input type="text" name="soldierName" value="<?php echo $soldierName ?>"/></td>
	</tr>
	<tr>
          <td width="50%" align="right"><b><font class="content">(For Drill Access) Nuke Name:</font></b></td>
		  <td width="50%"><input type="text" name="nukeusername" value="<?php echo $nukeusername ?>"/></td>
    </tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Location:</font></b></td>
		<td width="50%"><input type="text" name="location" value="<?php echo $location ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Status:  </font></b></td>
		<td width="50%"><?php echo $statusselecthtml ?></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content"><b>Primary MOS:</b></font></td>
		<td width="50%"><input type="text" name="p_mos" value="<?php echo $p_mos ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Combat Unit:</font></b></td>
		<td width="50%"><?php echo $unitselecthtml ?></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Combat Subunit:</font></b></td>
		<td width="50%"><?php echo $subunitselecthtml ?></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Admin Units:</font></b></td>
		<td width="50%"><?php echo $adminunitselecthtml ?></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Reports to:</font></b></td>
		<td width="50%"><input type="text" name="reports" value="<?php echo $reports ?>"/></td>		
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Position:</font></b></td>
		<td width="50%"><input type="text" name="position" value="<?php echo $position ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content"><b>Weapon:</b></font></td>
		<td width="50%"><?php echo $weaponselecthtml ?></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content"><b>Qualifications:</b></font></td>
		<td width="50%"><input type="text" name="qual" value="<?php echo $qual ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Enlisted Date:</font></b></td>
		<td width="50%"><input type="text" name="enlistment_dt" value="<?php echo $enlistment_dt ?>"/>
		<a href="javascript:showCal('Enlistment');"><img src="modules/MILPACS/images/icon_calendar.gif" title="Select Date" alt="Select Date"></a>
		</td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Promoted Date:</font></b></td>
		<td width="50%"><input type="text" name="promotion_dt" value="<?php echo $promotion_dt ?>"/>
		<a href="javascript:showCal('Promoted');"><img src="modules/MILPACS/images/icon_calendar.gif" title="Select Date" alt="Select Date"></a>
		</td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Xfire:  </font></b></td>
		<td width="50%"><input type="text" name="xfire" value="<?php echo $xfire ?>"/></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">E-mail:</font></b></td>
		<td width="50%"><input type="text" name="email" size="35" maxlength="35" value="<?php echo $email ?>"/></td>
	</tr>
</table>
</table>
<table width="100%" border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111">
	<tr>
		<td align="left" bgcolor= "<?php echo $bgcolor1 ?>"><b><font class="title">Personal Bio</font></b></td>
	</tr>
	<tr>
		<td align="left"><textarea name="bio" cols="80" colspan="1" rows="8"><?php echo $bio ?></textarea></td>
	</tr>
</table>
<br>
<input type="hidden" name="op" value="SaveSoldier"/>
<input type="hidden" name="profilename" value="<?php echo $soldierName ?>"/>
<input type="hidden" name="nukename" value="<?php echo $nukeusername ?>"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" class="button" align="center" value="Update"/>
</form>
<?php
CloseTable();
include_once("footer.php");
?>