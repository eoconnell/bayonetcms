<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Soldier Service Record                            */
/*********************************************************/

if ( !defined('ADMIN_FILE')) {
	die("Illegal File Access");
}

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

if ($op == "NewServiceRecord") {
	// Validations go here
	// If all validations passed, save and exit, otherwise, redisplay with errors
	$record_id = intval($_POST['record_id']);
	$id = intval($_POST['id']);
	$record_dt = addslashes($_POST['record_dt']);
	$date = explode("-",$record_dt,3);
	$date[0] = intval($date[0]);
	$date[1] = intval($date[1]);
	$date[2] = intval($date[2]);
	if(checkdate($date[1],$date[2],$date[0])) {
		$dt_error = "";
		$dt_valid = true;
	} else {
		$dt_error = "Error: Date is invalid.  Please enter date in the yyyy-mm-dd format.";
		$dt_valid = false;
	}
	$details = addslashes($_POST['details']);
	if ($dt_valid) {		
			$sql = "INSERT INTO " . $prefix . "_milpacs_service_record (
				 record_id, 
				 uniqueid, 
				 record_dt, 
				 details
				 ) VALUES (
				 null, 
				 $id, 
				 '$record_dt', 
				 '$details'
				 )";
		} 
		$result = $db->sql_query($sql);
		Header("Location: /admin.php?op=ServiceRecord&id=$id");
}
$result1 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result1);
if (!$result1) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
} else {
	$u_name = $info[u_name];
}
OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo " <form name=\"addservicerecord\" action=\"".$admin_file.".php\" method=\"post\">"
?>
<br>
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="100%">
	<tr>		
		<th width="100%"><b><font class="content" bgcolor= "<?php echo $bgcolor2 ?>">Add Service Record for <?php echo $u_name ?></font></b></th>
	</tr>
</table>
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="100%">
	<tr>
		<td width="50%" align="right"><b><font class="content">Record Date:</font></b></td>
		<td width="50%"><input type="text" name="record_dt" value="<?php echo $record_dt ?>">
		<a href="javascript:showCal('addServiceRecord');"><img src="modules/MILPACS/images/icon_calendar.gif" title="Select Date" alt="Select Date"></a>
		<font style="color: red;"><?php echo $dt_error ?></font></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Details:</font></b></td>
		<td width="50%"><textarea name="details" cols="60" colspan="1" rows="4"><?php echo $details ?></textarea></td>
	</tr>	
</table>
<br>
<input type="hidden" name="op" value="NewServiceRecord"/>
<input type="hidden" name="record_id" value="<?php echo $record_id ?>"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Add"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>