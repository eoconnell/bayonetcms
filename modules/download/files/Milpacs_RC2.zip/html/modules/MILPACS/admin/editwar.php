<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if (!defined('ADMIN_FILE')) { 
die ("Access Denied"); 
} 

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
get_lang($module_name);
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;
@include("modules/MILPACS/includes/milpacs.inc.php");
$warid = $_GET['warid'];

if ($op == "SaveWar") {
	// Validations go here	

	$result1 = $db->sql_query("SELECT * FROM vwar" . $n . " v JOIN vwar" . $n . "_opponents vo JOIN vwar" . $n . "_matchtype vmt WHERE v.status = 1 AND v.oppid = vo.oppid AND warid = '$warid'");
	if (!$result1) {
		    echo("<p>Error accessing war data!" . mysql_error() . "</p>");
	}
	while ($row = $db->sql_fetchrow($result1)) {
		$oppid = $row["oppid"];
		$sql = "SELECT mm.uniqueid, mm.unit_id, mm.position, mr.rank_abbr, mm.u_name FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.rank_id = mr.rank_id AND mm.unit_id != '' AND mm.status IN ('Active','LOA') ORDER BY mr.rank_order ";
		$result = $db->sql_query($sql);	
		while ( $row = $db->sql_fetchrow($result) ) {
			$uniqueid = $row["uniqueid"];
		    if ($warstatus[$uniqueid] == "Yes") {
				$result2 = $db->sql_query ("SELECT * FROM " . $prefix."_milpacs_combat WHERE warid = '$warid' AND uniqueid='$uniqueid'");
                if ($myrow2 = $db->sql_fetchrow($result2)){
				} else {
					$sql = "INSERT INTO " . $prefix . "_milpacs_combat (
						 warid,  uniqueid, 	 oppid ) VALUES ( $warid,  $uniqueid, $oppid)";
					$result3 = $db->sql_query ($sql);
				}
		    } else {
				$result2 = $db->sql_query ("SELECT * FROM " . $prefix."_milpacs_combat WHERE warid = " . $warid . " AND uniqueid = " . $uniqueid);
                if ($myrow2 = $db->sql_fetchrow($result2)){
					$result3 = $db->sql_query ("DELETE FROM " . $prefix . "_milpacs_combat WHERE warid = '$warid' AND uniqueid = '$uniqueid'");
                }
            }
		}
	}

}
$result1 = $db->sql_query("SELECT * FROM vwar" . $n . " v JOIN vwar" . $n . "_opponents vo JOIN vwar" . $n . "_matchtype vmt WHERE v.status = 1 AND v.oppid = vo.oppid AND warid = '$warid' AND v.matchtypeid = vmt.matchtypeid");
if (!$result1) {
	    echo("<p>Error accessing war data!" . mysql_error() . "</p>");
}
while ($row = $db->sql_fetchrow($result1)) {
$date = date("F j, Y", $row["dateline"]);
$oppname = $row["oppname"];
$matchtypename = $row["matchtypename"];
}

//Get unit tag info to display
$result4 = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result4);
$unit_tag = $info[unit_tag];

OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>"
// Load members
. "<form name=\"editwar\" action=\"admin.php?op=EditWar&warid=$warid\" method=\"POST\">"
. "<div align=\"center\">"
. "<label><H2>$unit_tag War Report</H2></label>"
. "<HR>"
. "</div>"
. "<br>"
. "<p>"
. "<strong>War Date: $date</strong>"
. "<br>"
. "<strong>Enemy Engaged: $oppname</strong>"
. "<br>"
. "<strong>Matchtype: $matchtypename</strong>"
. "<br>"
. "<table border=\"0\" width=\"100%\" cellpadding=\"5\"><tr>"
. "<table border=\"0\" width=\"100%\" cellpadding=\"3\"><tr><th width=\"5%\">Rank</th><th width=\"20%\">Name</th><th width=\"15%\"><b>Position</b></th><th width=\"20%\">Present</th>"
. "</tr>"
. "</table>"
. "<table border=\"0\" width=\"100%\" cellpadding=\"5\">";

$sql = "SELECT mm.uniqueid, mm.unit_id, mm.position, mr.rank_abbr, mm.u_name FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.rank_id = mr.rank_id AND mm.unit_id != '' AND mm.status IN ('Active','LOA') ORDER BY mr.rank_order ";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["uniqueid"];
	$rank = $row["rank_abbr"];
	$u_name = $row["u_name"];
	$position = $row["position"];
    $result2 = $db->sql_query ("SELECT * FROM " . $prefix."_milpacs_combat WHERE warid = " . $warid . " AND uniqueid = '$id'");
    if ($myrow2 = $db->sql_fetchrow($result2)){ $checked = "checked"; } else { $checked = ""; }
?>
<tr>
		<td align="center" width="5%"><b><?php echo $rank ?></b>
		</td>
		<td align="center" width="20%"><b><?php echo $u_name ?></b>
		</td>
		<td align="center" width="15%"><b><?php echo $position ?></b>
		</td>		
		<td align="center" width="20%"><input <?=$checked?> name="warstatus[<?=$id?>]" type="checkbox" id="warstatus" value="Yes">
		</td>		
	</tr>
<?php
}
echo "</table>"
."<input type=\"submit\" align=\"center\" name=\"Submit\" value=\"Save\"/>"
."<input type=\"hidden\" name=\"op\" value=\"SaveWar\"/>"
."<input type=\"hidden\" name=\"warid\" value=\"$warid\"/>"
."</form>";
CloseTable();
include("footer.php");
?>