<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if (!defined('ADMIN_FILE')) {
	die ("Access Denied");
}
define('INDEX_FILE', true);
$index = 1;

global $db, $prefix, $aid, $admin_file, $module_name, $sitename;
require_once("mainfile.php");
get_lang($module_name);
$aid = substr("$aid", 0,25);

/* Get list of valid authors */
$row = $db->sql_fetchrow($db->sql_query("SELECT title, admins FROM ".$prefix."_modules WHERE title='$module_name'"));
$row2 = $db->sql_fetchrow($db->sql_query("SELECT name, radminsuper FROM ".$prefix."_authors WHERE aid='$aid'"));
$admins = explode(",", $row['admins']);
$auth_user = 0;
for ($i=0; $i < sizeof($admins); $i++) {
    if ($row2['name'] == "$admins[$i]" AND $row['admins'] != "") {
        $auth_user = 1;   
    }
}

/* If you are not an admin, get out of here... */
if ($row2['radminsuper'] == 1 || $auth_user == 1) {

switch($op) {

		case "milpacs":
		case "ViewMainInfo":
			milpacs();
			break;		
		case "UpdateInfo":
		case "EditInfo":
			include("modules/$module_name/admin/editinfo.php");
			break;
		case "AddMedal":
		case "NewMedal":
			include("modules/$module_name/admin/addmedal.php");
			break;
		case "EditMedal":		
		case "SaveMedal":
			include("modules/$module_name/admin/editmedal.php");
			break;
		case "DelMedal":
		case "ConfirmDelMedal":
			include("modules/$module_name/admin/delmedal.php");
			break;
		case "AddRank":
		case "NewRank":
			include("modules/$module_name/admin/addrank.php");
			break;
		case "EditRank":
		case "SaveRank":
			include("modules/$module_name/admin/editrank.php");
			break;
		case "DelRank":
		case "ConfirmDelRank":
			include("modules/$module_name/admin/delrank.php");
			break;
		case "AddSoldier":
		case "NewSoldier":
			include("modules/$module_name/admin/addsoldier.php");		
			break;
		case "EditSoldier":
		case "SaveSoldier":
			include("modules/$module_name/admin/editsoldier.php");		
			break;
		case "DelSoldier":
		case "ConfirmDelSoldier":
			include("modules/$module_name/admin/delsoldier.php");
			break;
		case "AddWeapon":
		case "NewWeapon":		
			include("modules/$module_name/admin/addweapon.php");
			break;
		case "EditWeapon":
		case "SaveWeapon":
			include("modules/$module_name/admin/editweapon.php");
			break;
		case "DelWeapon":
		case "ConfirmDelWeapon":
			include("modules/$module_name/admin/delweapon.php");
			break;	
		case "ServiceRecord":
			include("modules/$module_name/admin/servicerecord.php");
			break;			
		case "EditServiceRecord":
		case "SaveServiceRecord";
			include("modules/$module_name/admin/editservicerecord.php");
			break;
		case "DelServiceRecord":
			include("modules/$module_name/admin/delservicerecord.php");
			break;		
		case "AddServiceRecord":			
		case "NewServiceRecord":
			include("modules/$module_name/admin/addservicerecord.php");
			break;
		case "MedalRecord":
			include("modules/$module_name/admin/medalrecord.php");
			break;
		case "EditMedalRecord":			
		case "SaveMedalRecord":
			include("modules/$module_name/admin/editmedalrecord.php");
			break;
		case "AddMedalRecord":			
		case "NewMedalRecord":
			include("modules/$module_name/admin/addmedalrecord.php");
			break;
		case "DelMedalRecord":
			include("modules/$module_name/admin/delmedalrecord.php");
			break;	
		case "AddDrillReport":
			include("modules/$module_name/admin/adddrillreport.php");
			break;
		case "AddUnit":
		case "NewUnit":
			include("modules/$module_name/admin/addunit.php");
			break;
		case "EditUnit":
		case "SaveUnit":
			include("modules/$module_name/admin/editunit.php");
			break;
		case "DelUnit":
		case "ConfirmDelUnit":		
			include("modules/$module_name/admin/delunit.php");
			break;
		case "AddSubUnit":
		case "NewSubUnit":
			include("modules/$module_name/admin/addsubunit.php");
			break;
		case "EditSubUnit":			
		case "SaveSubUnit":
			include("modules/$module_name/admin/editsubunit.php");
			break;		
		case "DelSubUnit":
		case "ConfirmDelSubUnit":
			include("modules/$module_name/admin/delsubunit.php");
			break;			
		case "AddAdminUnit":
		case "NewAdminUnit":
			include("modules/$module_name/admin/addadminunit.php");
			break;
		case "SaveAdminUnit":
		case "EditAdminUnit":
			include("modules/$module_name/admin/editadminunit.php");
			break;
		case "DelAdminUnit":
		case "ConfirmDelAdminUnit":		
			include("modules/$module_name/admin/deladminunit.php");
			break;		
		case "AddDrillReport":
		case "NewDrillReport":
			include("modules/$module_name/admin/adddrillreport.php");
			break;
		case "EditDrillReport":
		case "SaveDrillReport":
			include("modules/$module_name/admin/editdrillreport.php");
			break;	
		case "SaveWar":		
		case "EditWar":		
			include("modules/$module_name/admin/editwar.php");
			break;					
			
}
} else {
	include("header.php");
	GraphicAdmin();
	OpenTable();
	echo "<center><b>"._ERROR."</b><br><br>You do not have administration permission for module \"$module_name\"</center>";
	CloseTable();
	include("footer.php");
}
###############################################################
function milpacs() {
global $db, $prefix, $module_name, $admin_file, $bgcolor1, $bgcolor2;
include_once("header.php");
@include_once("includes/meta.php");
@include_once("includes/javascript.php");
@include_once("includes/my_header.php");
?>
<html>
<head>
<SCRIPT LANGUAGE="JavaScript" SRC="modules/MILPACS/js/switch.js"></SCRIPT>
</head>
<?php
OpenTable();
?>
<center><H1><strong>MILPACS 1.0 Administration </strong></H1></center><br>

<form name="dropmsgform">
<center>Administration Menu<br>
<select name="dropmsgoption" size="1" onChange="expandone()">
<option selected>Main Info Configuration</option>
<option>Roster Manager</option>
<option>Combat Unit Manager</option>
<option>Admin Unit Manager</option>
<option>Sub Unit Manager</option>
<option>Medal Manager</option>
<option>Weapons Manager</option>
<option>Rank Manager</option>
<option>Attendance Manager</option>
<option>Combat Record Manager</option>
<option>Drill Report Manager</option>
</select></center>
</form>

<!-- Start Main Info page -->

<?php
	$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
	$info = $db->sql_fetchrow($result);
	$unit_name = $info[unit_name];
	$unit_tag = $info[unit_tag];
	$unit_nick = $info[unit_nick];
	$motd = $info[motd];
	$recruitemail = $info[recruitemail];	
?>
<div id="dropmsg0" class="dropcontent">
<br>
<!--<form name="viewmaininfo" action="admin.php?op=ViewMainInfo" method="POST"> -->
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST"> 
<H3><center>Main Info Configuration</center></H3>
<HR>
<table border="2" align="center" width="100%">
	<tr>
		<td width="30%" align="right"><b>Unit Name: </b></td>
		<td width="70%"><font class="content"><?php echo $unit_name ?></td>
	</tr>
	<tr>
		<td width="30%" align="right"><b>Unit Nickname: </b></td>
		<td width="70%"><font class="content"><?php echo $unit_nick ?></td>
	</tr>
		<td width="30%" align="right"><b>Unit Tag: </b></td>
		<td width="70%"><font class="content"><?php echo $unit_tag ?></td>
	<tr>
		<td width="30%" align="right"><b>Recruitment Email: </b></td>
		<td width="70%"><font class="content"><?php echo $recruitemail ?></td>
	</tr>
	<tr>
		<td width="30%" align="right"><b>Information Page: </b></td>		
		<td width="70%"><font class="content"><?php echo $motd ?></td>
	</tr>	
</table>
<br>
<hr>
<input type="hidden" name="op" value="EditInfo">
<input type="submit" align="center" name="Submit" value="Update">
</form>
</div>
<!-- Start Roster page -->
<div id="dropmsg1" class="dropcontent">
<br>
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
<H3><center>Roster Management</center></H3>
<HR>
<table border="1" width="100%" cellpadding="3">
<tr>
<p><a href="admin.php?op=AddSoldier">Add a New Troop</a></p>
<th width="5%">Rank</th><th width="10%"><font color="#33CC33">Active Members</font></th><th width="10%"><b>Main Info</b></th><th width="10%">Service Record</th><th width="10%">Medal Record</th>
</tr>
<?php

$sql = "SELECT mm.uniqueid, mm.unit_id, mr.rank_abbr, mm.u_name
FROM " . $prefix . "_milpacs_members mm 
INNER JOIN (" . $prefix . "_milpacs_units mu) ON (mu.unit_id = mm.unit_id) 
LEFT JOIN " . $prefix . "_milpacs_weapons mw ON (mw.weapon_id = mm.weapon_id) 
LEFT JOIN " . $prefix . "_milpacs_ranks mr ON (mr.rank_id = mm.rank_id) 
WHERE mm.status IN ('Active','LOA') 
ORDER BY mu.unit_order, mm.subunit_id, mr.rank_order, mm.promotion_dt asc";


//$sql = "SELECT mm.uniqueid, mm.unit_id, mr.rank_abbr, mm.u_name FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.rank_id = mr.rank_id AND mm.unit_id != '' AND mm.status IN ('Active','LOA') ORDER BY mm.rank_id ";

$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["uniqueid"];
if ($row["rank_abbr"] =="") {
		$rank = "Not Assigned"; 
	} else {
		$rank = $row["rank_abbr"]; 
	}	
	$u_name = $row["u_name"];
	?>
	<tr>
		<td align="center" width="5%"><b><font class="content"><?php echo $rank ?></font></b></td>
		<td align="center" width="15%"><b><font class="content"><?php echo $u_name ?></font></b></td>
		<td align="center" width="10%"><a href="admin.php?op=EditSoldier&id=<?php echo $id ?>">Edit</a><p></td>
		<td align="center" width="10%"><a href="admin.php?op=ServiceRecord&id=<?php echo $id ?>">Edit</a><p></td>
		<td align="center" width="10%"><a href="admin.php?op=MedalRecord&id=<?php echo $id ?>">Edit</a><p>
		</td>		
	</tr>
	<?php
}
?>
</table>
<br>
<table border=1 width="100%" cellpadding="3">
<tr>
<th width="5%">Rank</th><th width="10%"><font color="#FF3300">Past Members</font></th><th width="10%"><b>Main Info</b></th><th width="10%">Delete</th>
</tr>
<?php

$sql = "SELECT mm.uniqueid, mm.unit_id, mr.rank_abbr, mm.u_name
FROM " . $prefix . "_milpacs_members mm 
INNER JOIN (" . $prefix . "_milpacs_units mu) ON (mu.unit_id = mm.unit_id) 
LEFT JOIN " . $prefix . "_milpacs_weapons mw ON (mw.weapon_id = mm.weapon_id) 
LEFT JOIN " . $prefix . "_milpacs_ranks mr ON (mr.rank_id = mm.rank_id) 
WHERE mm.status IN ('Retired','Discharged', 'Long Term LOA') 
ORDER BY mm.rank_id";


//$sql = "SELECT mm.uniqueid, mm.unit_id, mr.rank_abbr, mm.u_name FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.rank_id = mr.rank_id AND mm.unit_id != '' AND mm.status IN ('Retired','Discharged', 'Long Term LOA') ORDER BY mm.rank_id ";

$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["uniqueid"];
	$rank = $row["rank_abbr"];
	$u_name = $row["u_name"];
	?>
	<tr>
		<td align="center" width="5%"><b><font class="content"><?php echo $rank ?></font></b></td>
		<td align="center" width="15%"><b><font class="content"><?php echo $u_name ?></font></b></td>
		<td align="center" width="10%"><a href="admin.php?op=EditSoldier&id=<?php echo $id ?>">Edit</a><p></td>
		<td align="center" width="10%"><a href="admin.php?op=DelSoldier&id=<?php echo $id ?>">Delete</a><p></td>			
	</tr>
	<?php
}
?>
</table>
</form>
</div>
<div id="dropmsg2" class="dropcontent">
<br>
<form>
<H3><center>Combat Unit Management</center></H3>
<HR>
<p><a href="admin.php?op=AddUnit">Add a new Combat Unit!</a></p>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Combat Unit</th><th width="15%">Name</th><th width="15%"><b>Edit</th><th width="15%"><b>Delete</b></tr>
<?php
$sql = "SELECT mu.unit_id, mu.unit_name, mu.unit_nick FROM " . $prefix . "_milpacs_units mu ORDER BY mu.unit_id ";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["unit_id"];
	$unit_name = $row["unit_name"];
	$unit_nick = $row["unit_nick"];
	?>
<tr>
<td align="center" width="15%"><b><font class="content"><?php echo $unit_name ?></font></b></td>
<td align="center" width="15%"><b><font class="content"><?php echo $unit_nick ?></font></b></td>
<td align="center" width="15%"><a href="admin.php?op=EditUnit&id=<?php echo $id ?>">Edit</a><p></td>
<td align="center" width="15%"><a href="admin.php?op=DelUnit&id=<?php echo $id ?>">Delete</a><p></td>
</tr>
	<?php
}
?>
</table>
</form>
</div>
<div id="dropmsg3" class="dropcontent">
<br>
<form>
<H3><center>Admin Unit Management</center></H3>
<HR>
<p><a href="admin.php?op=AddAdminUnit">Add a New Administrative Unit!</a></p>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Admin Unit</th><th width="15%"><b>Edit</th><th width="15%"><b>Delete</b></tr>
<?php
$sql = "SELECT mau.admin_unit_id, mau.admin_unit_name FROM " . $prefix . "_milpacs_adminunit mau ORDER BY mau.admin_unit_id ";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["admin_unit_id"];
	$adminunit_name = $row["admin_unit_name"];	
	?>
<tr>
<td align="center" width="15%"><b><font class="content"><?php echo $adminunit_name ?></font></b></td>
<td align="center" width="15%"><a href="admin.php?op=EditAdminUnit&id=<?php echo $id ?>">Edit</a><p></td>
<td align="center" width="15%"><a href="admin.php?op=DelAdminUnit&id=<?php echo $id ?>">Delete</a><p></td>
</tr>
	<?php
}
?>
</table>
</form>

</div>
<div id="dropmsg4" class="dropcontent">
<br>
<form>
<H3><center>Sub Unit Management</center></H3>
<HR>
<p><a href="admin.php?op=AddSubUnit">Add a new Sub Unit!</a></p>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Sub Unit</th><th width="15%">Assigned To</th><th width="15%"><b>Edit</th><th width="15%"><b>Delete</b></tr>
<?php
$sql = "SELECT * FROM " . $prefix . "_milpacs_subunit msu, " . $prefix . "_milpacs_units mu WHERE msu.unit_id = mu.unit_id ORDER BY msu.subunit_id ";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["subunit_id"];
	$subunit_name = $row["subunit_name"];
	$unit_name = $row["unit_name"];
	?>
<tr>
<td align="center" width="15%"><b><font class="content"><?php echo $subunit_name ?></font></b></td>
<td align="center" width="15%"><b><font class="content"><?php echo $unit_name ?></font></b></td>
<td align="center" width="15%"><a href="admin.php?op=EditSubUnit&id=<?php echo $id ?>">Edit</a><p></td>
<td align="center" width="15%"><a href="admin.php?op=DelSubUnit&id=<?php echo $id ?>">Delete</a><p></td>
</tr>
	<?php
}
?>
</table>
</form>

</div>
<div id="dropmsg5" class="dropcontent">
<br>

<form>
<H3><center>Medal Management</center></H3>
<HR>
<p><a href="admin.php?op=AddMedal">Add a new medal!</a></p>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Medal</th><th width="15%">Class</th><th width="15%"><b>Edit</th><th width="15%"><b>Delete</b></tr>
<?php
$sql = "SELECT ma.award_id, ma.award_name, ma.award_class FROM " . $prefix . "_milpacs_awards ma ORDER BY ma.award_id";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["award_id"];
	$award_name = $row["award_name"];
	$award_class = $row["award_class"];
	?>
	<tr>
		<td align="left" width="25%"><b><font class="content"><?php echo $award_name ?></font></b></td>
		<td align="center" width="15%"><b><font class="content"><?php echo $award_class ?></font></b></td>
		<td align="center" width="15%"><a href="admin.php?op=EditMedal&id=<?php echo $id ?>">Edit</a><p></td>
		<td align="center" width="15%"><a href="admin.php?op=DelMedal&id=<?php echo $id ?>">Delete</a><p></td>
	</tr>
	<?php
}
?>
</table>
</form>

</div>
<div id="dropmsg6" class="dropcontent">
<br>
<form> 
<H3><center>Weapon Management</center></H3>
<HR>
<p><a href="admin.php?op=AddWeapon">Add a new weapon!</a></p>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Weapon</th><th width="15%">Make</th><th width="15%"><b>Edit</b><th width="15%"><b>Delete</b></th></tr>
<?php
$sql = "SELECT mw.weapon_id, mw.model, mw.make FROM " . $prefix . "_milpacs_weapons mw ORDER BY mw.weapon_id";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["weapon_id"];
	$model = $row["model"];
	$make = $row["make"];
	?>
	<tr>
		<td align="center" width="25%"><b><font class="content"><?php echo $model ?></font></b></td>
		<td align="center" width="15%"><b><font class="content"><?php echo $make ?></font></b></td>
		<td align="center" width="15%"><a href="admin.php?op=EditWeapon&id=<?php echo $id ?>">Edit</a><p></td>
		<td align="center" width="15%"><a href="admin.php?op=DelWeapon&id=<?php echo $id ?>">Delete</a><p></td>
	</tr>
	<?php
}
?>
</table>
</form>

</div>
<div id="dropmsg7" class="dropcontent">
<br>
<form>
<H3><center>Rank Management</center></H3>
<HR>
<p><a href="admin.php?op=AddRank">Add a new Rank!</a></p>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Rank Image</th><th width="15%">Rank Name</th><th width="15%"><b>Edit</th><th width="15%">Delete</th></b></tr>
<?php
$sql = "SELECT mr.rank_id, mr.rank_image, mr.rankname FROM " . $prefix . "_milpacs_ranks mr ORDER BY mr.rank_order";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$id = $row["rank_id"];
//	$image = $row["rank_image"];
	$name = $row["rankname"];

	if ($row["rank_image"] =="") {
		$image = "&nbsp;"; 
	} else {
		$image = "<img src='modules/MILPACS/images/ranks/small/$row[rank_image]'>"; 

	}
	?>
	<tr>
		<td align="center" width="15%"><b><font class="content"><?php echo $image ?></font></b></td>
		<td align="center" width="15%"><b><font class="content"><?php echo $name ?></font></b></td>
		<td align="center" width="15%"><a href="admin.php?op=EditRank&id=<?php echo $id ?>">Edit</a><p></td>
		<td align="center" width="15%"><a href="admin.php?op=DelRank&id=<?php echo $id ?>">Delete</a><p></td>
	</tr>
	<?php
}
?>
</table>
</form>


</div>
<div id="dropmsg8" class="dropcontent">
<br>
<form name="attendTimeForm">
<H3><center>Attendance Management</center></H3>
<HR>
<p>Timeframe : <select name="attendTimeOption" size="1" onChange="expandTime()">
<option selected>Last 30 Days</option>
<option>Last 60 Days</option>
<option>Last 90 Days</option>
<option>Last 120 Days</option>
<option>All Drills</option>
</select></p>
</form>

<?php
$end = 4;	// NOTE: $i is how many months PLUS current month will be included in table... $end tells at what point to display all drills
for( $i=0; $i<=$end; $i++ ) {
	?>
	<div id="attendTime<?php echo $i ?>" class="dropcontent">
	<br>

	<table border=1 width="100%" cellpadding="3"><tr><th width="25%">Name</th><th width="10%"><b>Drills Available</b></th><th width="10%">Drills Attended</th><th width="10%">Drills Excused</th><th width="10%">Drills Absent</th><th width="10%">Attendance Record</th></tr>
	<?php
	$sql = "SELECT mm.uniqueid, mm.unit_id, mm.u_name FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.rank_id = mr.rank_id AND mm.status IN ('Active','LOA','Medical LOA') ORDER BY mm.rank_id";
	$result = $db->sql_query($sql);
	while ( $row = $db->sql_fetchrow($result) ) {
		$u_name = $row["u_name"];
		$id2 = $row["uniqueid"];
		$drills_present = 0;
		$drills_excused = 0;
		$drills_absent = 0;
		$drills_available = 0;
		if ($i == $end)
			$sql2 = "SELECT mdlk.status FROM " . $prefix . "_milpacs_drill_lkup mdlk JOIN " . $prefix . "_milpacs_drills md WHERE mdlk.uniqueid = $id2 AND mdlk.drill_id = md.drill_id ORDER BY md.drill_dt";
		else
			$days = ($i + 1) * 30;
			$sql2 = "SELECT mdlk.status FROM " . $prefix . "_milpacs_drill_lkup mdlk JOIN " . $prefix . "_milpacs_drills md WHERE mdlk.uniqueid = $id2 AND mdlk.drill_id = md.drill_id AND DATE_SUB(CURDATE(),INTERVAL $days DAY) <= md.drill_dt ORDER BY md.drill_dt";
//			$sql2 = "SELECT mdlk.status FROM " . $prefix . "_milpacs_drill_lkup mdlk JOIN " . $prefix . "_milpacs_drills md WHERE mdlk.uniqueid = $id2 AND mdlk.drill_id = md.drill_id AND MONTH(md.drill_dt) >= (MONTH(NOW()) - $i) ORDER BY md.drill_dt";
		$result2 = $db->sql_query($sql2);
		while ( $row2 = $db->sql_fetchrow($result2) ) {
			$drills_available += 1;
			$status = $row2['status'];
			if ($status == 'Present')
				$drills_present += 1;
			else if ($status == 'Excused')
				$drills_excused += 1;
			else if ($status == 'Absent')
				$drills_absent += 1;
		}
		if ($drills_available <= 0)
			$per_attend = 0;
		else
			$per_attend = ($drills_present / $drills_available) * 100;
		settype($per_attend, 'integer');
		echo <<< _HTML_1_
		<tr>
			<td align="center" width="25%">
			<b><font class="content">$u_name</font></b>
			</td>
			<td align="center" width="10%">
			<b><font class="content">$drills_available</font></b>
			</td>
			<td align="center" width="10%"><font color="#00FF00">$drills_present</font>
			</td>
			<td align="center" width="10%"><font color="#FFFF00">$drills_excused</font>
			</td>
			<td align="center" width="10%"><font color="#FF0000">$drills_absent</font>
			</td>
			<td align="center" width="10%">$per_attend%
		</tr>
_HTML_1_;
	}
	?></table></div><?php
}
?>

</div>
<div id="dropmsg9" class="dropcontent">
<br>

<form> 
<H3><center>Combat Record Management</center></H3>
<HR>
<table border=1 width="100%" cellpadding="3"><tr><th width="15%">Combat Date</th><th width="15%">Enemy</th><th width="15%"><b>Edit</b></tr>
<?php
@include("modules/MILPACS/includes/milpacs.inc.php");
$sql = "SELECT v.warid, v.status, v.matchtypeid, v.dateline, vo.oppname, vo.oppid FROM vwar" . $n . " v INNER JOIN vwar" . $n . "_opponents vo WHERE v.oppid = vo.oppid AND v.status = 1 ORDER BY dateline DESC";
$result = $db->sql_query($sql);	
while ( $row = $db->sql_fetchrow($result) ) {
	$warid = $row["warid"];
	$date = date("F j, Y", $row["dateline"]);
	$enemy = $row["oppname"];	
	?>
	<tr>
		<td align="left" width="15%"><b><font class="content"><?php echo $date ?></font></b></td>
		<td align="center" width="25%"><b><font class="content"><?php echo $enemy ?></font></b></td>
		<td align="center" width="15%"><a href="admin.php?op=EditWar&warid=<?php echo $warid ?>">Edit</a><p></td>
	</tr>
	<?php
}
?>
</table>
</form>

</div>
</div>

<div id="dropmsg10" class="dropcontent">
<br>

<H3><center>Drill Report Manager</center></H3>
<HR>
<table border="1">
<tr>
<td><a href="admin.php?op=AddDrillReport"><img src="modules/MILPACS/images/add_drill.gif" alt="Add Drill Report" title="Add Drill Report"></a></td>
</tr>
</table>
<table border="1" width='100%' cellpadding='3'><tr><th width='20%'>Drill Date</th><th width='20%'>Edit Drill</th></tr>
<tr>
<?php
// create the SQL statement
$sql = "SELECT drill_id, drill_dt FROM " . $prefix . "_milpacs_drills ORDER BY drill_dt DESC";
//fill the table with values from drill table
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);
	list($Year,$Month,$Day) = split('-',$drill_dt);
    $formatdrilldate = date("F j, Y",mktime(12,0,0,$Month,$Day,$Year));
	?>
	<td width='20%' align='center'><?php echo $formatdrilldate ?></td><td width='20%' align='center'><a class="content" href="admin.php?op=EditDrillReport&amp;drill_id=<?php echo $drill_id ?>">Click here to edit!</a>			
	</td>
	</tr>
	<?php
}
?>
</table>

<?php
CloseTable();
?>
</html>
<?php
include_once("footer.php");
}
?>