 <?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Medal                                             */
/*********************************************************/
if ( !defined('ADMIN_FILE')) {
	die("Illegal File Access");
}

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
$module_name = basename(dirname(__FILE__));
global $module_name, $db, $admin_file, $prefix, $bgcolor1, $bgcolor2;
$IMAGEPATH = $_SERVER['DOCUMENT_ROOT'];

// Load Medal image
	$urlofimages="$IMAGEPATH/modules/MILPACS/images/medals/";
	$medalselecthtml = "<select name=\"award_image\">";
	$medalselecthtml .= "<option value=\"\">Select Medal Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$award_image) {
					$medalselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$medalselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$medalselecthtml .= "</select></td>";
	

if ($op == "NewMedal") {
		// Validations go here
		// If all validations passed, save and exit, otherwise, redisplay with errors
		$award_name = $_POST['award_name'];
		$award_description = addslashes($_POST['award_description']);		
		$award_image = $_POST['award_image'];
		$award_class = $_POST['award_class'];
		//Insert the values into the database 
	$sql = "INSERT INTO " . $prefix . "_milpacs_awards (award_id, award_name, award_image, award_description, award_class)". "VALUES ('NULL','$award_name','$award_image','$award_description', '$award_class')";
		$result = $db->sql_query($sql);
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		}
}	

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name];
$unit_tag = $info[unit_tag];

OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>"
	. "<form name=\"addmedal\" action=\"".$admin_file.".php\" method=\"post\">"
// Display Form
	." <table width=\"100%\" border=\"2\" cellpadding=\"2\" align =\"center\" cellspacing=\"0\" style=\"border-collapse: collapse;\" bordercolor=\"#111111\">"
	."<tr>"
    ."<td align=\"center\" bgcolor=\"$bgcolor2\">"
    ."<b><font class=\"title\">$unit_tag Medal $award_name </font></b>"
    ."</td>"
    ."<tr>"
  	."<td align=\"left\" bgcolor=\"$bgcolor2\">"
  	."<b><font class=\"content\">Medal Information</font></b>"
  	."</td>"
  	."</tr>"
	."<table border=\"0\" width=\"100%\" cellpadding=\"3\"><tr><th width=\"10%\">Medal Image</th><th width=\"30%\">Name of Medal</th><th width=\"20%\"><b>Medal Details</b></th><th width=\"8%\"><b>Medal Class</b></th></tr>"  
	."<tr>"
	."<td align=\"center\" size=\"20\" bgcolor=\"$bgcolor1\"> $medalselecthtml </td>"
	."<td align=\"center\" bgcolor=\"$bgcolor1\"><textarea name=\"award_name\" cols=\"15\" colspan=\"1\" rows=\"3\"> $award_name </textarea></td>"
	."<td align=\"center\" bgcolor=\"$bgcolor1\"><textarea name=\"award_description\" cols=\"20\" colspan=\"1\" rows=\"6\"> $award_description </textarea></td>"
	."<td align=\"center\" bgcolor=\"$bgcolor1\">"
	."<select NAME=\"award_class\" size=\"1\">"
    ."<option VALUE=\"Skill Badge\">Skill Badge"
    ."<option VALUE=\"Unit Citiation\">Unit Citiation"
	."<option VALUE=\"Individual Medal\">Individual Medal"
    ."</select>"			
	."</td>"
	."</tr>"
	."</table>"
	."<br>"
	."<br>"
."<input type=\"hidden\" name=\"op\" value=\"NewMedal\"/>"
."<input type=\"hidden\" name=\"award_id\" value=\" $award_id\"/>"
."<input type=\"submit\" align=\"center\" name=\"Submit\" value=\"Add\"/>"
."</form>";
CloseTable();
include("footer.php");
?>