<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Soldier Medal Record                              */
/*********************************************************/

if ( !defined('ADMIN_FILE')) {
	die("Illegal File Access");
}

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

if ($op == "NewMedalRecord") {
	// Validations go here	
	$pid = intval($_POST['pid']);
	$award_id = intval($_POST['award_id']);
	$id = intval($_POST['id']);
	$award_dt = addslashes($_POST['award_dt']);
	$date = explode("-",$award_dt,3);
	$date[0] = intval($date[0]);
	$date[1] = intval($date[1]);
	$date[2] = intval($date[2]);
	if(checkdate($date[1],$date[2],$date[0])) {
		$dt_error = "";
		$dt_valid = true;
	} else {
		$dt_error = "Error: Date is invalid.  Please enter date in the yyyy-mm-dd format.";
		$dt_valid = false;
	}
	$adetails = addslashes($_POST['adetails']);
	if ($dt_valid) {		
			$sql = "INSERT INTO " . $prefix . "_milpacs_award_lkup (
				 pid, 
				 award_id, 
				 uniqueid, 
				 award_dt, 
				 adetails
				 ) VALUES (
				 null, 
				 $award_id, 
				 $id, 
				 '$award_dt', 
				 '$adetails'
				 )";	
		}
		$result = $db->sql_query($sql);	
		Header("Location: /admin.php?op=MedalRecord&id=$id");
}	
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
} else {
	$u_name = $info[u_name];
}
OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
?>
<form name="addmedalrecord" action="admin.php?op=AddMedalRecord" method="post">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="100%">
	<tr>
		<th width="100%"><b><font class="content" bgcolor= "<?php echo $bgcolor2 ?>">Add Medal Record to <?php echo $u_name ?></font></b></th>		
    <tr>
</table>
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="100%">
		<th width="40%">Medal Name</th>
		<th width="10%">Date of Award</th>
		<th width="25%"><b>Award Details</b></th>
	</tr>
	<tr>
		<td align="left"><select name="award_id" size="1">
		<option value="">--- Select Medal ---</option>
<?php
$result = $db->sql_query("SELECT award_id, award_name FROM " . $prefix . "_milpacs_awards");
while ( $row = $db->sql_fetchrow($result) ) {
	$award_name = $row["award_name"];
	$medal_id = $row["award_id"];
	if ($medal_id == $award_id) {
		echo "<option value='$medal_id'>$award_name</option>";
	} else {
		echo "<option value='$medal_id'>$award_name</option>";
	}
}
?>
		</select>
		</td>
		<td align="center">
		<input type="text" name="award_dt" value="<?php echo $award_dt ?>">
		<a href="javascript:showCal('AddMedalDate');"><img src="modules/MILPACS/images/icon_calendar.gif" title="Select Date" alt="Select Date"></a>
		<font style="color: red;"><?php echo $dt_error ?></font>
		</td>
		<td align="left">
		<textarea name="adetails" cols="25" colspan="1" rows="4"><?php echo $adetails ?></textarea>
		</td>
	</tr>
</table>
<br>
<input type="hidden" name="op" value="NewMedalRecord"/>
<input type="hidden" name="pid" value="<?php echo $pid ?>"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Add"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>