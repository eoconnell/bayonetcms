<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Edit Soldier Service Record                           */
/*********************************************************/

if (!defined('ADMIN_FILE')) { 
die ("Access Denied"); 
} 

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

if ($op == "SaveServiceRecord") {
	// Validations go here		
	$date = explode("-",$record_dt,3);
	$date[0] = intval($date[0]);
	$date[1] = intval($date[1]);
	$date[2] = intval($date[2]);
	if(checkdate($date[1],$date[2],$date[0])) {
		$dt_error = "";
		$dt_valid = true;
	} else {
		$dt_error = "Error: Date is invalid.  Please enter date in the yyyy-mm-dd format.";
		$dt_valid = false;
	}	
	if ($dt_valid) {		
			$sql = "UPDATE " . $prefix . "_milpacs_service_record SET
				record_dt = '$record_dt',
				details = '$details'
			 WHERE record_id = '$record_id'";
		}
		$result = $db->sql_query($sql);
		Header("Location: /admin.php?op=ServiceRecord&id=$id");
}
//Display page
	$result = $db->sql_query("SELECT uniqueid, record_dt, details FROM " . $prefix . "_milpacs_service_record WHERE record_id ='$record_id'");
	$info = $db->sql_fetchrow($result);
    if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		exit();
	} else {
		$id = $info[uniqueid];
		$record_dt = $info[record_dt];
		$details = $info[details];
   }
$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_members mm WHERE mm.uniqueid ='$id'");
$info = $db->sql_fetchrow($result);
if (!$result) {
    echo("<p>Error performing query: " . mysql_error() . "</p>");
    exit();
} else {
	$u_name = $info[u_name];
}
OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo "<p><a href=\"admin.php?op=ServiceRecord&id=$id\">Return to Service Record</a></p>";

?>
<br><br><form name="editservicerecord" action="admin.php?op=EditServiceRecord" method="post">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="100%">
	<tr>
		<td colspan=2 align="center" bgcolor= "<?php echo $bgcolor2 ?>"><b>Service Record for <?php echo $u_name ?></b></td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Record Date:</font></b></td>
		<td width="50%"><input type="text" name="record_dt" value="<?php echo $record_dt ?>">
		<a href="javascript:showCal('editServiceRecord');"><img src="modules/MILPACS/images/icon_calendar.gif" title="Select Date" alt="Select Date"></a>
		<font style="color: red;"><?php echo $dt_error ?></font>
		</td>
	</tr>
	<tr>
		<td width="50%" align="right"><b><font class="content">Details:</font></b></td>
		<td width="50%"><textarea name="details" cols="60" colspan="1" rows="4"><?php echo $details ?></textarea>
		</td>
	</tr>
	<tr>
</table>
<br>
<input type="hidden" name="op" value="SaveServiceRecord"/>
<input type="hidden" name="record_id" value="<?php echo $record_id ?>"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Update"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>