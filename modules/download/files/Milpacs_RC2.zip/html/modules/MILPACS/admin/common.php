<?
if (stristr($_SERVER['SCRIPT_NAME'], "common.php")) {
    Header("Location: ../../index.php");
    die();
}

session_start();

function milpacs_is_admin()
{
    global $db, $prefix, $_SESSION;

	if (isset($_SESSION['loggedin']) AND $_SESSION['loggedin'] == 1 AND !empty($_SESSION['pass']))
    {
	    $pass = stripslashes(check_html(FixQuotes($_SESSION['pass'], "nohtml")));
		$query = "SELECT * FROM ".$prefix."_milpacs_pass WHERE id = 'admin' AND pass = MD5('" . $pass . "')";		
		$result = $db->sql_query($query);
		if ($row = $db->sql_fetchrow($result)) {
           return true;
        } else {
           return false;
        }
    } else {
       return false;
    }
}
?>