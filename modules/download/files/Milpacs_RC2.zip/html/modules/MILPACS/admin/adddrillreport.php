<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan (_at_) 3rd-infantry-division (_DOT_) net				*/	
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if ( !defined('ADMIN_FILE')) {
	die("Illegal File Access");
}

define('INDEX_FILE', false);
$index = 0;
include_once("header.php");
$module_name = basename(dirname(__FILE__));
get_lang($module_name);
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

// Insert Drill Information
if ($op == "NewDrillReport") {	

    $sql = "SELECT * FROM " . $prefix . "_milpacs_drills ORDER BY drill_id DESC";
	$result = $db->sql_query($sql);
    $row = $db->sql_fetchrow($result);
	$drid = $row['drill_id'] + 1;

		   $sql = "INSERT INTO " . $prefix . "_milpacs_drills (
				drill_id, 
				drill_dt, 
				drill_points, 
				drill_news, 
				drill_promotions, 
				drill_assign, 
				drill_tactic,
				drill_leader
				) VALUES (
				$drid,
				'$drill_dt',
				'$drill_points', 
				'$drill_news', 
				'$drill_promotions', 
				'$drill_assign', 
				'$drill_tactic',
				'$drill_leader'
				)";
//	echo $sql . "<br /><br >";
		$result = $db->sql_query($sql);		
// Declare array for drill status
//		$drillstatus = array();
		foreach( $drillstatus as $uniqueid=>$drillsts){
			$uniqueid = intval($uniqueid);
			$drillsts = substr($drillsts,0,10);
			$sql = "INSERT INTO " . $prefix . "_milpacs_drill_lkup (drill_id, uniqueid, status) VALUES ($drid, $uniqueid, '$drillsts')";
//	echo $sql . "<br /><br >";
			$result = $db->sql_query($sql);
		}
       Header("Location: admin.php?op=EditDrillReport&drill_id=" . $drid);	
  		exit();
}

// Load members
$members = array();
$sql = "SELECT mm.uniqueid , mr.rank_abbr, mm.u_name, mm.promotion_dt, mm.position, mm.status FROM " . $prefix . "_milpacs_members mm JOIN " . $prefix . "_milpacs_ranks mr WHERE mm.unit_id != '' AND mm.rank_id = mr.rank_id AND mm.status IN ('Active','LOA') ORDER BY mr.rank_id, mm.promotion_dt asc";
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) { 
	$uniqueid = $row["uniqueid"]; 
	$rank = $row["rank_abbr"]; 
	$u_name = $row["u_name"]; 
	$position = $row["position"]; 
	$status = $row["status"]; 
	$members[] = array("uniqueid" => $uniqueid, "u_name" => $u_name, "rank" => $rank, "position" => $position, "status" => $status);
}

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name];
$unit_tag = $info[unit_tag];

OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
echo "<form name=\"adddrillreport\" action=\"".$admin_file.".php\" method=\"post\">";
//<!-- Display Form -->
echo "<div align=\"center\">";
echo "<label><H3>Add the $unit_name Drill Report</H3></label>";
echo "<HR>";
echo "</div>";
echo "<br>";
echo "<p>";
echo "<strong>Drill Date: </strong>";
echo "<INPUT TYPE=\"text\" NAME=\"drill_dt\" size=\"20\" value=\"$drill_dt\">";
echo "<a href=\"javascript:showCal('addDrillDate');\"><img src=\"modules/MILPACS/images/icon_calendar.gif\" title=\"Select Date\" alt=\"Select Date\"></a>";
echo "&nbsp;&nbsp;<strong>Drill Leader: </strong>";
echo "<select name=\"drill_leader\">";
$sql2 = "SELECT u_name, rank_order FROM " . $prefix . "_milpacs_members mm, " . $prefix . "_milpacs_ranks mr WHERE mm.rank_id = mr.rank_id AND status IN ('Active','LOA') ORDER BY rank_order;";
$result2 = $db->sql_query($sql2);
while ( $row2 = $db->sql_fetchrow($result2) ) {
   $selected = "";
   echo "<option value=\"" . $row2['u_name'] . "\" $selected >" . $row2['u_name'] . "</option>"; 
}
echo "</select>"
."<br>"
."<br>"
."<label><strong>Post the $unit_tag Drill News:</strong></label>"
."<br>"
."<textarea name=\"drill_news\" cols=\"80\" rows=\"3\">$drill_news</textarea>"
."<br>"
."<br>"
."<label><strong>Post any $unit_tag promotions:</strong></label>"
."<br>"
."<textarea name=\"drill_promotions\" cols=\"80\" rows=\"3\">$drill_promotions</textarea>"
."<br>"
."<br>"
."<label><strong>Post any $unit_tag Assignments:</strong></label>"
."<br>"
."<textarea name=\"drill_assign\" cols=\"80\" rows=\"3\">$drill_assign</textarea>"
."<br>"
."<br>"
."<label><strong>Post the tactics used at drills:</strong></label>"
."<br>"
."<textarea name=\"drill_tactic\" cols=\"80\" rows=\"3\">$drill_tactic</textarea>"
."<br>"
."<br>"
."<br><p><strong>Take Attendance:</strong>"
."<table border=\"0\" width=\"100%\" cellpadding=\"5\"><tr>"
."<table border=\"0\" width=\"100%\" cellpadding=\"3\"><tr><th width=\"15%\>Drill Status</th><th width=\"5%\">Rank</th><th width=\"10%\"><b>Name</b></th><th width=\"5%\">Position</th><th width=\"5%\">Status</th>"
."</tr>"
."</table>"
."<table border=\"0\" width=\"100%\" cellpadding=\"5\">";
// Format drill detail HTML
foreach($members as $member){
	$uniqueid = $member["uniqueid"];
	$rank = $member["rank"];
	$u_name = $member["u_name"];
	$position = $member["position"];
	$status = $member["status"];
	$presentchecked = "";
	$absentchecked = "CHECKED";
	$excusedchecked = "";	
	?>
	<tr>
		<td align="center" width="15%">
			<INPUT TYPE="RADIO" NAME="drillstatus[<?php echo $uniqueid ?>]" VALUE="Present" <?php echo $presentchecked ?> > Present</INPUT>
			<INPUT TYPE="RADIO" NAME="drillstatus[<?php echo $uniqueid ?>]" VALUE="Absent" <?php echo $absentchecked ?> > Absent</INPUT>
			<INPUT TYPE="RADIO" NAME="drillstatus[<?php echo $uniqueid ?>]" VALUE="Excused" <?php echo $excusedchecked ?> > Excused</INPUT>
		</td>
		<td align="center" width="5%">
			<b><?php echo $rank ?></font></b>
		</td>
		<td align="center" width="10%">
			<b><?php echo $u_name ?></font></b>
		</td>
		<td align="center" width="5%">
			<b><?php echo $position ?></font></b>
		</td>
		<td align="center" width="5%">
			<b><?php echo $status ?></font></b>
		</td>
	</tr>
	<?php
}
?>
</table>
<input type="submit" align="center" name="Submit" value="Save"/>
<input type="hidden" name="op" value="NewDrillReport"/>
<input type="hidden" name="drid" value="<?php echo $drid ?>"/>
</form>
<?php
CloseTable();
?>
