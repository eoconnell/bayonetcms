<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Add Weapons                                           */
/*********************************************************/
if (!defined('ADMIN_FILE')) { 
die ("Access Denied"); 
} 

define('INDEX_FILE', true);
$index = 1;
include_once("header.php");
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;
$IMAGEPATH = $_SERVER['DOCUMENT_ROOT'];

// Load Weapon image
	$urlofimages="$IMAGEPATH/modules/$module_name/images/weapons/";
	$weaponselecthtml = "<select name=\"weapon_image\">";
	$weaponselecthtml .= "<option value=\"\">Select Weapon Image</option>";
	if ($handle=@opendir($urlofimages)) { 
		while ($imgfile = readdir($handle)) {
			if ($imgfile != "." && $imgfile != ".." && $imgfile != "" && $imgfile != "index.html" && $imgfile != "WS_FTP.LOG" && $imgfile != "Thumbs.db") {
				if ($imgfile==$weapon_image) {
					$weaponselecthtml .= "<option value =\"$imgfile\" selected>$imgfile</option>";
				} else {
					$weaponselecthtml .= "<option value =\"$imgfile\" >$imgfile</option>";
				}
			}
		}
		@closedir($handle);
	}
	$weaponselecthtml .= "</select></td>";

// Add data to weapons table
if ($op == "NewWeapon") {
	
		$model = $_POST['model'];
		$make = $_POST['make'];
		$weapon_image = $_POST['weapon_image'];
		$weapon_descr = $_POST['weapon_descr'];
		$caliber = $_POST['caliber'];
		$rounds = $_POST['rounds'];
		$weight = $_POST['weight'];
		$weapon_class = $_POST['weapon_class'];
		$intro_dt = $_POST['intro_dt'];
		$type_fire = $_POST['type_fire'];
		$rate_fire = $_POST['rate_fire'];
		$eff_range = $_POST['eff_range'];
		$max_range = $_POST['max_range'];
		//Insert the values into the database 
	$sql = "INSERT INTO " . $prefix . "_milpacs_weapons (weapon_id, model, make, weapon_image, weapon_descr, caliber, rounds, weight, weapon_class, intro_dt, type_fire, rate_fire, eff_range, max_range)". "VALUES ('NULL','$model','$make','$weapon_image','$weapon_descr','$caliber','$rounds','$weight','$weapon_class','$intro_dt','$type_fire','$rate_fire','$eff_range','$max_range')";
	$result = $db->sql_query($sql);
		if (!$result) {
		echo("<p>Error performing query: " . mysql_error() . "</p>");
		}
}		
OpenTable();
echo "<p><a href=\"admin.php?op=milpacs\">Return to Main Administration</a></p>";
?>
<!-- Display Form -->
<form name="addweapon" action="admin.php?op=AddWeapon" method="POST">
<table border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111" width="100%"><tr>
		<td align="center" bgcolor= "<?php echo $bgcolor2 ?>"> Weapon image: <?php echo $weaponselecthtml ?></td>
	</tr> 
</table>
<table width="100%" border="2" cellpadding="2" align="center" cellspacing="0" style="border-collapse: collapse;" bordercolor="#111111">
	<tr>
		<td height="25" colspan="2" align="left" bgcolor= <?php echo $bgcolor2 ?>><b><font class="title">Weapon Statistics</font></b></td>
	</tr>
	<tr>		
		<td width="40%"><p align="right"><font class="content"><b>Make:</b></font></td>
		<td width="60%"><input type="text" name="make" value="<?php echo $make ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Model:</b></font></td>
		<td width="60%"><input type="text" name="model" value="<?php echo $model ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Caliber:</b></font></td>
		<td width="60%"><input type="text" name="caliber" value="<?php echo $caliber ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Class:</b></font></td>
		<td width="60%"><input type="text" name="weapon_class" value="<?php echo $weapon_class ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Rounds:</b></font></td>
		<td width="60%"><input type="text" name="rounds" value="<?php echo $rounds ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Weight:</b></font></td>
		<td width="60%"><input type="text" name="weight" value="<?php echo $weight ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Introduced:</b></font></td>
		<td width="60%"><input type="text" name="intro_dt" value="<?php echo $intro_dt ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Type of Fire:</b></font></td>
		<td width="60%"><input type="text" name="type_fire" value="<?php echo $type_fire ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Rate of Fire:</b></font></td>
		<td width="60%"><input type="text" name="rate_fire" value="<?php echo $rate_fire ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Effective Range:</b></font></td>
		<td width="60%"><input type="text" name="eff_range" value="<?php echo $eff_range ?>"/></td>
	</tr>
	<tr>
		<td width="40%"><p align="right"><font class="content"><b>Maximum Range:</b></font></td>
		<td width="60%"><input type="text" name="max_range" value="<?php echo $max_range ?>"/></td>
	</tr>
	<tr>
	<td width="40%"><p align="right"><font class="content"><b>Decription:</b></font></td>
	<td width="60%"><p align="left"><textarea name="weapon_descr" cols="70" colspan="1" rows="10"><?php echo $weapon_descr ?></textarea></td>
	</tr>
</table>
<br>
<input type="hidden" name="op" value="NewWeapon"/>
<input type="hidden" name="id" value="<?php echo $id ?>"/>
<input type="submit" align="center" name="Submit" value="Update"/>
</form>
<?php
CloseTable();
@include_once("footer.php");
?>