<?php
/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

/*********************************************************/
/* Weapons page                                          */
/*********************************************************/

if (!defined('MODULE_FILE')) { 
    die ("You can't access this file directly..."); 
}

define('INDEX_FILE', true);
$index = 1;

//Required Files
@include_once("header.php");
$module_name = basename(dirname(__FILE__));
@get_lang($module_name);
global $module_name, $db, $prefix, $bgcolor1, $bgcolor2;

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name];
$unit_tag = $info[unit_tag];

OpenTable();
echo"<table border=0><tr><td width=100%>"
  . "<font class=\"title\"><big><b>Arsenal of the $unit_name</b></big></font><hr width=200 align=\"left\">"
  . "</td></tr></table>"
 .""
 ."<br>";
CloseTable();
OpenTable();
//returns all weapons in the weapon table
?>
<table border=0 width='100%' cellpadding='5'><tr>
<table border=1 width='100%' cellpadding='3'><tr><b><th width='20%'>Make</th><th width='20%'><b>Model</th><th width='20%'>Caliber</th><th width='20%'>Class</th></b>
</tr>
<?php
$sql = "SELECT * FROM " . $prefix . "_milpacs_weapons ORDER BY weapon_id";
//fill the table with values from weapon table
$result = $db->sql_query($sql);
while ( $row = $db->sql_fetchrow($result) ) {
	extract($row);  
	?>  
	<td width='20%' align='center'><a class="content" href="modules.php?name=<?php echo $module_name ?>&amp;file=weaponprofile&amp;weapon_id=<?php echo $weapon_id ?>"><?php echo $make ?></a><td width='20%' align='center'><?php echo $model ?></td><td width='20%' align='center'><?php echo $caliber ?></td><td width='20%' align='center'><?php echo $weapon_class ?></td>
	</tr>
	<?php
}
echo "</table><br/><hr noShade>";
CloseTable();
@include_once("footer.php");
?>