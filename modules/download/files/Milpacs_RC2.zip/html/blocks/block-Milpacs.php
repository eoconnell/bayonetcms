<?php

/************************************************************************/
/* MILPACS (Military Personell and Classification System)               */
/* Author::Donovan [3rd ID]												*/
/* Copyright (c) 2005 by Steven Donovan AKA Donovan [3rd ID]			*/
/* Email:: donovan@3rd-infantry-division.net
/* Homepage::http://www.3rd-infantry-division.net						*/
/*																		*/
/* This program is free software; you can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/*                                                                      */
/* This program is distributed in the hope that it will be useful, but  */
/* WITHOUT ANY WARRANTY; without even the implied warranty of           */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU     */
/* General Public License for more details.                             */
/*                                                                      */
/* If you want a copy of the GNU General Public License write to the    */
/* Free Software Foundation, Inc.										*/
/* 59 Temple Place, Suite 330, Boston, MA 02111-1307					*/
/* USA                                                                  */
/************************************************************************/

if ( !defined('BLOCK_FILE') ) {
    Header("Location: ../index.php");
    die();
}

global $prefix, $db;
$module_name = "MILPACS";
get_lang($module_name);

$result = $db->sql_query("SELECT * FROM " . $prefix . "_milpacs_main");
$info = $db->sql_fetchrow($result);
$unit_name = $info[unit_name];
$unit_tag = $info[unit_tag];
$unit_nick = $info[unit_nick];

$content  =  "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS\">Information</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=roster\">Roster</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=award\">Medals</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=weapon\">Weapons</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=ranks\">Ranks</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=enlistment\">Enlistment</a><BR>";
$content  .= "<HR><br>";
$content  .= "<B><center>$unit_tag Only!</center></B><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"modules.php?name=MILPACS&file=checkuser\">Drill Report</a><BR>";
$content  .= "&nbsp;<b><big>&middot;&nbsp;</big></b><a href=\"admin.php\">Administration</a><BR>";
?>