<?php
/************************************************************************/
/* PHP-NUKE: Web Portal System                                          */
/* ===========================                                          */
/*                                                                      */
/* Copyright (c) 2002 by Francisco Burzi                                */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/
/************************************************************************
* Original Installer Design / Structure
* By: NukeScripts Network (webmaster@nukescripts.net)
* http://www.nukescripts.net
* Copyright � 2000-2005 by NukeScripts Network
************************************************************************/
/********************************************************/
/* MILPACS                                              */
/* By: 3rd ID (donovan@3rd-infantry-division.net)       */
/* http://www.3rd-infantry-division.net                 */
/* Copyright � 2006 by Steven Donovan                   */
/********************************************************/

if ( !defined( 'MILPACS_LOADED' ) ) { die( "Illegal File Access" ); }
require_once("mainfile.php");
global $prefix, $db;

/************************************************************************
* Script Initialization
************************************************************************/

opentable();

echo "<div id=\"milpacs_div_main\"\n";
echo "<hr />\n";
echo"First Time Install -- REMOVE THIS SCRIPT WHEN FINISHED! \n";
echo"You can also remove the milpacs_installer directory as well.";


/************************************************************************
* CREATE TABLES: 
************************************************************************/

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_adminunit (
  `admin_unit_id` tinyint(4) NOT NULL auto_increment,
  `admin_unit_name` varchar(255) NOT NULL default '',
  `admin_unit_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`admin_unit_id`),
  KEY `admin_unit_name` (`admin_unit_name`))";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_adminunit</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_adminunit</i> Unsuccessful";
		echo "</p>\n";
	}


echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_award_lkup (
  `pid` int(11) NOT NULL auto_increment,
  `award_id` tinyint(4) default NULL,
  `uniqueid` int(11) default NULL,
  `award_dt` date default NULL,
  `adetails` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`pid`))";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_award_lkup</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_award_lkup</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_awards (
  `award_id` tinyint(4) NOT NULL auto_increment,
  `award_name` text NOT NULL,
  `award_image` varchar(255) NOT NULL default '',
  `award_description` varchar(250) NOT NULL default '',
  `award_class` varchar(255) default NULL,
  KEY `uniqueid` (`award_id`))";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_awards</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_awards</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_combat (
  `warid` smallint(5) NOT NULL default '0',
  `uniqueid` int(11) NOT NULL default '0',
  `oppid` smallint(5) NOT NULL default '0',
  `warstatus` smallint(1) default NULL,
  PRIMARY KEY  (`warid`,`uniqueid`))";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_combat</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_combat</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_drill_lkup (
  `drill_id` int(11) NOT NULL default '0',
  `uniqueid` int(11) NOT NULL default '0',
  `status` char(10) NOT NULL default '',
  PRIMARY KEY  (`drill_id`,`uniqueid`)
)";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_drill_lkup</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_drill_lkup</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_drills (
  `drill_id` int(11) NOT NULL auto_increment,
  `drill_dt` date NOT NULL default '0000-00-00',
  `drill_points` int(11) NOT NULL default '5',
  `drill_news` text NOT NULL,
  `drill_promotions` text NOT NULL,
  `drill_assign` text NOT NULL,
  `drill_tactic` text NOT NULL,
  `drill_leader` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`drill_id`)
)";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_drills</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_drills</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_main (
	`motd` text NOT NULL,
	`unit_name` VARCHAR(50) NOT NULL,
	`unit_tag` VARCHAR(20) NOT NULL,
	`unit_nick` VARCHAR(20) NOT NULL,
	`recruitemail` VARCHAR(50) NOT NULL    
  )";
$result = $db->sql_query($sql);	
	if (!$result) {
		echo "Information inserted into <i>milpacs_main</i> was Unsuccessful!";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_main</i> was Successful";
		echo "</p>\n";
	}


$sql = "INSERT INTO ".$prefix."_milpacs_main VALUES ('Welcome to the (Insert Unit Here) personnel administration system. We are utilizing MILPACS, a module for PHPNuke, developed by 1Lt Donovan of the 3rd Infantry Division.  The MILPACS development site is located at http://milpacs.3rd-infantry-division.net.  Though still under developement, it is a substantial improvement over other methods of unit administration and is currently the only module of its kind available. Please feel free to comment and provide feedback that will help us contribute to the development of this tool.','Change Me', '[Your Tag]', 'Change Me', 'recruitment@yourdomain.net')";

$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Information inserted <i>milpacs_main</i> Successful";
		echo "</p>\n";
	} else {
		echo "Information insertion <i>milpacs_main</i> was Unsuccessful";
		echo "</p>\n";
	}


echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_members (
  `u_name` text,
  `nukeusername` text,
  `uniqueid` int(11) NOT NULL auto_increment,
  `ismember` SMALLINT(1),
  `last_login` date NOT NULL default '0000-00-00',
  `Age` text,
  `location` text,
  `email` text,
  `xfire` varchar(30),
  `bio` text,
  `weapon_id` tinyint(4) default NULL,
  `position` text,
  `enlistment_dt` date NOT NULL default '0000-00-00',
  `promotion_dt` date default '0000-00-00',
  `status` text,
  `unit_id` tinyint(4) NOT NULL default '4',
  `uniform` varchar(255) default NULL,
  `rank_id` tinyint(4) default '17',
  `flag` text,
  `reports` text,
  `s_mos` text,
  `p_mos` text,
  `points` int(11) NOT NULL default '0',
  `subunit_id` tinyint(4) NOT NULL default '0',
  `adminunits` text NOT NULL,
  PRIMARY KEY  (`uniqueid`)  
)";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_members</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_members</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_ranks (
  `rankname` text,
  `rank_id` tinyint(4) NOT NULL auto_increment,
  `rank_image` varchar(255) default NULL,
  `rank_image_l` varchar(255) default NULL,
  `rank_abbr` text,
  `rank_order` tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (`rank_id`)
)";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_ranks</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_ranks</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_service_record (
  `record_id` int(4) NOT NULL auto_increment,
  `uniqueid` int(11) default NULL,
  `record_dt` date default NULL,
  `details` varchar(255) default NULL,
  PRIMARY KEY  (`record_id`)
)";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_service_record</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_service_record</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_subunit (
  `subunit_id` tinyint(4) NOT NULL auto_increment,
  `unit_id` tinyint(4) NOT NULL default '0',
  `subunit_name` varchar(255) NOT NULL default '',
  `subunit_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`subunit_id`),
  KEY `subunit_name` (`subunit_name`)
)";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_subunit</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_subunit</i> Unsuccessful";
		echo "</p>\n";
	}

echo "<p>\n";

$sql	= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_units (
  `unit_id` tinyint(4) NOT NULL auto_increment,
  `unit_order` tinyint(4) NOT NULL default '0',
  `unit_name` varchar(255) default NULL,
  `unit_image` varchar(255) default NULL,
  `unit_creed` varchar(50) default NULL,
  `unit_motto` text,
  `unit_nick` text,
  `unit_goal_one` text,
  `unit_goal_two` text,
  `unit_goal_three` text,
  `unit_bio` text,
  PRIMARY KEY  (`unit_id`)
)";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_units</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_units</i> Unsuccessful";
		echo "</p>\n";
	}


$sql= "CREATE TABLE IF NOT EXISTS ".$prefix."_milpacs_weapons (
  `weapon_id` tinyint(4) NOT NULL auto_increment,
  `model` varchar(50) default NULL,
  `make` varchar(50) default NULL,
  `weapon_image` varchar(255) default NULL,
  `weapon_descr` text,
  `caliber` varchar(20) default NULL,
  `rounds` varchar(20) default NULL,
  `weight` varchar(20) default NULL,
  `weapon_class` varchar(30) default NULL,
  `intro_dt` varchar(50) default NULL,
  `type_fire` varchar(50) default NULL,
  `rate_fire` varchar(50) default NULL,
  `eff_range` varchar(50) default NULL,
  `max_range` varchar(50) default NULL,
  PRIMARY KEY  (`weapon_id`)
)";
$result = $db->sql_query( $sql );	
	if ( $result ) {
		echo "Table Created <i>milpacs_weapons</i> Successful";
		echo "</p>\n";
	} else {
		echo "Table Created <i>milpacs_weapons</i> Unsuccessful";
		echo "</p>\n";
	}

/************************************************************************
* Finish up 
************************************************************************/

echo "</div><hr />\n";

CloseTable();
?>