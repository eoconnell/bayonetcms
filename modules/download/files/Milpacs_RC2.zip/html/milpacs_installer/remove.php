<?php
/************************************************************************/
/* PHP-NUKE: Web Portal System                                          */
/* ===========================                                          */
/*                                                                      */
/* Copyright (c) 2002 by Francisco Burzi                                */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/
/************************************************************************
* Original Installer Design / Structure
* By: NukeScripts Network (webmaster@nukescripts.net)
* http://www.nukescripts.net
* Copyright � 2000-2005 by NukeScripts Network
************************************************************************/
/********************************************************/
/* MILPACS                                              */
/* By: 3rd ID (donovan@3rd-infantry-division.net)       */
/* http://www.3rd-infantry-division.net                 */
/* Copyright � 2006 by Steven Donovan                   */
/********************************************************/

if ( !defined( 'MILPACS_LOADED' ) ) { die( "Illegal File Access" ); }
require_once("mainfile.php");
global $prefix, $db;

/************************************************************************
* Script Initialization
************************************************************************/

opentable();
echo "<div id=\"milpacs_div_main\"\n";
echo "<p><b>Dropping all of your MILPACS tables</b></p>\n";
echo "<hr />\n";

/************************************************************************
* DROPPING TABLES:
************************************************************************/

echo "<p>\n";
$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_adminunit";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_adminunit table Successful<br>\n";} else {echo "Dropped ".$prefix."_milpacs_adminunit table Unsuccessful<br>\n";}	

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_award_lkup";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_award_lkup table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_award_lkup table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_awards";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_awards table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_awards table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_combat";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_combat table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_combat table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_drill_lkup";
$result = $db->sql_query($sql);	
	if($result) {echo "Dropped ".$prefix."_milpacs_drill_lkup table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_drill_lkup table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_drills";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_drills table Successful<br>\n";} else {echo "Dropped ".$prefix."_milpacs_drills table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_main";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_main table Successful<br>\n";} else {echo "Dropped ".$prefix."_milpacs_main table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_members";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_members table Successful<br>\n";} else {echo "Dropped ".$prefix."_milpacs_members table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_ranks";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_ranks table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_ranks table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_service_record";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_service_record table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_service_record table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_subunit";
$result = $db->sql_query($sql);	
	if($result) {echo "Dropped ".$prefix."_milpacs_subunit table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_subunit table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_units";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped milpacs_units table Successful<br>\n";} else {echo"Dropped milpacs_units table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_weapons";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped milpacs_weapons table Successful<br>\n";} else {echo"Dropped milpacs_weapons table Unsuccessful<br>\n";}
	
$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_points";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_points table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_points table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_points_lkup";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_points_lkup table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_points_lkup table Unsuccessful<br>\n";}

$sql	= "DROP TABLE IF EXISTS ".$prefix."_milpacs_pass";
$result = $db->sql_query($sql);	
	if($result) {echo"Dropped ".$prefix."_milpacs_pass table Successful<br>\n";} else {echo"Dropped ".$prefix."_milpacs_pass table Unsuccessful<br>\n";}
echo "<hr><b>Operation Complete!</b><hr>\n";
echo "<hr><b>REMOVE THIS SCRIPT WHEN FINISHED!</b><hr>\n";
include("footer.php"); 
CloseTable();
?>