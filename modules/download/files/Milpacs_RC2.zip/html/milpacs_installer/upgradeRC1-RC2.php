<?php
/********************************************************/
/* MILPACS                                              */
/* By: 3rd ID (donovan@3rd-infantry-division.net)       */
/* http://www.3rd-infantry-division.net                 */
/* Copyright � 2006 by Steven Donovan                   */
/********************************************************/

if ( !defined( 'MILPACS_LOADED' ) ) { die( "Illegal File Access" ); }
//Upgrade script for MILPACS beta 1.0 RC2

require_once("mainfile.php");
global $prefix, $db; 
OpenTable();

echo "Upgrading the MILPACS tables!<br />\n";
echo "<hr>\n";
echo "<b>Operation Results:</b><hr>\n";
$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_members ADD nukeusername TEXT NOT NULL AFTER u_name");
if (!$result) { echo "Alter ".$prefix."_milpacs_members failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_members succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_members CHANGE uniqueid uniqueid INT( 11 ) NOT NULL AUTO_INCREMENT");
if (!$result) { echo "Alter ".$prefix."_milpacs_members failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_members succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_service_record CHANGE record_id record_id INT( 4 ) NOT NULL AUTO_INCREMENT");
if (!$result) { echo "Alter ".$prefix."_milpacs_service_record failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_service_record succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_service_record CHANGE uniqueid uniqueid INT( 11 ) NOT NULL");
if (!$result) { echo "Alter ".$prefix."_milpacs_service_record failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_service_record succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_award_lkup CHANGE uniqueid uniqueid INT( 11 ) NOT NULL");
if (!$result) { echo "Alter ".$prefix."_milpacs_award_lkup failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_award_lkup succeeded<br>\n"; } 

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_members ADD ismember SMALLINT( 1 ) AFTER uniqueid");
if (!$result) { echo "Alter ".$prefix."_milpacs_members failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_members succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_units DROP INDEX unit_motto");
if (!$result) { echo "Alter ".$prefix."_milpacs_units failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_units succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_members DROP INDEX uniqueid");
if (!$result) { echo "Alter ".$prefix."_milpacs_members failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_members succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_members DROP COLUMN icq");
if (!$result) { echo "Alter ".$prefix."_milpacs_members failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_members succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_members ADD xfire VARCHAR( 30 ) NULL AFTER email");
if (!$result) { echo "Alter ".$prefix."_milpacs_members failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_members succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_main ADD unit_name VARCHAR( 50 ) NOT NULL AFTER motd");
if (!$result) { echo "Alter ".$prefix."_milpacs_main failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_main succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_main ADD unit_tag VARCHAR( 20 ) NOT NULL AFTER unit_name");
if (!$result) { echo "Alter ".$prefix."_milpacs_main failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_main succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_main DROP COLUMN drillpass");
if (!$result) { echo "Alter ".$prefix."_milpacs_main failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_main succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_main DROP COLUMN u_email");
if (!$result) { echo "Alter ".$prefix."_milpacs_main failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_main succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_main DROP COLUMN name");
if (!$result) { echo "Alter ".$prefix."_milpacs_main failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_main succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_main DROP COLUMN color");
if (!$result) { echo "Alter ".$prefix."_milpacs_main failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_main succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_main ADD unit_nick VARCHAR( 20 ) NOT NULL AFTER unit_tag");
if (!$result) { echo "Alter ".$prefix."_milpacs_main failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_main succeeded<br>\n"; }

$result = $db->sql_query("ALTER TABLE ".$prefix."_milpacs_main ADD recruitemail VARCHAR( 50 ) NOT NULL AFTER unit_nick");
if (!$result) { echo "Alter ".$prefix."_milpacs_main failed<br>\n"; } else { echo "Alter ".$prefix."_milpacs_main succeeded<br>\n"; }

$result = $db->sql_query("DROP TABLE IF EXISTS ".$prefix."_milpacs_sotm");
if (!$result) { echo "Drop ".$prefix."_milpacs_sotm failed<br>\n"; } else { echo "Drop ".$prefix."_milpacs_sotm succeeded<br>\n"; }

$result = $db->sql_query("DROP TABLE IF EXISTS ".$prefix."_milpacs_points");
if (!$result) { echo "Drop ".$prefix."_milpacs_points failed<br>\n"; } else { echo "Drop ".$prefix."_milpacs_points succeeded<br>\n"; }

$result = $db->sql_query("DROP TABLE IF EXISTS ".$prefix."_milpacs_points_lkup");
if (!$result) { echo "Drop ".$prefix."_milpacs_points_lkup failed<br>\n"; } else { echo "Drop ".$prefix."_milpacs_points_lkup succeeded<br>\n"; }

$result = $db->sql_query("DROP TABLE IF EXISTS ".$prefix."_milpacs_pass");
if (!$result) { echo "Drop ".$prefix."_milpacs_pass failed<br>\n"; } else { echo "Drop ".$prefix."_milpacs_pass succeeded<br>\n"; }

$result = $db->sql_query("DROP TABLE IF EXISTS ".$prefix."_milpacs_access");
if (!$result) { echo "Drop ".$prefix."_milpacs_access failed<br>\n"; } else { echo "Drop ".$prefix."_milpacs_access succeeded<br>\n"; }

$result = $db->sql_query("DROP TABLE IF EXISTS ".$prefix."_milpacs_hof");
if (!$result) { echo "Drop ".$prefix."_milpacs_hof failed<br>\n"; } else { echo "Drop ".$prefix."_milpacs_hof succeeded<br>\n"; }

//$result = $db->sql_query("INSERT INTO ".$prefix."_milpacs_main VALUES('Welcome to the Insert Unit Here personnel administration system. We are utilizing MILPACS, a module for PHPNuke, developed by 1Lt Donovan of the 3rd Infantry Division.  The MILPACS development site is located at http://milpacs.3rd-infantry-division.net.  Though still under developement, it is a substantial improvement over other methods of unit administration and is currently the only module of its kind available. Please feel free to comment and provide feedback that will help us contribute to the development of this tool.', 'Change Me', '[Your Tag]', 'Change Me', 'recruitment@yourdomain.net'");
//	if (!$result) {echo "Information inserted into <i>milpacs_main</i> was Unsuccessful!<br>\n";} else {echo "Information inserted into <i>milpacs_main</i> was Successful!<br>\n";}


$sql = "INSERT INTO ".$prefix."_milpacs_main VALUES ('Welcome to the (Insert Unit Here) personnel administration system. We are utilizing MILPACS, a module for PHPNuke, developed by 1Lt Donovan of the 3rd Infantry Division.  The MILPACS development site is located at http://milpacs.3rd-infantry-division.net.  Though still under developement, it is a substantial improvement over other methods of unit administration and is currently the only module of its kind available. Please feel free to comment and provide feedback that will help us contribute to the development of this tool.','Change Me', '[Your Tag]', 'Change Me', 'recruitment@yourdomain.net')";

$result = $db->sql_query($sql);	
	if ($result) {
		echo "Information inserted <i>milpacs_main</i> Successful";
		echo "</p>\n";
	} else {
		echo "Information insertion <i>milpacs_main</i> was Unsuccessful";
		echo "</p>\n";
	}


echo "<hr><b>Operation Complete!</b><hr>\n";
echo "<hr><b>REMOVE THIS SCRIPT WHEN FINISHED!</b><hr>\n";
CloseTable();
include("footer.php");   
?>