<?php
/************************************************************************/
/* PHP-NUKE: Web Portal System                                          */
/* ===========================                                          */
/*                                                                      */
/* Copyright (c) 2002 by Francisco Burzi                                */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/
/************************************************************************
* Original Installer Design / Structure
* By: NukeScripts Network (webmaster@nukescripts.net)
* http://www.nukescripts.net
* Copyright � 2000-2005 by NukeScripts Network
************************************************************************/
/********************************************************/
/* MILPACS                                              */
/* By: 3rd ID (donovan@3rd-infantry-division.net)       */
/* http://www.3rd-infantry-division.net                 */
/* Copyright � 2006 by Steven Donovan                   */
/********************************************************/

if ( !defined( 'MILPACS_LOADED' ) ) { die( "Illegal File Access" ); }

/************************************************************************
* Script Initialization
************************************************************************/

$module_name = "MILPACS";

opentable();

echo"Install Options";

/************************************************************************
* Start Displaying
************************************************************************/
echo "<form action='".$_SERVER['PHP_SELF']."' method='post'>\n";

echo "<div id=\"milpacs_div_options\">\n"
			."This script will install, destall or upgrade the tables for ".$module_name."\n"
			."<br><br>"			
			."<br><br>";
			
echo "<select name=\"op\">\n";

/************************************************************************
* For First Time Installs
************************************************************************/

if ( file_exists( "milpacs_installer/install.php" ) ) {

  echo "<option value=\"\">---- Install Options ----</option>\n";

  echo "<option value=\"install\">First Time Install</option>\n";

}

/************************************************************************
* For Upgraders - Add New Options Here...
************************************************************************/

echo "<option value=\"\">---- Upgrade ----</option>\n";

if ( file_exists( "milpacs_installer/upgradeRC1-RC2.php") ) { 

	echo "<option value=\"upgradeRC1-RC2\">Upgrade RC1 to RC2</option>\n";
			
}

/************************************************************************
* Removal Options
************************************************************************/

if ( file_exists( "milpacs_installer/remove.php" ) ) {

  echo "<option value=\"\">---- Removal Options ----</option>\n";

  echo "<option value=\"remove\">Remove ".$module_name."</option>\n";

}

echo "</select>&nbsp;&nbsp;<input type=\"submit\" value=\"Commit\" /><br><br>\n";
echo "<b>Once you have finished with this script, delete it from your server!</b>\n";
echo "</div></form>\n";
CloseTable();
@include("footer.php");
?>