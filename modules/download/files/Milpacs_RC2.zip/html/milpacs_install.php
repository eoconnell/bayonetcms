<?php
/************************************************************************/
/* PHP-NUKE: Web Portal System                                          */
/* ===========================                                          */
/*                                                                      */
/* Copyright (c) 2002 by Francisco Burzi                                */
/* http://phpnuke.org                                                   */
/*                                                                      */
/* This program is free software. You can redistribute it and/or modify */
/* it under the terms of the GNU General Public License as published by */
/* the Free Software Foundation; either version 2 of the License.       */
/************************************************************************/
/************************************************************************
* Original Installer Design / Structure
* By: NukeScripts Network (webmaster@nukescripts.net)
* http://www.nukescripts.net
* Copyright � 2000-2005 by NukeScripts Network
************************************************************************/
/********************************************************/
/* MILPACS                                              */
/* By: 3rd ID (donovan@3rd-infantry-division.net)       */
/* http://www.3rd-infantry-division.net                 */
/* Copyright � 2006 by Steven Donovan                   */
/********************************************************/

define( 'MILPACS_LOADED', true );

/************************************************************************
* Script Initialization
************************************************************************/

@set_time_limit(600);

require_once( "mainfile.php" );

if ( !isset( $admin_file ) ) { $admin_file = "admin"; }

$index = 0;

include( "header.php" );

/************************************************************************
* Determine if logged in as super user
* If not a super USER, you must log in first or BEGONE!
************************************************************************/

if( is_admin( $admin ) ) {
  if( !is_array( $admin) ) {
    $adm = base64_decode( $admin );
    $adm = explode( ":", $adm );
    $aname = "$adm[0]";
  } else {
    $aname = "$admin[0]";
  }
}

$adm_info = $db->sql_fetchrow( $db->sql_query( "SELECT * FROM `".$prefix."_authors` WHERE `aid`='$aname'" ) );

if( $adm_info['radminsuper'] == 1 OR $adm_info['super_user'] == 1 ) {

/************************************************************************
* Either display the installer options or execute an option
************************************************************************/

  switch($op) {
    default:include("milpacs_installer/default.php" );break;
    case "remove":include("milpacs_installer/remove.php");break;
	case "install":include("milpacs_installer/install.php");break;
	case "upgradeRC1-RC2":include("milpacs_installer/upgradeRC1-RC2.php");break;
  }

} else {
  opentable();  
  echo "Sorry, ONLY super admins may run this script";  
  closetable();
}
include( "footer.php" );
?>